using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using Arcane.Core;

static string Full(string p)=>Path.GetFullPath(p);
static void Sign(string path,RSA key)=>File.WriteAllBytes(path+".sig",key.SignData(File.ReadAllBytes(path),HashAlgorithmName.SHA256,RSASignaturePadding.Pss));
if(args.Length==0)throw new ArgumentException("Commands: keygen, channel, launcher-channel, smoke, tests");
switch(args[0])
{
case "keygen":
{
    var dir=Full(args[1]);Directory.CreateDirectory(dir);
    if(File.Exists(Path.Combine(dir,"release-private.pem")))throw new IOException("Key already exists");
    using var rsa=RSA.Create(3072);File.WriteAllText(Path.Combine(dir,"release-private.pem"),rsa.ExportPkcs8PrivateKeyPem());File.WriteAllText(Path.Combine(dir,"release-public.pem"),rsa.ExportSubjectPublicKeyInfoPem());break;
}
case "channel":
{
    var source=Full(args[1]);var output=Full(args[2]);Directory.CreateDirectory(output);
    using var rsa=RSA.Create();rsa.ImportFromPem(File.ReadAllText(args[4]));
    var files=new List<PackFile>();
    foreach(var file in Directory.EnumerateFiles(source,"*",SearchOption.AllDirectories).OrderBy(x=>x,StringComparer.Ordinal))
    {
        var path=Path.GetRelativePath(source,file).Replace('\\','/');var hash=PackUpdater.Hash(file);var rel="objects/"+hash;
        var target=PackUpdater.SafePath(output,rel);Directory.CreateDirectory(Path.GetDirectoryName(target)!);if(!File.Exists(target))File.Copy(file,target);
        var policy=(path.StartsWith("config/") && !path.StartsWith("config/ftbquests/quests/") && path!="config/global_packs.toml") || path.StartsWith("defaultconfigs/")?"seed":"managed";
        files.Add(new PackFile(path,rel,hash,new FileInfo(file).Length,policy,"local-owned-profile; publication requires source/license audit"));
    }
    var manifest=new PackManifest(1,args[3],"1.21.1","21.1.265","Arcane Genesis · Ranger Alpha\nЧетыре класса, 12 специализаций, 256 талантов. Кампания: 654 квеста, 70 глав.\nБаланс предварительный. Выделенный сервер и полное прохождение ещё требуют испытаний.",files);
    PackUpdater.Validate(manifest);var pathOut=Path.Combine(output,"pack.json");Data.Write(pathOut,manifest);Sign(pathOut,rsa);File.WriteAllText(Path.Combine(output,"release-public.pem"),rsa.ExportSubjectPublicKeyInfoPem());
    Console.WriteLine(JsonSerializer.Serialize(new{files=files.Count,bytes=files.Sum(f=>f.Size),manifest=pathOut},Data.Json));break;
}
case "launcher-channel":
{
    using var rsa=RSA.Create();rsa.ImportFromPem(File.ReadAllText(args[4]));
    var output=Full(args[1]);Directory.CreateDirectory(output);var installer=Full(args[2]);var file=Path.Combine(output,"ArcaneGenesis-Setup-"+args[3]+".exe");if(installer!=file)File.Copy(installer,file,true);
    var path=Path.Combine(output,"launcher.json");Data.Write(path,new LauncherRelease(1,args[3],Path.GetFileName(file),PackUpdater.Hash(file),new FileInfo(file).Length));Sign(path,rsa);break;
}
case "sign":
{
    using var rsa=RSA.Create();rsa.ImportFromPem(File.ReadAllText(args[2]));Sign(Full(args[1]),rsa);break;
}
case "official-smoke":
{
    var engine=new NativeGameEngine(Full(args[1]),OfficialBootstrap.Channel,"");
    await engine.EnsureAsync(new Progress<UpdateProgress>(p=>Console.WriteLine(p.Message)));
    Console.WriteLine("Official runtime ready: "+engine.Runtime);
    if(args.Length>=4){var publicKey=File.ReadAllText(args[3]);var updater=new PackUpdater(engine.Game,Full(args[2]),publicKey);var installed=await updater.ApplyAsync(new Progress<UpdateProgress>(p=>Console.WriteLine(p.Message)));Data.Write(Path.Combine(engine.Root,"pack-install-report.json"),installed);var m=await updater.GetManifestAsync();var settings=new LauncherSettings{Nickname="ArcaneTester",MemoryMiB=7168};engine.Configure(settings,m);if(args.Contains("--launch")){using var game=engine.Launch(settings);Data.Write(Path.Combine(engine.Root,"game-process.json"),new{pid=game.Id});Console.WriteLine("Game PID: "+game.Id);await game.WaitForExitAsync();Console.WriteLine("Game exit: "+game.ExitCode);}}
    break;
}
case "native-smoke":
{
    var pack=Full(args[1]);var key=File.ReadAllText(Path.Combine(Path.GetDirectoryName(pack)!,"release-public.pem"));
    var runtime=Full(args[2]);var engine=new NativeGameEngine(Full(args[3]),runtime,key);
    await engine.EnsureAsync();var updater=new PackUpdater(engine.Game,pack,key);var result=await updater.ApplyAsync();var manifest=await updater.GetManifestAsync();
    var settings=new LauncherSettings{InstallDirectory=engine.Root,RuntimeChannel=runtime,Channel=pack,PublicKey=key,Nickname="ArcaneTester",Minimize=false};
    engine.Configure(settings,manifest);
    Data.Write(Path.Combine(engine.Root,"native-settings.json"),settings);
    if(args.Contains("--launch")){using var p=engine.Launch(settings);Data.Write(Path.Combine(engine.Root,"native-process.json"),new{pid=p.Id,game=engine.Game});Console.WriteLine("Minecraft PID: "+p.Id);await p.WaitForExitAsync();}
    Data.Write(Path.Combine(engine.Root,"native-install-report.json"),new{status="PASS",result,java21=NativeGameEngine.FindJava21()!=null,game=engine.Game});break;
}
case "tests": await Tests.Run(Full(args[1]));break;
default:throw new ArgumentException("Unknown command");
}

static class Tests
{
    public static async Task Run(string root)
    {
        if(Directory.Exists(root))throw new IOException("Test directory must be new");Directory.CreateDirectory(root);
        var results=new List<object>();using var rsa=RSA.Create(2048);var key=rsa.ExportSubjectPublicKeyInfoPem();
        var channel=Path.Combine(root,"channel");Directory.CreateDirectory(channel);var content=Path.Combine(channel,"payload");File.WriteAllText(content,"version one");
        PackFile F(string path,string policy="managed")=>new(path,"payload",PackUpdater.Hash(content),new FileInfo(content).Length,policy);
        var manifest=new PackManifest(1,"1.0.0","1.21.1","21.1.265","test",[F("mods/a.jar"),F("config/user.json","seed")]);var address=Path.Combine(channel,"pack.json");
        void Publish(){Data.Write(address,manifest);File.WriteAllBytes(address+".sig",rsa.SignData(File.ReadAllBytes(address),HashAlgorithmName.SHA256,RSASignaturePadding.Pss));}
        async Task Test(string name,Func<Task> test){await test();results.Add(new{name,status="PASS"});Console.WriteLine("PASS "+name);}
        void Assert(bool ok){if(!ok)throw new Exception("Assertion failed");}
        async Task Reject(Func<Task> action){try{await action();}catch(Exception e)when(e is InvalidDataException or CryptographicException or IOException){return;}throw new Exception("Expected rejection");}
        Publish();var game=Path.Combine(root,"game");var updater=new PackUpdater(game,address,key);
        await Test("initial install and signed manifest",async()=>{var r=await updater.ApplyAsync();Assert(r.Downloaded==2 && File.Exists(Path.Combine(game,"mods/a.jar")));});
        await Test("unchanged files not downloaded",async()=>{var r=await updater.ApplyAsync();Assert(r.Downloaded==0 && r.Unchanged==2);});
        await Test("repair corrupt managed file",async()=>{File.WriteAllText(Path.Combine(game,"mods/a.jar"),"bad");var r=await updater.ApplyAsync();Assert(r.Downloaded==1 && File.ReadAllText(Path.Combine(game,"mods/a.jar"))=="version one");});
        await Test("preserve worlds screenshots options custom config",async()=>
        {Directory.CreateDirectory(Path.Combine(game,"saves/world"));Directory.CreateDirectory(Path.Combine(game,"screenshots"));File.WriteAllText(Path.Combine(game,"saves/world/level.dat"),"WORLD");File.WriteAllText(Path.Combine(game,"screenshots/one.png"),"SCREENSHOT");File.WriteAllText(Path.Combine(game,"options.txt"),"CUSTOM OPTIONS");File.WriteAllText(Path.Combine(game,"config/user.json"),"CUSTOM CONFIG");await updater.ApplyAsync();Assert(File.ReadAllText(Path.Combine(game,"config/user.json"))=="CUSTOM CONFIG" && File.ReadAllText(Path.Combine(game,"options.txt"))=="CUSTOM OPTIONS" && File.ReadAllText(Path.Combine(game,"saves/world/level.dat"))=="WORLD");});
        await Test("tampered manifest rejected before changes",async()=>{File.AppendAllText(address," ");await Reject(()=>updater.ApplyAsync());Publish();});
        await Test("wrong signing key rejected",async()=>{using var bad=RSA.Create(2048);await Reject(()=>new PackUpdater(game,address,bad.ExportSubjectPublicKeyInfoPem()).ApplyAsync());});
        await Test("checksum mismatch rejected",async()=>{File.WriteAllText(content,"corrupt source");File.WriteAllText(Path.Combine(game,"mods/a.jar"),"needs repair");await Reject(()=>updater.ApplyAsync());Assert(File.ReadAllText(Path.Combine(game,"mods/a.jar"))=="needs repair");File.WriteAllText(content,"version one");await updater.ApplyAsync();});
        await Test("atomic rollback after interrupted commit",async()=>{File.WriteAllText(content,"version two");manifest=manifest with{Version="2.0.0",Files=[F("mods/a.jar"),F("mods/b.jar"),F("config/user.json","seed")]};Publish();await Reject(()=>updater.ApplyAsync(fault:n=>{if(n==1)throw new IOException("injected failure");}));Assert(File.ReadAllText(Path.Combine(game,"mods/a.jar"))=="version one" && !File.Exists(Path.Combine(game,"mods/b.jar")) && Data.Read<InstalledState>(updater.StatePath).Version=="1.0.0");});
        await Test("changed files only and new config template",async()=>{var r=await updater.ApplyAsync();Assert(r.Downloaded==2 && r.Preserved==1 && File.ReadAllText(Path.Combine(game,"config/user.json"))=="CUSTOM CONFIG" && File.Exists(Path.Combine(game,".arcane/new-defaults/config/user.json")));});
        await Test("remove only previously managed files",async()=>{File.WriteAllText(Path.Combine(game,"mods/user-added.jar"),"USER");manifest=manifest with{Version="3.0.0",Files=[F("mods/a.jar"),F("config/user.json","seed")]};Publish();await updater.ApplyAsync();Assert(!File.Exists(Path.Combine(game,"mods/b.jar")) && File.Exists(Path.Combine(game,"mods/user-added.jar")));});
        await Test("reject traversal absolute ADS and protected paths",async()=>{foreach(var p in new[]{"../outside","/absolute","mods/x:ads","saves/world/level.dat","mods/../x","mods\\evil.jar","mods/a.jar/child"}){var bad=manifest with{Files=[F("mods/a.jar"),F(p)]};try{PackUpdater.Validate(bad);}catch(InvalidDataException){continue;}throw new Exception("Accepted "+p);}await Task.CompletedTask;});
        await Test("reject case insensitive duplicate filenames",async()=>{try{PackUpdater.Validate(manifest with{Files=[F("mods/A.jar"),F("mods/a.jar")]});}catch(InvalidDataException){return;}await Task.CompletedTask;throw new Exception("duplicate accepted");});
        await Test("cancel leaves installation unchanged",async()=>{using var c=new CancellationTokenSource();c.Cancel();try{await updater.ApplyAsync(ct:c.Token);}catch(OperationCanceledException){Assert(Data.Read<InstalledState>(updater.StatePath).Version=="3.0.0");return;}throw new Exception("Cancellation ignored");});
        await Test("world lock prevents updates",async()=>{using var locked=new FileStream(Path.Combine(game,"saves/world/session.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);await Reject(()=>updater.ApplyAsync());});
        await Test("native runtime signature integrity and offline arguments",async()=>
        {
            var runtimeSource=Path.Combine(channel,"runtime.json");var r=new GameRuntime(1,"1.21.1","21.1.265","17","4.0.45","20240808.144430","forgeclient",["client/client.jar","libraries/test.jar"],["libraries/test.jar"],[F("client/client.jar"),F("libraries/test.jar")]);
            Data.Write(runtimeSource,r);File.WriteAllBytes(runtimeSource+".sig",rsa.SignData(File.ReadAllBytes(runtimeSource),HashAlgorithmName.SHA256,RSASignaturePadding.Pss));
            var engine=new NativeGameEngine(Path.Combine(root,"native test"),runtimeSource,key);await engine.EnsureAsync();Assert(File.Exists(Path.Combine(engine.Runtime,"client/client.jar")));
            var settings=new LauncherSettings{Nickname="ArcaneTester"};var launch=engine.BuildArguments(settings,r);Assert(launch.Contains("cpw.mods.bootstraplauncher.BootstrapLauncher") && launch[Array.IndexOf(launch,"--accessToken")+1]=="0" && !launch.Contains("--xuid") && !launch.Any(x=>x.Contains("prism",StringComparison.OrdinalIgnoreCase)));
            var uuid=NativeGameEngine.OfflineUuid(settings.Nickname);Assert(uuid.Length==32 && uuid[12]=='3' && "89ab".Contains(uuid[16]) && uuid!=NativeGameEngine.OfflineUuid("AnotherTester"));
            File.AppendAllText(runtimeSource," ");await Reject(()=>engine.EnsureAsync());
            try{NativeGameEngine.Validate(r with{ClassPath=["../outside.jar"]});}catch(InvalidDataException){return;}throw new Exception("Unsafe native runtime accepted");
        });
        await Test("concurrent update lock prevents second writer",async()=>{using var locked=new FileStream(Path.Combine(game,".arcane/lock"),FileMode.Open,FileAccess.ReadWrite,FileShare.None);await Reject(()=>updater.ApplyAsync());});
        await Test("recover pending journal from previous process",async()=>
        {var backup=Path.Combine(game,".arcane/backup/mods");Directory.CreateDirectory(backup);File.Copy(Path.Combine(game,"mods/a.jar"),Path.Combine(backup,"a.jar"),true);File.Copy(updater.StatePath,Path.Combine(game,".arcane/backup/installed.json"),true);File.WriteAllText(Path.Combine(game,"mods/a.jar"),"INTERRUPTED WRITE");Data.Write(Path.Combine(game,".arcane/journal.json"),new[]{new{path="mods/a.jar",existed=true}});updater.Recover();Assert(File.ReadAllText(Path.Combine(game,"mods/a.jar"))=="version two");await Task.CompletedTask;});
        await Test("tampered installed catalog cannot delete player saves",async()=>
        {var original=File.ReadAllText(updater.StatePath);Data.Write(updater.StatePath,new InstalledState("3.0.0",[F("saves/world/level.dat")]));await Reject(()=>updater.ApplyAsync());Assert(File.ReadAllText(Path.Combine(game,"saves/world/level.dat"))=="WORLD");File.WriteAllText(updater.StatePath,original);});
        await Test("launcher channel signature hash and separate version",async()=>
        {var binary=Path.Combine(channel,"test-setup.exe");File.WriteAllText(binary,"TEST ONLY");var p=Path.Combine(channel,"launcher.json");Data.Write(p,new LauncherRelease(1,"0.1.1","test-setup.exe",PackUpdater.Hash(binary),new FileInfo(binary).Length));File.WriteAllBytes(p+".sig",rsa.SignData(File.ReadAllBytes(p),HashAlgorithmName.SHA256,RSASignaturePadding.Pss));var r=await LauncherUpdater.Check(p,key);var downloaded=await LauncherUpdater.Download(r,p,Path.Combine(root,"launcher-download"));Assert(File.ReadAllText(downloaded)=="TEST ONLY");File.WriteAllText(binary,"BAD");await Reject(()=>LauncherUpdater.Download(r,p,Path.Combine(root,"launcher-download")));});
        await Test("portable defaults and legacy migration preserve player settings",async()=>{var saved=new LauncherSettings{Channel="C:/old/outputs/ArcaneGenesis_Local_Channel/pack/pack.json",RuntimeChannel="C:/old/outputs/ArcaneGenesis_Local_Channel/runtime/runtime.json",Nickname="Tester",MemoryMiB=8192,InstallDirectory=Path.Combine(root,"chosen-game")};var resolved=DistributionSettings.Resolve(saved,new LauncherSettings{Channel="release/pack.json",PublicKey=key},root);Assert(resolved.Channel==Path.Combine(root,"release","pack.json") && resolved.RuntimeChannel==OfficialBootstrap.Channel && resolved.MemoryMiB==8192 && resolved.Nickname=="Tester" && resolved.InstallDirectory==Path.Combine(root,"chosen-game"));await Task.CompletedTask;});
        await Test("official library OS rules",async()=>{Assert(OfficialBootstrap.AllowsWindows(System.Text.Json.Nodes.JsonNode.Parse("{\"rules\":[{\"action\":\"allow\",\"os\":{\"name\":\"windows\"}}]}")!) && !OfficialBootstrap.AllowsWindows(System.Text.Json.Nodes.JsonNode.Parse("{\"rules\":[{\"action\":\"allow\",\"os\":{\"name\":\"linux\"}}]}")!));await Task.CompletedTask;});
        Data.Write(Path.Combine(root,"report.json"),new{status="PASS",count=results.Count,checks=results});
    }
}



