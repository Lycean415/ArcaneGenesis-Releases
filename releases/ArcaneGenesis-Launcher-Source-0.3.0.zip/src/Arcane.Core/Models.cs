using System.Text.Json;
using System.Text.Json.Serialization;

namespace Arcane.Core;

public sealed record PackFile(string Path, string Url, string Sha256, long Size, string Policy = "managed", string? Source = null);
public sealed record PackManifest(int Schema, string Version, string Minecraft, string NeoForge, string News, List<PackFile> Files);
public sealed record InstalledState(string Version, List<PackFile> Files, string Minecraft="1.21.1", string NeoForge="21.1.265");
public sealed record UpdateProgress(string Message, double Percent);
public sealed record InstallResult(int Downloaded, int Unchanged, int Preserved, string Version);
public sealed record EnginePin(string Version, string Url, string Sha256);
public sealed class LauncherSettings
{
    public string InstallDirectory { get; set; } = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ArcaneGenesis", "Game");
    public string Channel { get; set; } = "";
    public string RuntimeChannel { get; set; } = "";
    public string LauncherChannel { get; set; } = "";
    public string Language { get; set; } = "ru";
    public string ProfileMode { get; set; } = "local";
    public string Nickname { get; set; } = "";
    public string MicrosoftProfile { get; set; } = "";
    public int MemoryMiB { get; set; } = 7168;
    public int Width { get; set; } = 1280;
    public int Height { get; set; } = 720;
    public bool Fullscreen { get; set; }
    public bool AutoUpdate { get; set; } = true;
    public bool Minimize { get; set; } = true;
    public string JavaPath { get; set; } = "";
    public string PublicKey { get; set; } = "";
    public string LauncherPublicKey { get; set; } = "";
}
public static class Data
{
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { WriteIndented = true, UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow };
    public static T Read<T>(string path) => JsonSerializer.Deserialize<T>(File.ReadAllText(path), Json) ?? throw new InvalidDataException("Empty JSON");
    public static void Write<T>(string path, T value)
    {
        Directory.CreateDirectory(System.IO.Path.GetDirectoryName(System.IO.Path.GetFullPath(path))!);
        var temp = path + ".new";
        File.WriteAllText(temp, JsonSerializer.Serialize(value, Json));
        File.Move(temp, path, true);
    }
}
