using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;

namespace Arcane.Core;

public sealed class PackUpdater
{
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromMinutes(20) };
    private readonly string root;
    private readonly Uri channel;
    private readonly string key;
    public string StatePath => System.IO.Path.Combine(root, ".arcane", "installed.json");
    public PackUpdater(string root, string channel, string key)
    {
        this.root = System.IO.Path.GetFullPath(root);
        this.channel = Uri.TryCreate(channel, UriKind.Absolute, out var uri) ? uri : new Uri(System.IO.Path.GetFullPath(channel));
        this.key = key;
        if (!this.channel.IsFile && this.channel.Scheme != "https") throw new InvalidDataException("The update channel must use HTTPS.");
    }
    public static string Hash(string path)
    {
        using var input = File.OpenRead(path);
        return Convert.ToHexString(SHA256.HashData(input)).ToLowerInvariant();
    }
    public static string SafePath(string root, string relative)
    {
        if (string.IsNullOrWhiteSpace(relative) || relative.Contains('\\') || relative.Contains(':') || relative.StartsWith('/') || relative.Split('/').Any(p => p is ".." or "." or "" || p.EndsWith('.') || p.EndsWith(' ') || p.IndexOfAny(System.IO.Path.GetInvalidFileNameChars()) >= 0))
            throw new InvalidDataException("Unsafe path: " + relative);
        var absolute = System.IO.Path.GetFullPath(System.IO.Path.Combine(root, relative));
        var prefix = System.IO.Path.GetFullPath(root).TrimEnd(System.IO.Path.DirectorySeparatorChar) + System.IO.Path.DirectorySeparatorChar;
        if (!absolute.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Path escapes install directory");
        for (var p = absolute; p != null && p.Length >= prefix.Length - 1; p = System.IO.Path.GetDirectoryName(p))
            if ((File.Exists(p) || Directory.Exists(p)) && (File.GetAttributes(p) & FileAttributes.ReparsePoint) != 0) throw new InvalidDataException("Links are not supported in managed paths: " + relative);
        return absolute;
    }
    public static void Validate(PackManifest manifest)
    {
        if (manifest.Schema != 1 || string.IsNullOrWhiteSpace(manifest.Version) || manifest.Files.Count == 0 || manifest.Files.Count > 20000 || manifest.Minecraft != "1.21.1" || !manifest.NeoForge.StartsWith("21.1.")) throw new InvalidDataException("Unsupported pack manifest");
        var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var f in manifest.Files)
        {
            SafePath(System.IO.Path.GetTempPath(), f.Path);
            if (!paths.Add(f.Path) || f.Size < 0 || f.Size > 2L * 1024 * 1024 * 1024 || !System.Text.RegularExpressions.Regex.IsMatch(f.Sha256, "^[a-f0-9]{64}$")) throw new InvalidDataException("Invalid file metadata: " + f.Path);
            if (f.Policy is not ("managed" or "seed")) throw new InvalidDataException("Unsupported update policy");
            // Only modpack-owned content is managed. Player data and credentials are never accepted.
            if (!new[] { "mods/", "config/", "defaultconfigs/", "resourcepacks/", "kubejs/", "scripts/", "global_packs/", "patchouli_books/", "datapacks/" }.Any(x => f.Path.StartsWith(x, StringComparison.OrdinalIgnoreCase))) throw new InvalidDataException("Protected/unknown directory: " + f.Path);
            if (f.Path.EndsWith("/", StringComparison.Ordinal) || f.Path.Contains("runtime-test", StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Test/private content rejected");
        }
        foreach (var p in paths)
            if (paths.Any(other => other.StartsWith(p + "/", StringComparison.OrdinalIgnoreCase))) throw new InvalidDataException("File/directory conflict: " + p);
    }
    private async Task<byte[]> ReadUri(Uri uri, CancellationToken ct)
    {
        if (!channel.IsFile && uri.Scheme != "https") throw new InvalidDataException("Remote channel cannot read local files");
        if (!uri.IsFile && uri.Scheme != "https") throw new InvalidDataException("HTTPS required");
        if (uri.IsFile) return await File.ReadAllBytesAsync(uri.LocalPath, ct);
        using var request = new HttpRequestMessage(HttpMethod.Get, uri);
        request.Headers.UserAgent.ParseAdd("ArcaneGenesisLauncher/0.1.0");
        using var response = await Http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
        response.EnsureSuccessStatusCode();
        if (response.RequestMessage?.RequestUri?.Scheme != "https") throw new InvalidDataException("Insecure redirect");
        await using var stream = await response.Content.ReadAsStreamAsync(ct);
        using var memory = new MemoryStream();
        var buffer = new byte[65536];
        int n;
        while ((n = await stream.ReadAsync(buffer, ct)) != 0) { if (memory.Length + n > 16 * 1024 * 1024) throw new InvalidDataException("Manifest too large"); await memory.WriteAsync(buffer.AsMemory(0,n), ct); }
        return memory.ToArray();
    }
    public async Task<PackManifest> GetManifestAsync(CancellationToken ct = default)
    {
        using var deadline=CancellationTokenSource.CreateLinkedTokenSource(ct);deadline.CancelAfter(TimeSpan.FromSeconds(25));
        var bytes = await ReadUri(channel, deadline.Token);
        if (string.IsNullOrWhiteSpace(key)) throw new InvalidDataException("Trusted release public key is missing");
        var signature = await ReadUri(new Uri(channel.AbsoluteUri + ".sig"), deadline.Token);
        using var rsa = RSA.Create(); rsa.ImportFromPem(key);
        if (!rsa.VerifyData(bytes, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pss)) throw new CryptographicException("Invalid manifest signature");
        var manifest = JsonSerializer.Deserialize<PackManifest>(bytes, Data.Json) ?? throw new InvalidDataException("Empty manifest");
        Validate(manifest);
        return manifest;
    }
    private async Task Download(PackFile f, string target, CancellationToken ct)
    {
        Directory.CreateDirectory(System.IO.Path.GetDirectoryName(target)!);
        var uri = new Uri(channel, f.Url);
        if ((!channel.IsFile && uri.Scheme != "https") || (!uri.IsFile && uri.Scheme != "https")) throw new InvalidDataException("Insecure download");
        await using var output = new FileStream(target, FileMode.CreateNew, FileAccess.Write, FileShare.None);
        using var response = uri.IsFile ? null : await Http.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead, ct);
        response?.EnsureSuccessStatusCode();
        if (response != null && response.RequestMessage?.RequestUri?.Scheme != "https") throw new InvalidDataException("Insecure redirect");
        await using var input = uri.IsFile ? File.OpenRead(uri.LocalPath) : await response!.Content.ReadAsStreamAsync(ct);
        using var digest = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        var buffer = new byte[131072]; long total = 0; int n;
        while ((n = await input.ReadAsync(buffer, ct)) > 0)
        {
            total += n; if (total > f.Size) throw new InvalidDataException("File exceeds declared size: " + f.Path);
            digest.AppendData(buffer, 0, n); await output.WriteAsync(buffer.AsMemory(0,n), ct);
        }
        if (total != f.Size || !Convert.ToHexString(digest.GetHashAndReset()).Equals(f.Sha256, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Checksum mismatch: " + f.Path);
        await output.FlushAsync(ct);
    }
    public static void EnsureIdle(string gameRoot)
    {
        // The game process continues independently of the invoking process.
        if (Directory.Exists(System.IO.Path.Combine(gameRoot, "saves")))
            foreach (var file in Directory.EnumerateFiles(System.IO.Path.Combine(gameRoot,"saves"), "session.lock", SearchOption.AllDirectories))
            {
                try { using var check = new FileStream(file, FileMode.Open, FileAccess.ReadWrite, FileShare.None); }
                catch (IOException) { throw new IOException("Minecraft is using a world. Close the game before updating."); }
            }
    }
    public async Task<InstallResult> ApplyAsync(IProgress<UpdateProgress>? progress = null, CancellationToken ct = default, Action<int>? fault = null)
    {
        Directory.CreateDirectory(root);
        SafePath(root, ".arcane/lock");
        Directory.CreateDirectory(System.IO.Path.Combine(root, ".arcane"));
        using var gate = new FileStream(System.IO.Path.Combine(root,".arcane","lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        EnsureIdle(root);
        Recover();
        var manifest = await GetManifestAsync(ct);
        var old = File.Exists(StatePath) ? Data.Read<InstalledState>(StatePath) : new InstalledState("", []);
        if(old.Files.Count>0) Validate(new PackManifest(1,old.Version,"1.21.1","21.1.265","",old.Files));
        foreach (var f in old.Files) SafePath(root, f.Path);
        var stage = SafePath(root,".arcane/stage");
        if (Directory.Exists(stage)) Directory.Delete(stage, true);
        Directory.CreateDirectory(stage);
        int unchanged=0, preserved=0;
        List<PackFile> changed = [];
        for (int i=0; i<manifest.Files.Count; i++)
        {
            ct.ThrowIfCancellationRequested();
            var f = manifest.Files[i]; var dest = SafePath(root, f.Path);
            if (File.Exists(dest) && new FileInfo(dest).Length == f.Size && Hash(dest) == f.Sha256) { unchanged++; continue; }
            var prior = old.Files.Find(x => x.Path.Equals(f.Path, StringComparison.OrdinalIgnoreCase));
            // Templates update when untouched; locally edited settings are preserved, with the new default stored separately.
            if (f.Policy == "seed" && File.Exists(dest) && (prior == null || Hash(dest) != prior.Sha256))
            {
                var template = SafePath(stage, "templates/"+f.Path);
                await Download(f, template, ct); preserved++; continue;
            }
            progress?.Report(new UpdateProgress($"{i+1}/{manifest.Files.Count} · {f.Path}", (i+1)*90.0/manifest.Files.Count));
            await Download(f, SafePath(stage,"content/"+f.Path), ct); changed.Add(f);
        }
        var desired = manifest.Files.Select(x => x.Path).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var remove = old.Files.Where(x => !desired.Contains(x.Path) && x.Policy == "managed").ToList();
        var operations = changed.Select(x=>x.Path).Concat(remove.Select(x=>x.Path)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var backup = SafePath(root,".arcane/backup");
        if (Directory.Exists(backup)) Directory.Delete(backup,true);
        Directory.CreateDirectory(backup);
        // Back up the entire write set before recording the transaction. No live files have changed yet.
        var journal = operations.Select(p => new JournalEntry(p, File.Exists(SafePath(root,p)))).ToList();
        foreach (var item in journal.Where(x=>x.Existed))
        { var to=SafePath(backup,item.Path); Directory.CreateDirectory(System.IO.Path.GetDirectoryName(to)!); File.Copy(SafePath(root,item.Path),to); }
        if (File.Exists(StatePath)) File.Copy(StatePath, System.IO.Path.Combine(backup,"installed.json"));
        Data.Write(System.IO.Path.Combine(root,".arcane","journal.json"),journal);
        try
        {
            EnsureIdle(root); ct.ThrowIfCancellationRequested(); int count=0;
            foreach (var p in operations)
            {
                var dest=SafePath(root,p); var source=SafePath(stage,"content/"+p);
                if (File.Exists(source)) { Directory.CreateDirectory(System.IO.Path.GetDirectoryName(dest)!); File.Copy(source,dest,true); }
                else if (File.Exists(dest)) File.Delete(dest);
                fault?.Invoke(++count);
            }
            Data.Write(StatePath, new InstalledState(manifest.Version,manifest.Files,manifest.Minecraft,manifest.NeoForge));
            File.Delete(System.IO.Path.Combine(root,".arcane","journal.json"));
        }
        catch { Recover(); throw; }
        var templates=System.IO.Path.Combine(stage,"templates");
        if (Directory.Exists(templates)) foreach(var file in Directory.EnumerateFiles(templates,"*",SearchOption.AllDirectories))
        { var dest=SafePath(root,".arcane/new-defaults/"+System.IO.Path.GetRelativePath(templates,file).Replace('\\','/')); Directory.CreateDirectory(System.IO.Path.GetDirectoryName(dest)!); File.Copy(file,dest,true); }
        progress?.Report(new UpdateProgress(manifest.Version,100));
        return new InstallResult(changed.Count,unchanged,preserved,manifest.Version);
    }
    private sealed record JournalEntry(string Path, bool Existed);
    public void Recover()
    {
        var journal=System.IO.Path.Combine(root,".arcane","journal.json");
        if (!File.Exists(journal)) return;
        var backup=System.IO.Path.Combine(root,".arcane","backup");
        foreach (var item in Data.Read<List<JournalEntry>>(journal))
        {
            var target=SafePath(root,item.Path);
            if (item.Existed) { Directory.CreateDirectory(System.IO.Path.GetDirectoryName(target)!); File.Copy(SafePath(backup,item.Path),target,true); }
            else if (File.Exists(target)) File.Delete(target);
        }
        var stateBackup=System.IO.Path.Combine(backup,"installed.json");
        if(File.Exists(stateBackup)) File.Copy(stateBackup,StatePath,true); else if(File.Exists(StatePath)) File.Delete(StatePath);
        File.Delete(journal);
    }
}

