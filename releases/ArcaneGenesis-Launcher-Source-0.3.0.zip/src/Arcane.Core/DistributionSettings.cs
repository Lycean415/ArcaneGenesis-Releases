namespace Arcane.Core;

public static class DistributionSettings
{
    public static LauncherSettings Resolve(LauncherSettings settings,LauncherSettings defaults,string baseDirectory)
    {
        string ResolveAddress(string address)=>string.IsNullOrWhiteSpace(address)?"":Uri.TryCreate(address,UriKind.Absolute,out _)?address:Path.GetFullPath(Path.Combine(baseDirectory,address));
        bool OldChannel(string value)=>string.IsNullOrWhiteSpace(value)||value.Contains("ArcaneGenesis_Local_Channel",StringComparison.OrdinalIgnoreCase);
        if(OldChannel(settings.Channel))settings.Channel=ResolveAddress(defaults.Channel);
        else settings.Channel=ResolveAddress(settings.Channel);
        if(OldChannel(settings.RuntimeChannel))settings.RuntimeChannel=OfficialBootstrap.Channel;
        if(OldChannel(settings.LauncherChannel))settings.LauncherChannel=ResolveAddress(defaults.LauncherChannel);
        if(string.IsNullOrWhiteSpace(settings.InstallDirectory))settings.InstallDirectory=new LauncherSettings().InstallDirectory;
        if(string.IsNullOrWhiteSpace(settings.PublicKey))settings.PublicKey=defaults.PublicKey;
        if(string.IsNullOrWhiteSpace(settings.LauncherPublicKey))settings.LauncherPublicKey=defaults.LauncherPublicKey;
        settings.ProfileMode="local";return settings;
    }
}
