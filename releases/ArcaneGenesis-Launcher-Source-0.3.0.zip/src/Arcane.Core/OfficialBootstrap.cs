using System.Diagnostics;
using System.IO.Compression;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json.Nodes;

namespace Arcane.Core;

// No game binaries or user-machine paths are distributed. Each installation is built
// from Mojang metadata and the checksum-pinned, unmodified NeoForge installer.
public static class OfficialBootstrap
{
    public const string Channel = "official:1.21.1-neoforge-21.1.265";
    private const string InstallerHash = "a547ccc30a80a675d1c61d04b55d10c45c39a86971e09731482c50a24399d1a2";
    private const string JavaHash = "e15ee1e54a5a3b38027a09cedfa87bc3348d7dd3ce50866dd3d9671d7fffc6c1";
    private const string JavaUrl = "https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.13.1%2B2/OpenJDK21U-jre_x64_windows_hotspot_21.0.13.1_2.zip";
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromMinutes(20) };
    private static string S(JsonNode n,string key)=>n[key]!.GetValue<string>();
    private static string Digest(string file, bool sha1)
    { using var input=File.OpenRead(file);return Convert.ToHexString(sha1?SHA1.HashData(input):SHA256.HashData(input)).ToLowerInvariant(); }

    private static async Task Fetch(string url,string file,string hash,bool sha1,CancellationToken ct)
    {
        if(File.Exists(file)&&Digest(file,sha1)==hash)return;
        if(new Uri(url).Scheme!="https")throw new InvalidDataException("Official downloads require HTTPS");
        Directory.CreateDirectory(Path.GetDirectoryName(file)!);
        for(int attempt=0;;attempt++)
        {
            try
            {
                using var response=await Http.GetAsync(url,HttpCompletionOption.ResponseHeadersRead,ct);response.EnsureSuccessStatusCode();
                if(response.RequestMessage?.RequestUri?.Scheme!="https")throw new InvalidDataException("Insecure redirect");
                await using(var output=new FileStream(file+".partial",FileMode.Create,FileAccess.Write,FileShare.None))
                await using(var input=await response.Content.ReadAsStreamAsync(ct)) { await input.CopyToAsync(output,ct); }
                if(Digest(file+".partial",sha1)!=hash)throw new InvalidDataException("Official download checksum mismatch: "+Path.GetFileName(file));
                File.Move(file+".partial",file,true);return;
            }
            catch(HttpRequestException) when(attempt<2) { await Task.Delay(500*(attempt+1),ct); }
        }
    }
    private static async Task<JsonNode> Json(string url,CancellationToken ct)
    { if(new Uri(url).Scheme!="https")throw new InvalidDataException("HTTPS required");return JsonNode.Parse(await Http.GetStringAsync(url,ct))??throw new InvalidDataException("Empty metadata"); }
    public static bool AllowsWindows(JsonNode library)
    {
        if(library["rules"] is not JsonArray rules)return true;
        bool allowed=false;
        foreach(var r in rules)
        {
            if(r!["features"]!=null)continue;
            var os=r["os"];if(os!=null && (os["name"]?.GetValue<string>() is string name && name!="windows"))continue;
            if(os?["arch"]?.GetValue<string>() is string arch && arch is not ("x86_64" or "amd64"))continue;
            allowed=S(r,"action")=="allow";
        }
        return allowed;
    }
    private static void Extract(string zip,string output,bool dllOnly=false)
    {
        using var archive=ZipFile.OpenRead(zip);
        foreach(var e in archive.Entries)
        {
            if(e.FullName.EndsWith('/'))continue;
            if(dllOnly&&!e.FullName.EndsWith(".dll",StringComparison.OrdinalIgnoreCase))continue;
            var name=dllOnly?Path.GetFileName(e.FullName):e.FullName;
            var target=PackUpdater.SafePath(output,name);Directory.CreateDirectory(Path.GetDirectoryName(target)!);e.ExtractToFile(target,true);
        }
    }
    public static string? Java(string runtime)
    {
        var root=Path.Combine(runtime,"jre");
        var receipt=Path.Combine(runtime,"bootstrap","java-files.json");
        if(!Directory.Exists(root)||!File.Exists(receipt))return null;
        List<PackFile> catalog;
        try { catalog=Data.Read<List<PackFile>>(receipt); }
        catch(Exception e) when(e is System.Text.Json.JsonException or IOException or InvalidDataException) { return null; }
        if(catalog.Count==0||catalog.Any(f=>!File.Exists(PackUpdater.SafePath(root,f.Path))||PackUpdater.Hash(PackUpdater.SafePath(root,f.Path))!=f.Sha256))return null;
        return Directory.EnumerateFiles(root,"javaw.exe",SearchOption.AllDirectories).FirstOrDefault();
    }
    private static async Task<string> EnsureJava(string root,CancellationToken ct)
    {
        var existing=Java(root);if(existing!=null)return existing;
        var zip=Path.Combine(root,"bootstrap","java21.zip");await Fetch(JavaUrl,zip,JavaHash,false,ct);
        var jre=Path.Combine(root,"jre");Extract(zip,jre);
        Data.Write(Path.Combine(root,"bootstrap","java-files.json"),Directory.EnumerateFiles(jre,"*",SearchOption.AllDirectories).Select(f=>new PackFile(Path.GetRelativePath(jre,f).Replace('\\','/'),"",PackUpdater.Hash(f),new FileInfo(f).Length)).ToList());
        return Java(root)??throw new IOException("Java 21 archive is incomplete");
    }
    public static async Task<GameRuntime> Ensure(string root,IProgress<UpdateProgress>? progress,CancellationToken ct)
    {
        Directory.CreateDirectory(root);
        progress?.Report(new("Java 21 · проверка среды",0));var java=await EnsureJava(root,ct);
        var receipt=Path.Combine(root,"official-runtime.json");
        if(File.Exists(receipt))
        {
            try
            {
                var cached=Data.Read<GameRuntime>(receipt);NativeGameEngine.Validate(cached);
                if(cached.Files.All(f=>File.Exists(PackUpdater.SafePath(root,f.Path))&&new FileInfo(PackUpdater.SafePath(root,f.Path)).Length==f.Size&&PackUpdater.Hash(PackUpdater.SafePath(root,f.Path))==f.Sha256))return cached;
            }
            catch(Exception e) when(e is System.Text.Json.JsonException or InvalidDataException) { /* Rebuild a damaged local receipt from official metadata. */ }
        }
        var meta=await Json("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json",ct);
        var version=meta["versions"]!.AsArray().First(x=>S(x!,"id")=="1.21.1")!;
        var vanillaPath=PackUpdater.SafePath(root,"versions/1.21.1/1.21.1.json");
        await Fetch(S(version,"url"),vanillaPath,S(version,"sha1"),true,ct);
        var vanilla=JsonNode.Parse(await File.ReadAllTextAsync(vanillaPath,ct))!;
        var client=vanilla["downloads"]!["client"]!;
        if(S(client,"sha1")!="30c73b1c5da787909b2f73340419fdf13b9def88")throw new InvalidDataException("Unexpected Minecraft 1.21.1 client");
        progress?.Report(new("Minecraft 1.21.1 · загрузка",3));
        await Fetch(S(client,"url"),PackUpdater.SafePath(root,"versions/1.21.1/1.21.1.jar"),S(client,"sha1"),true,ct);
        Directory.CreateDirectory(Path.Combine(root,"client"));File.Copy(PackUpdater.SafePath(root,"versions/1.21.1/1.21.1.jar"),PackUpdater.SafePath(root,"client/client.jar"),true);
        var libraries=vanilla["libraries"]!.AsArray().Where(x=>AllowsWindows(x!)).Select(x=>x!).ToArray();
        var cp=new List<string>();int done=0;
        foreach(var lib in libraries)
        {
            var a=lib["downloads"]?["artifact"];if(a==null)continue;
            var path="libraries/"+S(a,"path");await Fetch(S(a,"url"),PackUpdater.SafePath(root,path),S(a,"sha1"),true,ct);cp.Add(path);
            // Native classifiers in modern Mojang metadata are regular artifacts.
            if(path.Contains("natives-windows.jar",StringComparison.Ordinal))Extract(PackUpdater.SafePath(root,path),Path.Combine(root,"natives"),true);
            progress?.Report(new($"Библиотеки Minecraft · {++done}/{libraries.Length}",5+done*15.0/libraries.Length));
        }
        var index=vanilla["assetIndex"]!;var assetId=S(index,"id");
        var indexPath=PackUpdater.SafePath(root,"assets/indexes/"+assetId+".json");await Fetch(S(index,"url"),indexPath,S(index,"sha1"),true,ct);
        var objects=JsonNode.Parse(await File.ReadAllTextAsync(indexPath,ct))!["objects"]!.AsObject().Select(x=>x.Value!).GroupBy(x=>S(x,"hash")).Select(x=>x.First()).ToArray();done=0;
        await Parallel.ForEachAsync(objects,new ParallelOptions{MaxDegreeOfParallelism=8,CancellationToken=ct},async(obj,token)=>
        {
            var h=S(obj,"hash");await Fetch("https://resources.download.minecraft.net/"+h[..2]+"/"+h,PackUpdater.SafePath(root,"assets/objects/"+h[..2]+"/"+h),h,true,token);
            var n=Interlocked.Increment(ref done);if(n%25==0||n==objects.Length)progress?.Report(new($"Ресурсы Minecraft · {n}/{objects.Length}",20+n*50.0/objects.Length));
        });
        var installer=PackUpdater.SafePath(root,"bootstrap/neoforge-installer.jar");
        await Fetch("https://maven.neoforged.net/releases/net/neoforged/neoforge/21.1.265/neoforge-21.1.265-installer.jar",installer,InstallerHash,false,ct);
        // The official installer requires the standard launcher directory marker.
        var profiles=Path.Combine(root,"launcher_profiles.json");if(!File.Exists(profiles))await File.WriteAllTextAsync(profiles,"{\"profiles\":{}}",ct);
        progress?.Report(new("NeoForge 21.1.265 · официальная установка",72));
        var start=new ProcessStartInfo(Path.Combine(Path.GetDirectoryName(java)!,"java.exe")){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=root,RedirectStandardOutput=true,RedirectStandardError=true};
        foreach(var arg in new[]{"-jar",installer,"--installClient",root})start.ArgumentList.Add(arg);
        using(var process=Process.Start(start)??throw new IOException("Cannot start NeoForge installer"))
        {
            var stdout=process.StandardOutput.ReadToEndAsync(ct);var stderr=process.StandardError.ReadToEndAsync(ct);
            using var registration=ct.Register(()=>{try{process.Kill(true);}catch(InvalidOperationException){}});
            await process.WaitForExitAsync(ct);var log=(await stdout)+"\n"+(await stderr);await File.WriteAllTextAsync(Path.Combine(root,"bootstrap","neoforge-install.log"),log,ct);
            if(process.ExitCode!=0)throw new IOException("NeoForge не установлен. Подробности: "+Path.Combine(root,"bootstrap","neoforge-install.log"));
        }
        var neo=JsonNode.Parse(await File.ReadAllTextAsync(PackUpdater.SafePath(root,"versions/neoforge-21.1.265/neoforge-21.1.265.json"),ct))!;
        foreach(var lib in neo["libraries"]!.AsArray())
        {
            var a=lib!["downloads"]?["artifact"];if(a==null)continue;
            var path="libraries/"+S(a,"path");
            if(!File.Exists(PackUpdater.SafePath(root,path))||Digest(PackUpdater.SafePath(root,path),true)!=S(a,"sha1"))await Fetch(S(a,"url"),PackUpdater.SafePath(root,path),S(a,"sha1"),true,ct);
            cp.Insert(0,path);
        }
        cp.Add("client/client.jar");
        var jvm=neo["arguments"]!["jvm"]!.AsArray().Where(x=>x is JsonValue).Select(x=>x!.GetValue<string>()).ToArray();var mp=jvm[Array.IndexOf(jvm,"-p")+1].Replace("${classpath_separator}",";").Split(';').Select(x=>x.Replace("${library_directory}/","libraries/")).ToArray();
        var files=new List<PackFile>();
        foreach(var directory in new[]{"libraries","assets","natives","client"})
        foreach(var file in Directory.EnumerateFiles(Path.Combine(root,directory),"*",SearchOption.AllDirectories).Where(x=>!x.EndsWith(".partial")))
            files.Add(new(Path.GetRelativePath(root,file).Replace('\\','/'),"",PackUpdater.Hash(file),new FileInfo(file).Length,Source:"official bootstrap cache"));
        var result=new GameRuntime(1,"1.21.1","21.1.265",assetId,"4.0.45","20240808.144430","forgeclient",cp.Distinct().ToArray(),mp,files);
        NativeGameEngine.Validate(result);Data.Write(receipt,result);progress?.Report(new("Minecraft и NeoForge установлены",100));return result;
    }
}

