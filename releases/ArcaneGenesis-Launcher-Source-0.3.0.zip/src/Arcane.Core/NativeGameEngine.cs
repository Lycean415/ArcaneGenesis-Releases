using System.Diagnostics;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace Arcane.Core;
public sealed record GameRuntime(int Schema,string Minecraft,string NeoForge,string AssetIndex,string FmlVersion,string NeoFormVersion,string LaunchTarget,string[] ClassPath,string[] ModulePath,List<PackFile> Files);
public sealed record RunningGame(int Pid,long Started);
public sealed class NativeGameEngine
{
    private readonly string channel,key;
    public string Root{get;}
    public string Runtime=>Path.Combine(Root,"runtime");
    public string Game=>Directory.Exists(Path.Combine(Root,"prism","instances","ArcaneGenesis",".minecraft"))?Path.Combine(Root,"prism","instances","ArcaneGenesis",".minecraft"):Path.Combine(Root,"game");
    private string Active=>Path.Combine(Game,".arcane","active-game.json");
    public NativeGameEngine(string root,string channel,string key){Root=Path.GetFullPath(root);this.channel=channel;this.key=key;}
    public void EnsureNotRunning()
    {
        PackUpdater.EnsureIdle(Game);
        if(!File.Exists(Active))return;
        var active=Data.Read<RunningGame>(Active);
        try{using var process=Process.GetProcessById(active.Pid);if(!process.HasExited && process.StartTime.ToUniversalTime().Ticks==active.Started)throw new IOException("Minecraft уже запущен. Закрой игру перед обновлением.");}
        catch(ArgumentException){}
    }
    private static Uri Address(string path)=>Uri.TryCreate(path,UriKind.Absolute,out var uri)?uri:new Uri(Path.GetFullPath(path));
    private static async Task<byte[]> Read(Uri uri,CancellationToken ct)
    {
        if(uri.IsFile)return await File.ReadAllBytesAsync(uri.LocalPath,ct);
        if(uri.Scheme!="https")throw new InvalidDataException("HTTPS required");
        using var http=new HttpClient{Timeout=TimeSpan.FromSeconds(30)};
        var bytes=await http.GetByteArrayAsync(uri,ct);if(bytes.Length>16*1024*1024)throw new InvalidDataException("Runtime manifest too large");return bytes;
    }
    private GameRuntime Verify(byte[] data,byte[] signature)
    {
        using var rsa=RSA.Create();rsa.ImportFromPem(key);
        if(!rsa.VerifyData(data,signature,HashAlgorithmName.SHA256,RSASignaturePadding.Pss))throw new CryptographicException("Invalid runtime signature");
        var result=JsonSerializer.Deserialize<GameRuntime>(data,Data.Json)??throw new InvalidDataException("Empty runtime");
        Validate(result);return result;
    }
    public static void Validate(GameRuntime r)
    {
        if(r.Schema!=1 || r.Minecraft!="1.21.1" || r.NeoForge!="21.1.265" || r.AssetIndex!="17" || r.FmlVersion!="4.0.45" || r.NeoFormVersion!="20240808.144430" || r.LaunchTarget!="forgeclient" || r.Files.Count is <1 or >30000)throw new InvalidDataException("Unsupported Minecraft runtime");
        var paths=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(var f in r.Files)
        {
            PackUpdater.SafePath(Path.GetTempPath(),f.Path);
            if(!paths.Add(f.Path) || !new[]{"libraries/","assets/","natives/","client/"}.Any(x=>f.Path.StartsWith(x,StringComparison.Ordinal)) || f.Size<0 || f.Size>1024L*1024*1024 || !Regex.IsMatch(f.Sha256,"^[a-f0-9]{64}$"))throw new InvalidDataException("Unsafe runtime entry");
        }
        foreach(var p in r.ClassPath.Concat(r.ModulePath))if(!paths.Contains(p)||!p.EndsWith(".jar",StringComparison.Ordinal))throw new InvalidDataException("Missing runtime classpath entry");
        if(r.ClassPath.Length<2 || r.ModulePath.Length<1)throw new InvalidDataException("Incomplete classpath");
    }
    public async Task EnsureAsync(IProgress<UpdateProgress>? progress=null,CancellationToken ct=default)
    {
        EnsureNotRunning();Directory.CreateDirectory(Runtime);
        using var gate=new FileStream(PackUpdater.SafePath(Runtime,"install.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
        if(channel==OfficialBootstrap.Channel){await OfficialBootstrap.Ensure(Runtime,progress,ct);return;}
        var address=Address(channel);
        var bytes=await Read(address,ct);var signature=await Read(new Uri(address.AbsoluteUri+".sig"),ct);var r=Verify(bytes,signature);
        using var http=new HttpClient{Timeout=TimeSpan.FromMinutes(15)};
        int n=0;
        foreach(var f in r.Files)
        {
            ct.ThrowIfCancellationRequested();var target=PackUpdater.SafePath(Runtime,f.Path);
            if(File.Exists(target)&&new FileInfo(target).Length==f.Size&&PackUpdater.Hash(target)==f.Sha256){n++;continue;}
            progress?.Report(new UpdateProgress($"Minecraft · {++n}/{r.Files.Count}",n*100.0/r.Files.Count));
            var uri=new Uri(address,f.Url);
            if((!address.IsFile&&uri.Scheme!="https")||(!uri.IsFile&&uri.Scheme!="https"))throw new InvalidDataException("Unsafe runtime download");
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);var temp=PackUpdater.SafePath(Runtime,f.Path+".partial");
            using var response=uri.IsFile?null:await http.GetAsync(uri,HttpCompletionOption.ResponseHeadersRead,ct);response?.EnsureSuccessStatusCode();
            if(response!=null&&response.RequestMessage?.RequestUri?.Scheme!="https")throw new InvalidDataException("Unsafe redirect");
            await using(var input=uri.IsFile?File.OpenRead(uri.LocalPath):await response!.Content.ReadAsStreamAsync(ct))
            await using(var output=File.Create(temp))
            {var buffer=new byte[131072];long total=0;int count;while((count=await input.ReadAsync(buffer,ct))>0){total+=count;if(total>f.Size)throw new InvalidDataException("Runtime size mismatch");await output.WriteAsync(buffer.AsMemory(0,count),ct);}}
            if(new FileInfo(temp).Length!=f.Size||PackUpdater.Hash(temp)!=f.Sha256)throw new InvalidDataException("Runtime checksum mismatch: "+f.Path);
            File.Move(temp,target,true);
        }
        await File.WriteAllBytesAsync(Path.Combine(Runtime,"runtime.json"),bytes,ct);await File.WriteAllBytesAsync(Path.Combine(Runtime,"runtime.json.sig"),signature,ct);
    }
    private GameRuntime Cached()=>channel==OfficialBootstrap.Channel?Data.Read<GameRuntime>(Path.Combine(Runtime,"official-runtime.json")):Verify(File.ReadAllBytes(Path.Combine(Runtime,"runtime.json")),File.ReadAllBytes(Path.Combine(Runtime,"runtime.json.sig")));
    public void Configure(LauncherSettings settings,PackManifest pack)
    {
        var r=Cached();if(r.Minecraft!=pack.Minecraft||r.NeoForge!=pack.NeoForge)throw new InvalidDataException("Runtime and modpack versions do not match");
        if(settings.MemoryMiB is <2048 or >65536||settings.Width is <640 or >7680||settings.Height is <480 or >4320)throw new InvalidDataException("Invalid memory or resolution");
        Directory.CreateDirectory(Game);var path=Path.Combine(Game,"options.txt");var lines=File.Exists(path)?File.ReadAllLines(path).ToList():[];
        var i=lines.FindIndex(x=>x.StartsWith("fullscreen:"));var value="fullscreen:"+settings.Fullscreen.ToString().ToLowerInvariant();if(i>=0)lines[i]=value;else lines.Add(value);File.WriteAllLines(path,lines);
    }
    public static string OfflineUuid(string name)
    {
        var bytes=MD5.HashData(Encoding.UTF8.GetBytes("OfflinePlayer:"+name));bytes[6]=(byte)((bytes[6]&15)|48);bytes[8]=(byte)((bytes[8]&63)|128);return Convert.ToHexString(bytes).ToLowerInvariant();
    }
    public string[] BuildArguments(LauncherSettings s,GameRuntime r)
    {
        Validate(r);if(!Regex.IsMatch(s.Nickname,"^[A-Za-z0-9_]{3,16}$"))throw new InvalidDataException("Ник: 3–16 латинских букв, цифр или _");
        if(s.MemoryMiB is <2048 or >65536)throw new InvalidDataException("Invalid RAM");
        string P(string rel)=>PackUpdater.SafePath(Runtime,rel).Replace('\\','/');
        var natives=P("natives").TrimEnd('/');
        List<string> args=[$"-Xms1024m",$"-Xmx{s.MemoryMiB}m","-Djava.library.path="+natives,"-Djna.tmpdir="+natives,"-Dorg.lwjgl.system.SharedLibraryExtractPath="+natives,"-Dio.netty.native.workdir="+natives,"-Dminecraft.launcher.brand=ArcaneGenesis","-Dminecraft.launcher.version=0.3.0","-Djava.net.preferIPv6Addresses=system","-DignoreList=client-extra,client.jar","-DlibraryDirectory="+P("libraries").TrimEnd('/'),"-cp",string.Join(';',r.ClassPath.Select(P)),"-p",string.Join(';',r.ModulePath.Select(P)),"--add-modules","ALL-MODULE-PATH","--add-opens","java.base/java.util.jar=cpw.mods.securejarhandler","--add-opens","java.base/java.lang.invoke=cpw.mods.securejarhandler","--add-exports","java.base/sun.security.util=cpw.mods.securejarhandler","--add-exports","jdk.naming.dns/com.sun.jndi.dns=java.naming","cpw.mods.bootstraplauncher.BootstrapLauncher","--username",s.Nickname,"--version","ArcaneGenesis-1.21.1","--gameDir",Game.Replace('\\','/'),"--assetsDir",P("assets").TrimEnd('/'),"--assetIndex",r.AssetIndex,"--uuid",OfflineUuid(s.Nickname),"--accessToken","0","--userType","legacy","--versionType","release","--fml.neoForgeVersion",r.NeoForge,"--fml.fmlVersion",r.FmlVersion,"--fml.mcVersion",r.Minecraft,"--fml.neoFormVersion",r.NeoFormVersion,"--launchTarget",r.LaunchTarget,"--width",s.Width.ToString(),"--height",s.Height.ToString()];
        return args.ToArray();
    }
    public Process Launch(LauncherSettings s)
    {
        EnsureNotRunning();var r=Cached();var java=string.IsNullOrWhiteSpace(s.JavaPath)?OfficialBootstrap.Java(Runtime)??FindJava21():s.JavaPath;
        if(java==null||!File.Exists(java))throw new FileNotFoundException("Не найдена Java 21. Укажи путь к javaw.exe в настройках.");
        var args=BuildArguments(s,r);var path=PackUpdater.SafePath(Game,".arcane/launch.args");Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        File.WriteAllLines(path,args.Select(x=>"\""+x.Replace("\\","\\\\").Replace("\"","\\\"")+"\""));
        var start=new ProcessStartInfo(java){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=Game,RedirectStandardOutput=true,RedirectStandardError=true};start.ArgumentList.Add("@"+path);
        Directory.CreateDirectory(Path.Combine(Game,"logs"));var process=Process.Start(start)??throw new IOException("Minecraft не запустился");
        _=Pump(process.StandardOutput,Path.Combine(Game,"logs","launcher-out.log"));_=Pump(process.StandardError,Path.Combine(Game,"logs","launcher-error.log"));
        Data.Write(Active,new RunningGame(process.Id,process.StartTime.ToUniversalTime().Ticks));return process;
    }
    private static async Task Pump(StreamReader reader,string path){try{await using var file=new FileStream(path,FileMode.Create,FileAccess.Write,FileShare.ReadWrite);await reader.BaseStream.CopyToAsync(file);}catch(IOException){}catch(ObjectDisposedException){}}
    public static string? FindJava21()
    {
        var baseDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),".minecraft","runtime");
        var candidates=new List<string>();var home=Environment.GetEnvironmentVariable("JAVA_HOME");if(home!=null)candidates.Add(Path.Combine(home,"bin","javaw.exe"));
        foreach(var dir in new[]{baseDir,Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"Eclipse Adoptium"),Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"Java")})
            if(Directory.Exists(dir))candidates.AddRange(Directory.EnumerateFiles(dir,"javaw.exe",SearchOption.AllDirectories));
        foreach(var java in candidates.Distinct())try{using var p=Process.Start(new ProcessStartInfo(Path.Combine(Path.GetDirectoryName(java)!,"java.exe"),"-version"){UseShellExecute=false,CreateNoWindow=true,RedirectStandardError=true});if(p==null)continue;var version=p.StandardError.ReadToEnd();if(p.WaitForExit(5000)&&Regex.IsMatch(version,"version \"21[.\"]"))return java;}catch(System.ComponentModel.Win32Exception){}catch(IOException){}
        return null;
    }
}



