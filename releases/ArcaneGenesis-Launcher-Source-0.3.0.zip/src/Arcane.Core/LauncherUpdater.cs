using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;
namespace Arcane.Core;
public sealed record LauncherRelease(int Schema,string Version,string Url,string Sha256,long Size);
public static class LauncherUpdater
{
    private static Uri Address(string address)=>Uri.TryCreate(address,UriKind.Absolute,out var u)?u:new Uri(Path.GetFullPath(address));
    private static readonly HttpClient Http=new(){Timeout=TimeSpan.FromMinutes(15)};
    private static async Task<byte[]> Read(Uri uri,CancellationToken ct,int limit)
    {
        if(!uri.IsFile && uri.Scheme!="https")throw new InvalidDataException("HTTPS required");
        using var response=uri.IsFile?null:await Http.GetAsync(uri,HttpCompletionOption.ResponseHeadersRead,ct);response?.EnsureSuccessStatusCode();
        if(response!=null && response.RequestMessage?.RequestUri?.Scheme!="https")throw new InvalidDataException("Insecure redirect");
        await using var input=uri.IsFile?File.OpenRead(uri.LocalPath):await response!.Content.ReadAsStreamAsync(ct);
        using var output=new MemoryStream();var b=new byte[131072];int n;while((n=await input.ReadAsync(b,ct))>0){if(output.Length+n>limit)throw new InvalidDataException("Download too large");await output.WriteAsync(b.AsMemory(0,n),ct);}return output.ToArray();
    }
    public static async Task<LauncherRelease> Check(string channel,string key,CancellationToken ct=default)
    {
        using var deadline=CancellationTokenSource.CreateLinkedTokenSource(ct);deadline.CancelAfter(TimeSpan.FromSeconds(25));
        var address=Address(channel);var bytes=await Read(address,deadline.Token,1024*1024);var sig=await Read(new Uri(address.AbsoluteUri+".sig"),deadline.Token,4096);
        using var rsa=RSA.Create();rsa.ImportFromPem(key);if(!rsa.VerifyData(bytes,sig,HashAlgorithmName.SHA256,RSASignaturePadding.Pss))throw new CryptographicException("Invalid launcher signature");
        var r=JsonSerializer.Deserialize<LauncherRelease>(bytes,Data.Json)??throw new InvalidDataException("Empty launcher manifest");
        if(r.Schema!=1||!Version.TryParse(r.Version,out _)||r.Size<=0||r.Size>500*1024*1024||!System.Text.RegularExpressions.Regex.IsMatch(r.Sha256,"^[a-f0-9]{64}$"))throw new InvalidDataException("Invalid launcher manifest");
        var target=new Uri(address,r.Url);if(!address.IsFile && target.Scheme!="https")throw new InvalidDataException("Insecure installer source");return r;
    }
    public static async Task<string> Download(LauncherRelease release,string channel,string folder,CancellationToken ct=default)
    {
        var address=Address(channel);var uri=new Uri(address,release.Url);if(!address.IsFile && uri.Scheme!="https")throw new InvalidDataException("Insecure installer source");
        var bytes=await Read(uri,ct,checked((int)release.Size));
        if(bytes.LongLength!=release.Size||!Convert.ToHexString(SHA256.HashData(bytes)).Equals(release.Sha256,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("Installer checksum mismatch");
        Directory.CreateDirectory(folder);var target=Path.Combine(folder,"ArcaneGenesis-Setup-"+Version.Parse(release.Version)+".exe");
        await File.WriteAllBytesAsync(target+".partial",bytes,ct);File.Move(target+".partial",target,true);return target;
    }
}
