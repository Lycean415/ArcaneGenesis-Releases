using System.Windows;
namespace Arcane.Launcher;
public partial class App : System.Windows.Application
{
    private System.Threading.Mutex? mutex;
    protected override void OnStartup(StartupEventArgs e)
    {
        mutex=new System.Threading.Mutex(true,"Local\\ArcaneGenesisLauncher",out var created);
        if(!created){Shutdown();return;}
        DispatcherUnhandledException+=(s,a)=>{System.Windows.MessageBox.Show(a.Exception.Message,"Arcane Genesis");a.Handled=true;};
        base.OnStartup(e);
    }
    protected override void OnExit(ExitEventArgs e){mutex?.Dispose();base.OnExit(e);}
}
