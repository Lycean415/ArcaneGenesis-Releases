$ErrorActionPreference='Stop'
$tools=Join-Path $PSScriptRoot 'tools'
New-Item -ItemType Directory -Force $tools | Out-Null
if(!(Test-Path (Join-Path $tools 'dotnet10/dotnet.exe'))){
 Invoke-WebRequest 'https://dot.net/v1/dotnet-install.ps1' -OutFile (Join-Path $tools 'dotnet-install.ps1')
 & (Join-Path $tools 'dotnet-install.ps1') -Channel 10.0 -InstallDir (Join-Path $tools 'dotnet10') -NoPath
 if($LASTEXITCODE -ne 0){throw 'SDK installation failed'}
}
& (Join-Path $tools 'dotnet10/dotnet.exe') build (Join-Path $PSScriptRoot 'src/Arcane.Tools/Arcane.Tools.csproj') -c Release --nologo
if($LASTEXITCODE -ne 0){throw 'Build failed'}
Write-Output 'Tools ready. Create a private release key and a local pack channel before running build.ps1. See PUBLISHING.md.'
