$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$source=[Drawing.Image]::FromFile((Join-Path $PSScriptRoot 'assets/logo.png'))
$sizes=@(256,128,64,48,32,24,16)
$frames=@()
try{
 foreach($size in $sizes){
  $bitmap=[Drawing.Bitmap]::new($size,$size,[Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $graphics=[Drawing.Graphics]::FromImage($bitmap)
  $stream=[IO.MemoryStream]::new()
  try{
   $graphics.Clear([Drawing.Color]::Transparent)
   $graphics.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
   $graphics.PixelOffsetMode=[Drawing.Drawing2D.PixelOffsetMode]::HighQuality
   $graphics.CompositingQuality=[Drawing.Drawing2D.CompositingQuality]::HighQuality
   $scale=[Math]::Min($size/$source.Width,$size/$source.Height)
   $width=[single]($source.Width*$scale);$height=[single]($source.Height*$scale)
   $graphics.DrawImage($source,[Drawing.RectangleF]::new(($size-$width)/2,($size-$height)/2,$width,$height))
   $bitmap.Save($stream,[Drawing.Imaging.ImageFormat]::Png)
   $frames+=,@{size=$size;bytes=$stream.ToArray()}
  }finally{$stream.Dispose();$graphics.Dispose();$bitmap.Dispose()}
 }
 $file=[IO.File]::Create((Join-Path $PSScriptRoot 'assets/app.ico'))
 $writer=[IO.BinaryWriter]::new($file)
 try{
  $writer.Write([uint16]0);$writer.Write([uint16]1);$writer.Write([uint16]$frames.Count)
  $offset=6+16*$frames.Count
  foreach($frame in $frames){
   $dimension=if($frame.size -eq 256){0}else{$frame.size}
   $writer.Write([byte]$dimension);$writer.Write([byte]$dimension);$writer.Write([byte]0);$writer.Write([byte]0)
   $writer.Write([uint16]1);$writer.Write([uint16]32);$writer.Write([uint32]$frame.bytes.Length);$writer.Write([uint32]$offset)
   $offset+=$frame.bytes.Length
  }
  foreach($frame in $frames){$writer.Write([byte[]]$frame.bytes)}
 }finally{$writer.Dispose()}
}finally{$source.Dispose()}
Write-Output 'Created app.ico: 16, 24, 32, 48, 64, 128, 256 px, transparent PNG frames.'
