using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Arcane.Core;
using Brush=System.Windows.Media.Brush;
using Brushes=System.Windows.Media.Brushes;
using Color=System.Windows.Media.Color;
using MessageBox=System.Windows.MessageBox;
using Button=System.Windows.Controls.Button;
using TextBox=System.Windows.Controls.TextBox;
using CheckBox=System.Windows.Controls.CheckBox;
using TextBlock=System.Windows.Controls.TextBlock;

namespace Arcane.Launcher;

public partial class MainWindow : Window
{
    private LauncherSettings settings;
    private readonly string settingsPath;
    private PackManifest? manifest;
    private bool busy;
    private bool Ru => settings.Language=="ru";
    private string T(string ru,string en)=>Ru?ru:en;
    private NativeGameEngine Engine=>new(settings.InstallDirectory,settings.RuntimeChannel,settings.PublicKey);
    private string? effectiveChannel;
    private string BundledChannel=>Path.Combine(AppContext.BaseDirectory,"release","pack.json");
    private PackUpdater Updater=>new(Engine.Game,effectiveChannel??settings.Channel,settings.PublicKey,Path.Combine(AppContext.BaseDirectory,"release","objects"));
    private string InstalledPath=>Path.Combine(Engine.Game,".arcane","installed.json");
    private string? stateProblem;
    private InstalledState? ReadInstalled()
    {
        try{var state=InstalledCatalog.Read(Engine.Game,settings.PublicKey);stateProblem=null;return state;}
        catch(InvalidDataException error){stateProblem=error.Message;return null;}
        catch(Exception error) when(error is IOException or UnauthorizedAccessException){stateProblem=T("Не удалось прочитать служебные данные установки. Закрой игру и повтори проверку файлов.","Cannot read installation metadata. Close the game and retry file repair.");return null;}
    }
    private CancellationTokenSource cancel=new();
    private bool closeAfterOperation;
    public MainWindow()
    {
        InitializeComponent();
        var args=Environment.GetCommandLineArgs(); var i=Array.IndexOf(args,"--data-dir");
        var data=i>=0 && i+1<args.Length?Path.GetFullPath(args[i+1]):Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"ArcaneGenesis","Launcher");
        settingsPath=Path.Combine(data,"settings.json");
        var defaults=Path.Combine(AppContext.BaseDirectory,"channel.json");
        var baseSettings=Data.ReadSettings(defaults,new());
        settings=Data.ReadSettings(settingsPath,baseSettings);
        settings=DistributionSettings.Resolve(settings,baseSettings,AppContext.BaseDirectory);
        var logo=Path.Combine(AppContext.BaseDirectory,"assets","logo.png");
        if(File.Exists(logo)){LogoImage.Source=new BitmapImage(new Uri(logo));LogoImage.Visibility=Visibility.Visible;LogoPlaceholder.Visibility=Visibility.Collapsed;}
        settings.ProfileMode="local";
        if(string.IsNullOrWhiteSpace(settings.RuntimeChannel) && !string.IsNullOrWhiteSpace(settings.Channel)){var location=Uri.TryCreate(settings.Channel,UriKind.Absolute,out var uri)?uri:new Uri(Path.GetFullPath(settings.Channel));settings.RuntimeChannel=new Uri(location,"../runtime/runtime.json").AbsoluteUri;}
        Translate();
        Loaded+=async(_,_)=>await Run(Refresh);
        var previewIndex=Array.IndexOf(args,"--render-preview");
        if(previewIndex>=0 && previewIndex+1<args.Length) ContentRendered+=(_,_)=>
        {
            var visual=(FrameworkElement)Content;
            var bitmap=new RenderTargetBitmap((int)visual.ActualWidth,(int)visual.ActualHeight,96,96,PixelFormats.Pbgra32);
            bitmap.Render(visual);
            var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using var output=File.Create(args[previewIndex+1]);encoder.Save(output);
        };
        Closing+=(_,e)=>{if(busy){e.Cancel=true;closeAfterOperation=true;CancelOperation();}else {SaveProfile();Save();cancel.Cancel();}};
    }
    private void Save()=>Data.Write(settingsPath,settings);
    private void SaveProfile(){settings.ProfileMode="local";settings.Nickname=ProfileName.Text.Trim();}
    private void Translate()
    {
        SettingsButton.Content=T("Настройки","Settings");
        CancelButton.Content=T("Отмена","Cancel");
        ProfileName.Text=settings.Nickname;
        ProfileName.ToolTip=T("Ник игрока: 3–16 латинских букв, цифр или _","Player nickname: 3–16 letters, digits or _");
        UpdateLabels();
    }
    private void UpdateLabels()
    {
        var installed=ReadInstalled()?.Version;
        PlayButton.Content=new TextBlock{Text=stateProblem!=null||PackUpdater.HasPendingRecovery(Engine.Game)?T("ВОССТАНОВИТЬ","REPAIR"):installed==null?T("УСТАНОВИТЬ","INSTALL"):manifest!=null && installed!=manifest.Version?T("ОБНОВИТЬ","UPDATE"):T("ИГРАТЬ","PLAY"),Foreground=new SolidColorBrush(Color.FromRgb(24,19,33))};
        if(stateProblem!=null)StatusText.Text=stateProblem;
    }
    private async Task Refresh()
    {
        if(string.IsNullOrWhiteSpace(settings.Channel)){StatusText.Text=T("Укажи канал обновлений в настройках","Configure an update channel in settings");return;}
        effectiveChannel=null;
        try
        {
            manifest=await Updater.GetManifestAsync(cancel.Token);
            if(File.Exists(BundledChannel))
            {
                var bundled=await ReadBundled();
                if(bundled!=null)
                {
                    var order=ReleaseVersion.Compare(bundled.Version,manifest.Version);
                    if(bundled.Version==manifest.Version)
                    {
                        var same=PackUpdater.SameContents(bundled.Files,manifest.Files);
                        if(!same)throw new InvalidDataException("Встроенный и сетевой каталоги содержат разные файлы под одним номером версии. Установка остановлена.");
                    }
                    if(order>0||bundled.Version==manifest.Version){effectiveChannel=BundledChannel;manifest=bundled;}
                }
            }
            var current=ReadInstalled();
            if(current!=null&&ReleaseVersion.Compare(manifest.Version,current.Version)<0)
            {manifest=null;UpdateLabels();StatusText.Text=T("Канал предлагает старую версию. Сохранена установленная сборка.","Channel offers an older version. Installed pack preserved.");return;}
        }
        catch(Exception ex) when(!cancel.IsCancellationRequested && ex is System.Net.Http.HttpRequestException or FileNotFoundException or DirectoryNotFoundException or OperationCanceledException)
        {
            var current=ReadInstalled();var bundled=await ReadBundled();
            if(bundled!=null&&(current==null||ReleaseVersion.Compare(bundled.Version,current.Version)>=0))
            {effectiveChannel=BundledChannel;manifest=bundled;UpdateLabels();StatusText.Text=T("Канал недоступен. Используется проверенный каталог из установщика.","Channel unavailable. Using verified bundled catalog.");return;}
            if(current!=null)
            {
                manifest=null;UpdateLabels();StatusText.Text=T("Канал недоступен. Используется установленная версия.","Channel unavailable. Using installed version.");return;
            }
            throw;
        }
        UpdateLabels();StatusText.Text=T("Канал проверен. Готов к работе.","Channel verified. Ready.");
    }
    private async Task<PackManifest?> ReadBundled()
    {
        if(!File.Exists(BundledChannel))return null;
        try{return await new PackUpdater(Engine.Game,BundledChannel,settings.PublicKey).GetManifestAsync(cancel.Token);}
        catch(Exception error) when(error is System.Security.Cryptography.CryptographicException or InvalidDataException or System.Text.Json.JsonException or IOException or UnauthorizedAccessException){return null;}
    }
    private async Task Run(Func<Task> action)
    {
        if(busy)return;cancel.Dispose();cancel=new();busy=true;OperationPanel.Visibility=Visibility.Visible;
        Progress.Visibility=Visibility.Visible;Progress.Value=0;CancelButton.Visibility=Visibility.Visible;CancelButton.IsEnabled=true;ProfileName.IsEnabled=false;
        foreach(var b in new[]{PlayButton,SettingsButton})b.IsEnabled=false;
        try {await action();}
        catch(OperationCanceledException) when(cancel.IsCancellationRequested){StatusText.Text=T("Операция отменена. Проверенные загрузки сохранены для продолжения.","Operation cancelled. Verified downloads kept for retry.");}
        catch(Exception e){StatusText.Text=T("Операция не завершена: ","Operation failed: ")+e.Message;MessageBox.Show(e.Message,T("Arcane Genesis — операция не завершена","Arcane Genesis — operation failed"),MessageBoxButton.OK,MessageBoxImage.Warning);}
        finally{busy=false;Progress.Visibility=Visibility.Collapsed;CancelButton.Visibility=Visibility.Collapsed;ProfileName.IsEnabled=true;foreach(var b in new[]{PlayButton,SettingsButton})b.IsEnabled=true;if(closeAfterOperation)Close();}
    }
    private void CancelOperation(){CancelButton.IsEnabled=false;StatusText.Text=T("Завершается текущий шаг…","Finishing current step…");cancel.Cancel();}
    private void Cancel_Click(object sender,RoutedEventArgs e){if(busy)CancelOperation();}
    private IProgress<UpdateProgress> ProgressSink()
    {var operation=cancel;return new Progress<UpdateProgress>(p=>{if(!busy||!ReferenceEquals(cancel,operation)||operation.IsCancellationRequested)return;StatusText.Text=p.Message;Progress.Value=p.Percent;});}
    private async Task Install(bool repair=false)
    {
        SaveProfile();Save();
        Engine.EnsureNotRunning();
        var engine=Engine;var progress=ProgressSink();
        StatusText.Text=T("Проверяем Java и игровые файлы…","Checking Java and game files…");
        await Task.Run(()=>engine.EnsureAsync(progress,cancel.Token),cancel.Token);
        var updater=Updater;var result=repair?await updater.RepairAsync(ProgressSink(),cancel.Token):await updater.ApplyAsync(ProgressSink(),cancel.Token);
        manifest=updater.LastAppliedManifest??throw new InvalidDataException("Applied manifest missing");Engine.Configure(settings,manifest);
        UpdateLabels();StatusText.Text=T($"Готово: загружено {result.Downloaded}, без изменений {result.Unchanged}, личных настроек сохранено {result.Preserved}.",$"Done: downloaded {result.Downloaded}, unchanged {result.Unchanged}, custom settings preserved {result.Preserved}.");
    }
    private async void Play_Click(object sender,RoutedEventArgs e)=>await Run(async()=>
    {
        SaveProfile();Save();Engine.EnsureNotRunning();
        try{Updater.RecoverBeforeLaunch();}
        catch(RecoveryIncompleteException){await Refresh();await Install(repair:true);return;}
        if(settings.AutoUpdate || ReadInstalled()==null)
        {
            try{await Refresh();}
            catch(Exception ex) when(ReadInstalled()!=null && settings.ProfileMode=="local" && !cancel.IsCancellationRequested && ex is IOException or System.Net.Http.HttpRequestException or OperationCanceledException)
            {manifest=null;StatusText.Text=T("Канал недоступен. Используется установленная версия.","Channel unavailable. Using installed version.");}
        }
        var state=ReadInstalled();
        if(state==null || (settings.AutoUpdate && manifest!=null && state.Version!=manifest.Version)){await Install();return;}
        // Offline launch uses the last installed, previously signed version; never silently changes loader components.
        var m=manifest!=null && manifest.Version==state.Version?manifest:new PackManifest(1,state.Version,state.Minecraft,state.NeoForge,"",state.Files);
        var engine=Engine;var progress=ProgressSink();
        StatusText.Text=T("Проверяем Java и игровые файлы…","Checking Java and game files…");
        await Task.Run(()=>engine.EnsureAsync(progress,cancel.Token),cancel.Token);cancel.Token.ThrowIfCancellationRequested();engine.Configure(settings,m);
        StatusText.Text=T("Запускается Minecraft…","Starting Minecraft…");
        var process=await Task.Run(()=>{cancel.Token.ThrowIfCancellationRequested();return engine.Launch(settings);},cancel.Token);
        _=ObserveGame(process);
        StatusText.Text=T("Запускается Minecraft…","Starting Minecraft…");
        if(settings.Minimize)WindowState=WindowState.Minimized;
    });
    private async Task ObserveGame(Process process)
    {
        try
        {
            await process.WaitForExitAsync();
            if(Dispatcher.HasShutdownStarted)return;
            if(settings.Minimize && WindowState==WindowState.Minimized) {WindowState=WindowState.Normal;Activate();}
            if(process.ExitCode!=0) MessageBox.Show(T("Запуск игры завершился с ошибкой. Подробности находятся в logs/launcher-error.log и logs/latest.log профиля.","The game launch failed. See logs/launcher-error.log and logs/latest.log in the game profile."),"Arcane Genesis",MessageBoxButton.OK,MessageBoxImage.Warning);
        }
        catch(Exception ex) when(ex is InvalidOperationException or System.ComponentModel.Win32Exception){if(!Dispatcher.HasShutdownStarted)StatusText.Text=ex.Message;}
        finally{process.Dispose();}
    }
    private async void Repair_Click(object sender,RoutedEventArgs e)=>await Run(async()=>{await Refresh();await Install(repair:true);});
    private void Folder_Click(object sender,RoutedEventArgs e){Directory.CreateDirectory(Engine.Game);Process.Start(new ProcessStartInfo("explorer.exe"){ArgumentList={Engine.Game},UseShellExecute=true});}
    private async void LauncherUpdate_Click(object sender,RoutedEventArgs e)=>await Run(async()=>
    {
        if(string.IsNullOrWhiteSpace(settings.LauncherChannel)){MessageBox.Show(T("Канал обновлений лаунчера ещё не опубликован. Инструкция находится в комплекте исходников.","No launcher update channel configured. See the publishing guide."));return;}
        var release=await LauncherUpdater.Check(settings.LauncherChannel,settings.LauncherPublicKey,cancel.Token);
        if(Version.Parse(release.Version)<=LauncherBuild.Version){StatusText.Text=T("Установлена актуальная версия лаунчера.","Launcher is up to date.");return;}
        if(MessageBox.Show(T($"Доступна версия {release.Version}. Скачать установщик?",$"Version {release.Version} is available. Download installer?"),"Arcane Genesis",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;
        var file=await LauncherUpdater.Download(release,settings.LauncherChannel,Path.Combine(Path.GetDirectoryName(settingsPath)!,"updates"),cancel.Token);
        Process.Start(new ProcessStartInfo(file){UseShellExecute=true,ArgumentList={"--parent",Environment.ProcessId.ToString()}});busy=false;Close();
    });
    private void Settings_Click(object sender,RoutedEventArgs e)
    {
        SaveProfile();
        var w=new Window{Owner=this,Title=T("Настройки Arcane Genesis","Arcane Genesis settings"),Width=650,Height=720,WindowStartupLocation=WindowStartupLocation.CenterOwner,Background=(Brush)new BrushConverter().ConvertFromString("#151728")!,Foreground=Brushes.White};
        var panel=new System.Windows.Controls.StackPanel{Margin=new Thickness(24)};
        var scroll=new System.Windows.Controls.ScrollViewer{Content=panel,VerticalScrollBarVisibility=System.Windows.Controls.ScrollBarVisibility.Auto};w.Content=scroll;
        TextBox Field(string label,string value){panel.Children.Add(new TextBlock{Text=label,TextWrapping=TextWrapping.Wrap});var t=new TextBox{Text=value};panel.Children.Add(t);return t;}
        CheckBox Check(string label,bool value){var c=new CheckBox{Content=label,IsChecked=value};panel.Children.Add(c);return c;}
        var languageButton=new Button{Content=T("English","Русский")};languageButton.Click+=(_,_)=>{settings.Language=Ru?"en":"ru";Save();Translate();w.Close();Settings_Click(sender,e);};panel.Children.Add(languageButton);
        var tools=new System.Windows.Controls.WrapPanel();panel.Children.Add(tools);
        var repairButton=new Button{Content=T("Проверить файлы","Verify files")};repairButton.Click+=(s,a)=>{w.Close();Repair_Click(s,a);};tools.Children.Add(repairButton);
        var folderButton=new Button{Content=T("Папка игры","Game folder")};folderButton.Click+=Folder_Click;tools.Children.Add(folderButton);
        var updateButton=new Button{Content=T("Обновление лаунчера","Launcher update")};updateButton.Click+=(s,a)=>{w.Close();LauncherUpdate_Click(s,a);};tools.Children.Add(updateButton);
        var folder=Field(T("Отдельная папка установки (смена создаёт новую установку)","Separate install folder (changing creates a new installation)"),settings.InstallDirectory);
        var browse=new Button{Content=T("Выбрать папку","Browse folder")};browse.Click+=(_,_)=>{using var d=new System.Windows.Forms.FolderBrowserDialog{InitialDirectory=folder.Text};if(d.ShowDialog()==System.Windows.Forms.DialogResult.OK)folder.Text=d.SelectedPath;};panel.Children.Add(browse);
        var ram=Field(T("Оперативная память, МБ (по умолчанию 7168)","RAM, MB (default 7168)"),settings.MemoryMiB.ToString());
        var java=Field(T("Java 21 — путь к javaw.exe; пусто = автоматически","Java 21 javaw.exe path; empty = automatic"),settings.JavaPath);
        var width=Field(T("Ширина окна","Window width"),settings.Width.ToString());var height=Field(T("Высота окна","Window height"),settings.Height.ToString());
        var full=Check(T("Полноэкранный режим","Fullscreen"),settings.Fullscreen);var auto=Check(T("Автообновление сборки","Auto-update modpack"),settings.AutoUpdate);var mini=Check(T("Сворачивать после передачи запуска","Minimize after handing off launch"),settings.Minimize);
        var channel=Field(T("Манифест сборки (HTTPS или локальный путь)","Pack manifest (HTTPS or local path)"),settings.Channel);
        var runtime=Field(T("Среда Minecraft (официальная установка)","Local Minecraft runtime channel"),settings.RuntimeChannel);
        var lc=Field(T("Манифест лаунчера","Launcher manifest"),settings.LauncherChannel);
        var key=Field(T("Доверенный публичный ключ сборки (PEM)","Trusted pack public key (PEM)"),settings.PublicKey);key.AcceptsReturn=true;key.Height=85;
        var lk=Field(T("Доверенный публичный ключ лаунчера (PEM)","Trusted launcher public key (PEM)"),settings.LauncherPublicKey);lk.AcceptsReturn=true;lk.Height=85;
        var save=new Button{Content=T("Сохранить","Save")};panel.Children.Add(save);
        save.Click+=async(_,_)=>
        {
            if(!int.TryParse(ram.Text,out var mem)||mem<2048||mem>65536||!int.TryParse(width.Text,out var wi)||wi<640||wi>7680||!int.TryParse(height.Text,out var he)||he<480||he>4320){MessageBox.Show(T("Проверь память (2048–65536 МБ) и разрешение.","Check RAM (2048–65536 MB) and resolution."));return;}
            try{settings.InstallDirectory=Path.GetFullPath(folder.Text);settings.MemoryMiB=mem;settings.Width=wi;settings.Height=he;settings.JavaPath=java.Text.Trim();settings.Fullscreen=full.IsChecked==true;settings.AutoUpdate=auto.IsChecked==true;settings.Minimize=mini.IsChecked==true;settings.Channel=channel.Text.Trim();settings.LauncherChannel=lc.Text.Trim();settings.RuntimeChannel=runtime.Text.Trim();settings.PublicKey=key.Text;settings.LauncherPublicKey=lk.Text;Save();Translate();w.Close();await Run(Refresh);}catch(Exception ex){MessageBox.Show(ex.Message);}
        };w.ShowDialog();
    }
}






