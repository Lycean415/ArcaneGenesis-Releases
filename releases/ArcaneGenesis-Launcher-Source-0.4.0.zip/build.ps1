param([string]$Dotnet='',[string]$Output='',[switch]$SkipChannelSigning)
$ErrorActionPreference='Stop'
$launcherRoot=$PSScriptRoot
$projectRoot=Split-Path (Split-Path $launcherRoot -Parent) -Parent
$launcherVersion=([xml](Get-Content -LiteralPath (Join-Path $launcherRoot 'Directory.Build.props') -Raw)).Project.PropertyGroup.Version
$parsedVersion=$null
if(![Version]::TryParse($launcherVersion,[ref]$parsedVersion) -or $launcherVersion -notmatch '^\d+\.\d+\.\d+$'){throw 'Launcher version must contain three numeric components'}
if(!$Dotnet){$Dotnet=Join-Path $launcherRoot 'tools/dotnet10/dotnet.exe'}
if(!$Output){$Output=Join-Path $projectRoot ('outputs/ArcaneGenesis_Launcher_'+$launcherVersion)}
$Output=[IO.Path]::GetFullPath($Output)
$publish=Join-Path $launcherRoot 'publish-distribution'
& (Join-Path $launcherRoot 'make-icon.ps1')
& $Dotnet build (Join-Path $launcherRoot 'src/Arcane.Tools/Arcane.Tools.csproj') -c Release --nologo
if($LASTEXITCODE -ne 0){throw 'Tools build failed'}
$tool=Join-Path $launcherRoot 'src/Arcane.Tools/bin/Release/net10.0-windows/Arcane.Tools.dll'
& $Dotnet $tool clean-build $launcherRoot
if($LASTEXITCODE -ne 0){throw 'Generated publish directory could not be safely cleared'}
& $Dotnet publish (Join-Path $launcherRoot 'src/Arcane.Launcher/Arcane.Launcher.csproj') -c Release -r win-x64 --self-contained true -o $publish --nologo
if($LASTEXITCODE -ne 0){throw 'Publish failed'}
# Do not overwrite saved user settings. These are defaults for fresh installations only.
$keyPath=Join-Path $launcherRoot 'release-public.pem'
if(!(Test-Path $keyPath)){$keyPath=Join-Path $launcherRoot 'private/release-public.pem'}
$key=Get-Content -LiteralPath $keyPath -Raw
$settings=@{installDirectory='' ;channel='https://raw.githubusercontent.com/Lycean415/ArcaneGenesis-Releases/main/channels/pack/pack.json';launcherChannel='https://raw.githubusercontent.com/Lycean415/ArcaneGenesis-Releases/main/channels/launcher/launcher.json';language='ru';runtimeChannel='official:1.21.1-neoforge-21.1.265';profileMode='local';nickname='';microsoftProfile='';memoryMiB=7168;width=1280;height=720;fullscreen=$false;autoUpdate=$true;minimize=$true;javaPath='';publicKey=$key;launcherPublicKey=$key}
if(!(Test-Path (Join-Path $launcherRoot 'distribution/release/pack.json'))){throw 'Build the verified distribution manifest first'}
Copy-Item -LiteralPath (Join-Path $launcherRoot 'distribution/release') -Destination $publish -Recurse -Force
$releaseObjects=[IO.Path]::GetFullPath((Join-Path $publish 'release/objects'))
$manifest=Get-Content -LiteralPath (Join-Path $publish 'release/pack.json') -Raw | ConvertFrom-Json
$referenced=@($manifest.files | Where-Object {$_.url.StartsWith('objects/')} | ForEach-Object {$_.url.Substring(8)})
foreach($object in Get-ChildItem -LiteralPath $releaseObjects -File){
 if(!$object.FullName.StartsWith($releaseObjects+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe generated object path'}
 if($object.Name -notin $referenced){Remove-Item -LiteralPath $object.FullName}
}
$settings | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $publish 'channel.json') -Encoding utf8
New-Item -ItemType Directory -Force $Output,(Join-Path $publish 'assets') | Out-Null
Copy-Item -LiteralPath (Join-Path $launcherRoot 'assets/logo.png') -Destination (Join-Path $publish 'assets/logo.png') -Force
Copy-Item -LiteralPath (Join-Path $launcherRoot 'assets/app.ico') -Destination (Join-Path $publish 'assets/app.ico') -Force
Copy-Item -LiteralPath (Join-Path $launcherRoot 'LICENSE.txt'),(Join-Path $launcherRoot 'THIRD_PARTY_NOTICES.txt') -Destination $publish -Force
if(Test-Path (Join-Path $launcherRoot 'tools/dotnet10/LICENSE.txt')){Copy-Item -LiteralPath (Join-Path $launcherRoot 'tools/dotnet10/LICENSE.txt') -Destination (Join-Path $publish 'DOTNET_LICENSE.txt') -Force}
if(Test-Path (Join-Path $launcherRoot 'tools/dotnet10/ThirdPartyNotices.txt')){Copy-Item -LiteralPath (Join-Path $launcherRoot 'tools/dotnet10/ThirdPartyNotices.txt') -Destination (Join-Path $publish 'DOTNET_THIRD_PARTY_NOTICES.txt') -Force}
$csc=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$refs=@('/nologo','/target:winexe','/optimize+','/reference:System.Windows.Forms.dll','/reference:System.Drawing.dll','/reference:System.Core.dll','/reference:System.IO.Compression.dll','/reference:System.IO.Compression.FileSystem.dll','/reference:Microsoft.CSharp.dll')
$refs+=('/win32icon:'+(Join-Path $launcherRoot 'assets/app.ico'))
$uninstall=Join-Path $publish 'ArcaneGenesis-Uninstall.exe'
& $csc @refs "/out:$uninstall" (Join-Path $launcherRoot 'installer/Setup.cs')
if($LASTEXITCODE -ne 0){throw 'Uninstaller compilation failed'}
Get-ChildItem -LiteralPath $publish -Recurse -File -Filter '*.pdb' | ForEach-Object {Remove-Item -LiteralPath $_.FullName}
$catalog=Get-ChildItem -LiteralPath $publish -Recurse -File | Where-Object {$_.Name -ne 'payload-sha256.txt' -and $_.Extension -ne '.pdb'} | ForEach-Object { (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()+'  '+[IO.Path]::GetRelativePath($publish,$_.FullName).Replace('\','/') }
$catalog | Set-Content -LiteralPath (Join-Path $publish 'payload-sha256.txt') -Encoding utf8
Add-Type -AssemblyName System.IO.Compression.FileSystem
$payload=Join-Path $launcherRoot ('launcher-payload-'+[Guid]::NewGuid().ToString('N')+'.zip')
$installer=Join-Path $Output ('ArcaneGenesis-Setup-'+$launcherVersion+'.exe')
try {
 [IO.Compression.ZipFile]::CreateFromDirectory($publish,$payload,[IO.Compression.CompressionLevel]::Optimal,$false)
 & $csc @refs "/out:$installer" "/resource:$payload,launcher.zip" (Join-Path $launcherRoot 'installer/Setup.cs')
 if($LASTEXITCODE -ne 0){throw 'Setup compilation failed'}
} finally {
 # Only this uniquely named generated archive is removed, including failed builds.
 if(Test-Path -LiteralPath $payload){Remove-Item -LiteralPath $payload}
}
Copy-Item -LiteralPath (Join-Path $launcherRoot 'README.md'),(Join-Path $launcherRoot 'PUBLISHING.md'),(Join-Path $launcherRoot 'TESTING.md') -Destination $Output -Force
(Get-FileHash -LiteralPath $installer -Algorithm SHA256).Hash.ToLowerInvariant() | Set-Content -LiteralPath ($installer+'.sha256') -Encoding ascii
$tool=Join-Path $launcherRoot 'src/Arcane.Tools/bin/Release/net10.0-windows/Arcane.Tools.dll'
if(!$SkipChannelSigning){
& $Dotnet $tool launcher-channel (Join-Path $projectRoot 'outputs/ArcaneGenesis_Local_Channel/launcher') $installer $launcherVersion (Join-Path $launcherRoot 'private/release-private.pem')
if($LASTEXITCODE -ne 0){throw 'Launcher manifest failed'}
}
Get-Item -LiteralPath $installer | Select-Object Name,Length









