$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Add-Type -AssemblyName System.IO.Compression.FileSystem
[xml]$properties=Get-Content -LiteralPath (Join-Path $root 'Directory.Build.props') -Raw
$version=[string]$properties.Project.PropertyGroup.Version
if($version -notmatch '^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$'){throw 'Invalid source version'}
$zipPath=Join-Path $root ('distribution/ArcaneGenesis-Launcher-Source-'+$version+'.zip')
if(Test-Path $zipPath){Remove-Item -LiteralPath $zipPath}
$zip=[IO.Compression.ZipFile]::Open($zipPath,[IO.Compression.ZipArchiveMode]::Create)
try {
 $top='build.ps1','bootstrap.ps1','make-icon.ps1','prepare-source.ps1','Directory.Build.props','global.json','LICENSE.txt','THIRD_PARTY_NOTICES.txt','README.md','TESTING.md','PUBLISHING.md','release-public.pem'
 $files=@($top | ForEach-Object {Get-Item -LiteralPath (Join-Path $root $_)})
 $files+=@(Get-ChildItem (Join-Path $root 'src') -Recurse -File | Where-Object {$_.FullName -notmatch '[\\/](bin|obj)[\\/]'})
 foreach($dir in 'assets','installer','distribution/release'){$files+=@(Get-ChildItem (Join-Path $root $dir) -Recurse -File)}
 foreach($f in $files){
  $rel=[IO.Path]::GetRelativePath($root,$f.FullName).Replace('\','/')
  if($rel -match '(^|/)(private|backup|tools|bin|obj)/' -or $rel -match 'release-private|runtime-test'){throw 'Private source rejected'}
  [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,$rel,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
 }
}finally{$zip.Dispose()}
Get-Item $zipPath | Select-Object Name,Length
