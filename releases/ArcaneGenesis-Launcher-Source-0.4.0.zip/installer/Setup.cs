using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

internal static class Setup
{
    const string RegPath=@"Software\Microsoft\Windows\CurrentVersion\Uninstall\ArcaneGenesisLauncher";
    [STAThread] static void Main(string[] args)
    {
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        if(!Environment.Is64BitOperatingSystem){MessageBox.Show("Нужна 64-битная Windows 10/11.","Arcane Genesis");return;}
        if(args.Contains("--uninstall") && !args.Contains("--from-temp"))
        {
            var copy=Path.Combine(Path.GetTempPath(),"ArcaneGenesis-Uninstall-"+Guid.NewGuid().ToString("N")+".exe");File.Copy(Assembly.GetExecutingAssembly().Location,copy);
            var root=NormalizeRoot(AppDomain.CurrentDomain.BaseDirectory);
            var command="--uninstall --from-temp --parent "+Process.GetCurrentProcess().Id+" --dir \""+root+"\""+(args.Contains("--silent")?" --silent":"")+(args.Contains("--portable-test")?" --portable-test":"");
            Process.Start(new ProcessStartInfo(copy,command){UseShellExecute=false});return;
        }
        var parentIndex=Array.IndexOf(args,"--parent");if(parentIndex>=0){int parentId;if(parentIndex+1>=args.Length||!int.TryParse(args[parentIndex+1],out parentId)||parentId<=0){MessageBox.Show("Некорректный идентификатор предыдущего процесса");Environment.ExitCode=1;return;}try{using(var parent=Process.GetProcessById(parentId))if(!parent.WaitForExit(30000)){MessageBox.Show("Предыдущий лаунчер ещё не закрылся");Environment.ExitCode=1;return;}}catch(ArgumentException){}}
        var form=new Form{Text="Arcane Genesis — установка",Width=620,Height=390,StartPosition=FormStartPosition.CenterScreen,FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,BackColor=Color.FromArgb(18,21,35),ForeColor=Color.FromArgb(232,223,203)};
        form.Icon=Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
        bool removing=args.Contains("--uninstall"),busy=false;
        var title=new Label{Text="ARCANE GENESIS",Font=new Font("Georgia",23),AutoSize=true,Left=30,Top=25};form.Controls.Add(title);
        var caption=new Label{Text=removing?"Удаление лаунчера. Миры, сборка и профили останутся на месте.":"Лаунчер для Minecraft 1.21.1 · NeoForge\nУстановка для текущего пользователя, без прав администратора.",Left=30,Top=80,Width=550,Height=48};form.Controls.Add(caption);
        var folder=new TextBox{Text=removing?AppDomain.CurrentDomain.BaseDirectory:Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Programs","ArcaneGenesisLauncher"),Left=30,Top=142,Width=450,Enabled=!removing};form.Controls.Add(folder);
        var browse=new Button{Text="Обзор…",Left=485,Top=140,Width=88,Enabled=!removing};browse.Click+=(s,e)=>{using(var dialog=new FolderBrowserDialog()){if(dialog.ShowDialog()==DialogResult.OK)folder.Text=dialog.SelectedPath;}};form.Controls.Add(browse);
        var note=new Label{Text="Локальный тестовый выпуск. Оригинальный логотип включён.\nMinecraft и модпак устанавливаются отдельно при первом запуске.",Left=30,Top=183,Width=545,Height=45};form.Controls.Add(note);
        var progress=new ProgressBar{Left=30,Top=237,Width=543,Height=12};form.Controls.Add(progress);
        var status=new Label{Left=30,Top=258,Width=540,Height=25,Text="Готово к установке"};form.Controls.Add(status);
        var button=new Button{Text=removing?"Удалить лаунчер":"Установить",Left=397,Top=293,Width=176,Height=35,BackColor=Color.FromArgb(217,187,121),ForeColor=Color.FromArgb(20,18,30),FlatStyle=FlatStyle.Flat};form.Controls.Add(button);
        form.FormClosing+=(s,e)=>{if(busy)e.Cancel=true;};
        var silent=args.Contains("--silent");var dirArg=Array.IndexOf(args,"--dir");if(dirArg>=0&&dirArg+1<args.Length)folder.Text=args[dirArg+1];
        button.Click+=(s,e)=>
        {
            if(button.Tag!=null){form.Close();return;}
            string target;try{target=NormalizeRoot(folder.Text);}catch(Exception ex){status.Text=ex.Message;if(silent){Environment.ExitCode=1;form.Close();}return;}
            if(removing && !silent && MessageBox.Show(form,"Удалить только файлы лаунчера? Сборка и сохранения останутся.","Arcane Genesis",MessageBoxButtons.YesNo)!=DialogResult.Yes)return;
            busy=true;button.Enabled=false;browse.Enabled=false;folder.Enabled=false;
            var worker=new BackgroundWorker{WorkerReportsProgress=true};worker.ProgressChanged+=(ss,ee)=>{progress.Value=ee.ProgressPercentage;status.Text=Convert.ToString(ee.UserState);};
            worker.DoWork+=(ss,ee)=>{if(removing)Uninstall(target,worker,!args.Contains("--portable-test"));else Install(target,worker,!args.Contains("--portable-test"));};
            worker.RunWorkerCompleted+=(ss,ee)=>
            {
                busy=false;button.Enabled=true;
                if(ee.Error!=null){status.Text="Ошибка: "+ee.Error.Message;if(silent){Environment.ExitCode=1;form.Close();}else MessageBox.Show(form,ee.Error.Message,"Установка не завершена");return;}
                progress.Value=100;status.Text=removing?"Лаунчер удалён. Игровые данные сохранены.":"Лаунчер установлен. Ярлык создан на рабочем столе.";button.Text="Закрыть";button.Tag=true;if(silent)form.Close();
            };worker.RunWorkerAsync();
        };
        if(silent){form.Opacity=0;form.ShowInTaskbar=false;form.Shown+=(s,e)=>button.PerformClick();}
        Application.Run(form);
    }
    static string NormalizeRoot(string path){var full=Path.GetFullPath(path);if(full.Contains(";"))throw new IOException("Выбери папку без точки с запятой (;)");if(full.StartsWith(@"\\",StringComparison.Ordinal)||string.Equals(full.TrimEnd(Path.DirectorySeparatorChar),Path.GetPathRoot(full).TrimEnd(Path.DirectorySeparatorChar),StringComparison.OrdinalIgnoreCase))throw new IOException("Выбери отдельную локальную папку для лаунчера");return full.TrimEnd(Path.DirectorySeparatorChar);}
    static void Writable(string path){if(File.Exists(path))File.SetAttributes(path,File.GetAttributes(path)&~FileAttributes.ReadOnly);}
    static void CopyReplace(string source,string dest){Writable(dest);File.Copy(source,dest,true);}
    static void Backup(string root,string backup,string rel,List<Tuple<string,bool>> applied){if(applied.Any(x=>string.Equals(x.Item1,rel,StringComparison.OrdinalIgnoreCase)))return;var dest=Safe(root,rel);bool existed=File.Exists(dest);if(existed){var old=Safe(backup,rel);Directory.CreateDirectory(Path.GetDirectoryName(old));File.Copy(dest,old);}applied.Add(Tuple.Create(rel,existed));}
    static string Hash(string file){using(var sha=SHA256.Create())using(var stream=File.OpenRead(file))return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","").ToLowerInvariant();}
    static string Safe(string root,string rel)
    {
        if(string.IsNullOrEmpty(rel)||rel.Contains("..")||rel.Contains(":")||rel.StartsWith("/")||rel.StartsWith("\\"))throw new IOException("Недопустимый путь установщика");
        var top=rel.Replace('\\','/').Split('/')[0];if(new[]{"saves","screenshots","game","runtime","prism",".minecraft","mods","config","global_packs","resourcepacks","options.txt","servers.dat","usercache.json","settings.json"}.Contains(top,StringComparer.OrdinalIgnoreCase))throw new IOException("Установщик не изменяет игровые и личные данные");
        var dest=Path.GetFullPath(Path.Combine(root,rel));var prefix=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;
        if(!dest.StartsWith(prefix,StringComparison.OrdinalIgnoreCase))throw new IOException("Путь вне папки установки");
        for(string p=dest;p!=null;p=Path.GetDirectoryName(p)){if((File.Exists(p)||Directory.Exists(p))&&(File.GetAttributes(p)&FileAttributes.ReparsePoint)!=0)throw new IOException("Выбери папку без символических ссылок");if(p.Length<prefix.Length)break;}
        return dest;
    }
    static void CheckIdle(string root)
    {
        foreach(var process in Process.GetProcessesByName("ArcaneGenesisLauncher"))using(process)
        {try{if(string.Equals(process.MainModule.FileName,Path.Combine(root,"ArcaneGenesisLauncher.exe"),StringComparison.OrdinalIgnoreCase))throw new IOException("Закрой лаунчер перед установкой или обновлением.");}catch(InvalidOperationException){}catch(Win32Exception){throw new IOException("Не удалось проверить запуск лаунчера. Закрой его перед установкой.");}}
    }
    static void Install(string root,BackgroundWorker worker,bool integrate)
    {
        CheckIdle(root);Safe(root,"setup-files.txt");Directory.CreateDirectory(root);
        string stage=Safe(root,".setup-stage-"+Guid.NewGuid().ToString("N")),backup=Safe(root,".setup-backup-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(stage);Directory.CreateDirectory(backup);
        var files=new List<string>();var applied=new List<Tuple<string,bool>>();bool retainBackup=false;
        try
        {
            using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("launcher.zip"))
            using(var zip=new ZipArchive(stream,ZipArchiveMode.Read))
            {int index=0;foreach(var entry in zip.Entries){if(entry.FullName.EndsWith("/"))continue;var dest=Safe(stage,entry.FullName);Directory.CreateDirectory(Path.GetDirectoryName(dest));entry.ExtractToFile(dest);files.Add(entry.FullName);worker.ReportProgress(++index*65/zip.Entries.Count,"Распаковка файлов…");}}
            if(!File.Exists(Path.Combine(stage,"ArcaneGenesisLauncher.exe")))throw new IOException("В архиве нет лаунчера");
            // The checksum catalog travels inside the embedded archive; an incomplete payload is never committed.
            var catalogFiles=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach(var line in File.ReadAllLines(Path.Combine(stage,"payload-sha256.txt")))
            {var split=line.IndexOf("  ",StringComparison.Ordinal);if(split!=64)throw new IOException("Повреждён каталог файлов");if(!catalogFiles.Add(line.Substring(66)))throw new IOException("Повтор файла в каталоге");if(Hash(Safe(stage,line.Substring(66)))!=line.Substring(0,64))throw new IOException("Контрольная сумма не совпадает");}
            catalogFiles.Add("payload-sha256.txt");if(catalogFiles.Count!=files.Count || !catalogFiles.SetEquals(files))throw new IOException("Список файлов архива не совпадает с каталогом");
            if(files.Contains("setup-files.txt",StringComparer.OrdinalIgnoreCase))throw new IOException("Архив не должен содержать служебный список установки");
            var catalogPath=Safe(root,"setup-files.txt");var prior=File.Exists(catalogPath)?File.ReadAllLines(catalogPath):new string[0];foreach(var rel in prior)Safe(root,rel);
            foreach(var rel in prior.Except(files,StringComparer.OrdinalIgnoreCase)){Backup(root,backup,rel,applied);var dest=Safe(root,rel);if(File.Exists(dest)){Writable(dest);File.Delete(dest);}}
            foreach(var rel in files){Backup(root,backup,rel,applied);var dest=Safe(root,rel);Directory.CreateDirectory(Path.GetDirectoryName(dest));CopyReplace(Safe(stage,rel),dest);}
            Backup(root,backup,"setup-files.txt",applied);Writable(catalogPath);File.WriteAllLines(catalogPath,files);
            if(integrate){
            var shortcut=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"Arcane Genesis.lnk");CreateShortcut(shortcut,Path.Combine(root,"ArcaneGenesisLauncher.exe"));
            var menu=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs),"Arcane Genesis");Directory.CreateDirectory(menu);CreateShortcut(Path.Combine(menu,"Arcane Genesis.lnk"),Path.Combine(root,"ArcaneGenesisLauncher.exe"));
            using(var key=Registry.CurrentUser.CreateSubKey(RegPath)){key.SetValue("DisplayName","Arcane Genesis Launcher");key.SetValue("DisplayVersion",FileVersionInfo.GetVersionInfo(Path.Combine(root,"ArcaneGenesisLauncher.exe")).ProductVersion.Split('+')[0]);key.SetValue("Publisher","Arcane Genesis");key.SetValue("InstallLocation",root);key.SetValue("UninstallString","\""+Path.Combine(root,"ArcaneGenesis-Uninstall.exe")+"\" --uninstall");key.SetValue("NoModify",1);key.SetValue("NoRepair",1);}
            }
            worker.ReportProgress(100,"Установка завершена");
        }
        catch(Exception failure){var errors=new List<Exception>{failure};foreach(var op in applied.AsEnumerable().Reverse()){try{var dest=Safe(root,op.Item1);if(op.Item2)CopyReplace(Safe(backup,op.Item1),dest);else if(File.Exists(dest)){Writable(dest);File.Delete(dest);}}catch(Exception restore){errors.Add(restore);}}if(errors.Count>1){retainBackup=true;throw new IOException("Откат не завершён. Резервная копия сохранена: "+backup,new AggregateException(errors));}throw;}
        finally{try{if(Directory.Exists(stage))Directory.Delete(stage,true);}catch(IOException){}catch(UnauthorizedAccessException){}if(!retainBackup)try{if(Directory.Exists(backup))Directory.Delete(backup,true);}catch(IOException){}catch(UnauthorizedAccessException){}}
    }
    static void CreateShortcut(string path,string target)
    {var type=Type.GetTypeFromProgID("WScript.Shell");dynamic shell=Activator.CreateInstance(type);dynamic link=shell.CreateShortcut(path);link.TargetPath=target;link.IconLocation=target+",0";link.WorkingDirectory=Path.GetDirectoryName(target);link.Description="Arcane Genesis Launcher";link.Save();}
    static void Uninstall(string root,BackgroundWorker worker,bool integrate)
    {
        CheckIdle(root);var catalog=Path.Combine(root,"setup-files.txt");if(!File.Exists(catalog))throw new IOException("Не найден список установленных файлов");
        var installedFiles=File.ReadAllLines(catalog);foreach(var rel in installedFiles)Safe(root,rel);
        foreach(var rel in installedFiles){var file=Safe(root,rel);if(string.Equals(file,Assembly.GetExecutingAssembly().Location,StringComparison.OrdinalIgnoreCase))continue;if(File.Exists(file)){Writable(file);File.Delete(file);}}
        // Only explicitly installed files are removed. Never recursively delete the installation/game directory.
        if(integrate){foreach(var link in new[]{Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"Arcane Genesis.lnk"),Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs),"Arcane Genesis","Arcane Genesis.lnk")})if(File.Exists(link))File.Delete(link);
        Registry.CurrentUser.DeleteSubKeyTree(RegPath,false);}Writable(catalog);File.Delete(catalog);worker.ReportProgress(100,"Игровые данные сохранены");
    }
}






