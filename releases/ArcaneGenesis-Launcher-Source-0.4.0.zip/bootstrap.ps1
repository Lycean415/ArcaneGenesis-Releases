param([switch]$PrepareOnly)
$ErrorActionPreference='Stop'
$tools=Join-Path $PSScriptRoot 'tools'
New-Item -ItemType Directory -Force $tools | Out-Null
$sdkVersion='10.0.404'
# Pinned from Microsoft's official .NET 10 release metadata; no downloaded script is executed.
$sdkUrl='https://builds.dotnet.microsoft.com/dotnet/Sdk/10.0.404/dotnet-sdk-10.0.404-win-x64.zip'
$sdkHash='330ddd2665b43cd2e428216a0d8ea1ac7bb19b5434fdc530e62010dc3b52823a620bf95489d628e1ed6f5122401793ee4887cca4a019122361a1231497f632ee'
$sdkRoot=Join-Path $tools 'dotnet10'
$dotnet=Join-Path $sdkRoot 'dotnet.exe'
if(!(Test-Path -LiteralPath $dotnet)){
 $zip=Join-Path $tools ('dotnet-sdk-'+$sdkVersion+'-win-x64.zip')
 if(!(Test-Path -LiteralPath $zip) -or (Get-FileHash -LiteralPath $zip -Algorithm SHA512).Hash.ToLowerInvariant() -ne $sdkHash){
  $partial=$zip+'.partial'
  Invoke-WebRequest -Uri $sdkUrl -OutFile $partial -TimeoutSec 600
  if((Get-FileHash -LiteralPath $partial -Algorithm SHA512).Hash.ToLowerInvariant() -ne $sdkHash){throw 'SDK checksum mismatch; downloaded code was not executed'}
  Move-Item -LiteralPath $partial -Destination $zip -Force
 }
 $stage=Join-Path $tools ('dotnet-stage-'+[Guid]::NewGuid().ToString('N'))
 Expand-Archive -LiteralPath $zip -DestinationPath $stage
 if(!(Test-Path -LiteralPath (Join-Path $stage 'dotnet.exe'))){throw 'SDK archive is incomplete'}
 if(Test-Path -LiteralPath $sdkRoot){Move-Item -LiteralPath $sdkRoot -Destination (Join-Path $tools ('dotnet-rejected-'+[Guid]::NewGuid().ToString('N')))}
 Move-Item -LiteralPath $stage -Destination $sdkRoot
}
$version=(& $dotnet --version | Out-String).Trim()
if($LASTEXITCODE -ne 0 -or $version -ne $sdkVersion){throw ('Required .NET SDK '+$sdkVersion+'; found '+$version)}
if($PrepareOnly){Write-Output ('SDK '+$sdkVersion+' ready');return}
& $dotnet build (Join-Path $PSScriptRoot 'src/Arcane.Tools/Arcane.Tools.csproj') -c Release --nologo
if($LASTEXITCODE -ne 0){throw 'Build failed'}
Write-Output 'Tools ready. build.ps1 uses the audited distribution and public key. See PUBLISHING.md.'

