using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using Arcane.Core;

static string Full(string p)=>Path.GetFullPath(p);
static void Sign(string path,RSA key)=>File.WriteAllBytes(path+".sig",key.SignData(File.ReadAllBytes(path),HashAlgorithmName.SHA256,RSASignaturePadding.Pss));
try
{
if(args.Length==0)throw new ArgumentException("Commands: keygen, channel, launcher-channel, smoke, tests");
switch(args[0])
{
case "keygen":
{
    var dir=Full(args[1]);Directory.CreateDirectory(dir);
    if(File.Exists(Path.Combine(dir,"release-private.pem")))throw new IOException("Key already exists");
    using var rsa=RSA.Create(3072);File.WriteAllText(Path.Combine(dir,"release-private.pem"),rsa.ExportPkcs8PrivateKeyPem());File.WriteAllText(Path.Combine(dir,"release-public.pem"),rsa.ExportSubjectPublicKeyInfoPem());break;
}
case "channel":
{
    var source=Full(args[1]);var output=Full(args[2]);Directory.CreateDirectory(output);
    using var rsa=RSA.Create();rsa.ImportFromPem(File.ReadAllText(args[4]));
    var files=new List<PackFile>();
    foreach(var file in Directory.EnumerateFiles(source,"*",SearchOption.AllDirectories).OrderBy(x=>x,StringComparer.Ordinal))
    {
        var path=Path.GetRelativePath(source,file).Replace('\\','/');var hash=PackUpdater.Hash(file);var rel="objects/"+hash;
        var target=PackUpdater.SafePath(output,rel);Directory.CreateDirectory(Path.GetDirectoryName(target)!);if(!File.Exists(target))File.Copy(file,target);
        var policy=(path.StartsWith("config/") && !path.StartsWith("config/ftbquests/quests/") && path!="config/global_packs.toml") || path.StartsWith("defaultconfigs/")?"seed":"managed";
        files.Add(new PackFile(path,rel,hash,new FileInfo(file).Length,policy,"local-owned-profile; publication requires source/license audit"));
    }
    var manifest=new PackManifest(1,args[3],"1.21.1","21.1.265","Arcane Genesis · Ranger Alpha\nЧетыре класса, 12 специализаций, 256 талантов. Кампания: 654 квеста, 70 глав.\nБаланс предварительный. Выделенный сервер и полное прохождение ещё требуют испытаний.",files);
    PackUpdater.Validate(manifest);var pathOut=Path.Combine(output,"pack.json");Data.Write(pathOut,manifest);Sign(pathOut,rsa);File.WriteAllText(Path.Combine(output,"release-public.pem"),rsa.ExportSubjectPublicKeyInfoPem());
    Console.WriteLine(JsonSerializer.Serialize(new{files=files.Count,bytes=files.Sum(f=>f.Size),manifest=pathOut},Data.Json));break;
}
case "launcher-channel":
{
    using var rsa=RSA.Create();rsa.ImportFromPem(File.ReadAllText(args[4]));
    var output=Full(args[1]);Directory.CreateDirectory(output);var installer=Full(args[2]);var file=Path.Combine(output,"ArcaneGenesis-Setup-"+args[3]+".exe");if(installer!=file)File.Copy(installer,file,true);
    var path=Path.Combine(output,"launcher.json");Data.Write(path,new LauncherRelease(1,args[3],Path.GetFileName(file),PackUpdater.Hash(file),new FileInfo(file).Length));Sign(path,rsa);break;
}
case "sign":
{
    using var rsa=RSA.Create();rsa.ImportFromPem(File.ReadAllText(args[2]));Sign(Full(args[1]),rsa);break;
}
case "official-smoke":
{
    var engine=new NativeGameEngine(Full(args[1]),OfficialBootstrap.Channel,"");
    await engine.EnsureAsync(new Progress<UpdateProgress>(p=>Console.WriteLine(p.Message)));
    Console.WriteLine("Official runtime ready: "+engine.Runtime);
    if(args.Length>=4)
    {
        var publicKey=File.ReadAllText(args[3]);var updater=new PackUpdater(engine.Game,Full(args[2]),publicKey);
        var installed=await updater.ApplyAsync(new Progress<UpdateProgress>(p=>Console.WriteLine(p.Message)));
        Data.Write(Path.Combine(engine.Root,"pack-install-report.json"),installed);
        var m=updater.LastAppliedManifest??throw new InvalidDataException("Applied manifest missing");
        var settings=new LauncherSettings{Nickname="ArcaneTester",MemoryMiB=7168};engine.Configure(settings,m);
        if(args.Contains("--launch"))
        {
            using var game=engine.Launch(settings);Data.Write(Path.Combine(engine.Root,"game-process.json"),new{pid=game.Id});
            Console.WriteLine("Game PID: "+game.Id);await game.WaitForExitAsync();Console.WriteLine("Game exit: "+game.ExitCode);
            Environment.ExitCode=game.ExitCode;
        }
    }
    break;
}
case "native-smoke":
{
    var pack=Full(args[1]);var key=File.ReadAllText(Path.Combine(Path.GetDirectoryName(pack)!,"release-public.pem"));
    var runtime=Full(args[2]);var engine=new NativeGameEngine(Full(args[3]),runtime,key);
    await engine.EnsureAsync();var updater=new PackUpdater(engine.Game,pack,key);var result=await updater.ApplyAsync();var manifest=await updater.GetManifestAsync();
    var settings=new LauncherSettings{InstallDirectory=engine.Root,RuntimeChannel=runtime,Channel=pack,PublicKey=key,Nickname="ArcaneTester",Minimize=false};
    engine.Configure(settings,manifest);
    Data.Write(Path.Combine(engine.Root,"native-settings.json"),settings);
    if(args.Contains("--launch")){using var p=engine.Launch(settings);Data.Write(Path.Combine(engine.Root,"native-process.json"),new{pid=p.Id,game=engine.Game});Console.WriteLine("Minecraft PID: "+p.Id);await p.WaitForExitAsync();}
    Data.Write(Path.Combine(engine.Root,"native-install-report.json"),new{status="PASS",result,java21=NativeGameEngine.FindJava21()!=null,game=engine.Game});break;
}
case "tests": await Tests.Run(Full(args[1]));break;
case "verify-pack":
{
    var manifest=await new PackUpdater(Path.Combine(Path.GetTempPath(),"ArcaneReadOnlyManifestCheck"),Full(args[1]),File.ReadAllText(args[2])).GetManifestAsync();
    Console.WriteLine(JsonSerializer.Serialize(new{status="PASS",manifest.Version,files=manifest.Files.Count},Data.Json));break;
}
case "config-smoke":
{
    var engine=new NativeGameEngine(Full(args[1]),OfficialBootstrap.Channel,"");
    var flag=PackUpdater.SafePath(engine.Game,".arcane/codex-config-smoke.flag");
    if(!File.Exists(flag)||File.ReadAllText(flag).Trim()!="config-audit62")throw new InvalidDataException("Private configuration test guard missing");
    await engine.EnsureAsync();using var game=engine.Launch(new(){Nickname="ArcaneTester",MemoryMiB=7168});
    Console.WriteLine("Configuration test PID: "+game.Id);await game.WaitForExitAsync();Environment.ExitCode=game.ExitCode;Console.WriteLine("Game exit: "+game.ExitCode);break;
}
case "clean-build":
{
    if(!ManagedCache.Remove(Full(args[1]),"publish-distribution"))throw new IOException("Build folder is locked or contains links; cleanup stopped");
    Console.WriteLine("Generated build folder cleared");break;
}
case "java-check":
{
    var timer=Stopwatch.StartNew();var java=OfficialBootstrap.Java(Full(args[1]));
    if(java==null||!NativeGameEngine.IsJava21(java)){Console.Error.WriteLine("Pinned Java verification failed");Environment.ExitCode=1;break;}
    Console.WriteLine(JsonSerializer.Serialize(new{status="PASS",version="21",architecture="x64",milliseconds=timer.ElapsedMilliseconds},Data.Json));break;
}
default:throw new ArgumentException("Unknown command");
}
}
catch(OperationCanceledException){Console.Error.WriteLine("Operation cancelled");Environment.ExitCode=130;}
catch(Exception error){Console.Error.WriteLine(error.GetType().Name+": "+error.Message);Environment.ExitCode=1;}

static class Tests
{
    public static async Task Run(string root)
    {
        if(Directory.Exists(root))throw new IOException("Test directory must be new");Directory.CreateDirectory(root);
        var results=new List<object>();using var rsa=RSA.Create(2048);var key=rsa.ExportSubjectPublicKeyInfoPem();
        var channel=Path.Combine(root,"channel");Directory.CreateDirectory(channel);var content=Path.Combine(channel,"payload");File.WriteAllText(content,"version one");
        PackFile F(string path,string policy="managed")=>new(path,"payload",PackUpdater.Hash(content),new FileInfo(content).Length,policy);
        var manifest=new PackManifest(1,"1.0.0","1.21.1","21.1.265","test",[F("mods/a.jar"),F("config/user.json","seed")]);var address=Path.Combine(channel,"pack.json");
        void Publish(){Data.Write(address,manifest);File.WriteAllBytes(address+".sig",rsa.SignData(File.ReadAllBytes(address),HashAlgorithmName.SHA256,RSASignaturePadding.Pss));}
        async Task Test(string name,Func<Task> test){await test();results.Add(new{name,status="PASS"});Console.WriteLine("PASS "+name);}
        void Assert(bool ok){if(!ok)throw new Exception("Assertion failed");}
        async Task Reject(Func<Task> action){try{await action();}catch(Exception e)when(e is InvalidDataException or CryptographicException or IOException){return;}throw new Exception("Expected rejection");}
        Publish();var game=Path.Combine(root,"game");var updater=new PackUpdater(game,address,key);
        await Test("initial install and signed manifest",async()=>{var r=await updater.ApplyAsync();Assert(r.Downloaded==2 && File.Exists(Path.Combine(game,"mods/a.jar")));});
        await Test("unchanged files not downloaded",async()=>{var r=await updater.ApplyAsync();Assert(r.Downloaded==0 && r.Unchanged==2);});
        await Test("repair corrupt managed file",async()=>{File.WriteAllText(Path.Combine(game,"mods/a.jar"),"bad");var r=await updater.ApplyAsync();Assert(r.Downloaded==1 && File.ReadAllText(Path.Combine(game,"mods/a.jar"))=="version one");});
        await Test("preserve worlds screenshots options custom config",async()=>
        {Directory.CreateDirectory(Path.Combine(game,"saves/world"));Directory.CreateDirectory(Path.Combine(game,"screenshots"));File.WriteAllText(Path.Combine(game,"saves/world/level.dat"),"WORLD");File.WriteAllText(Path.Combine(game,"screenshots/one.png"),"SCREENSHOT");File.WriteAllText(Path.Combine(game,"options.txt"),"CUSTOM OPTIONS");File.WriteAllText(Path.Combine(game,"config/user.json"),"CUSTOM CONFIG");await updater.ApplyAsync();Assert(File.ReadAllText(Path.Combine(game,"config/user.json"))=="CUSTOM CONFIG" && File.ReadAllText(Path.Combine(game,"options.txt"))=="CUSTOM OPTIONS" && File.ReadAllText(Path.Combine(game,"saves/world/level.dat"))=="WORLD");});
        await Test("tampered manifest rejected before changes",async()=>{File.AppendAllText(address," ");await Reject(()=>updater.ApplyAsync());Publish();});
        await Test("wrong signing key rejected",async()=>{using var bad=RSA.Create(2048);await Reject(()=>new PackUpdater(game,address,bad.ExportSubjectPublicKeyInfoPem()).ApplyAsync());});
        await Test("checksum mismatch rejected",async()=>{foreach(var cached in Directory.EnumerateFiles(Path.Combine(game,".arcane","stage"),"a.jar",SearchOption.AllDirectories))File.Delete(cached);File.WriteAllText(content,"corrupt source");File.WriteAllText(Path.Combine(game,"mods/a.jar"),"needs repair");await Reject(()=>updater.ApplyAsync());Assert(File.ReadAllText(Path.Combine(game,"mods/a.jar"))=="needs repair");File.WriteAllText(content,"version one");await updater.ApplyAsync();});
        await Test("atomic rollback after interrupted commit",async()=>{File.WriteAllText(content,"version two");manifest=manifest with{Version="2.0.0",Files=[F("mods/a.jar"),F("mods/b.jar"),F("config/user.json","seed")]};Publish();await Reject(()=>updater.ApplyAsync(fault:n=>{if(n==1)throw new IOException("injected failure");}));Assert(File.ReadAllText(Path.Combine(game,"mods/a.jar"))=="version one" && !File.Exists(Path.Combine(game,"mods/b.jar")) && Data.Read<InstalledState>(updater.StatePath).Version=="1.0.0");});
        await Test("changed files only and new config template",async()=>{var r=await updater.ApplyAsync();Assert(r.Downloaded==2 && r.Preserved==1 && File.ReadAllText(Path.Combine(game,"config/user.json"))=="CUSTOM CONFIG" && File.Exists(Path.Combine(game,".arcane/new-defaults/config/user.json")));});
        await Test("remove only previously managed files",async()=>{File.WriteAllText(Path.Combine(game,"mods/user-added.jar"),"USER");manifest=manifest with{Version="3.0.0",Files=[F("mods/a.jar"),F("config/user.json","seed")]};Publish();await updater.ApplyAsync();Assert(!File.Exists(Path.Combine(game,"mods/b.jar")) && File.Exists(Path.Combine(game,"mods/user-added.jar")));});
        await Test("reject traversal absolute ADS and protected paths",async()=>{foreach(var p in new[]{"../outside","/absolute","mods/x:ads","saves/world/level.dat","mods/../x","mods\\evil.jar","mods/a.jar/child"}){var bad=manifest with{Files=[F("mods/a.jar"),F(p)]};try{PackUpdater.Validate(bad);}catch(InvalidDataException){continue;}throw new Exception("Accepted "+p);}await Task.CompletedTask;});
        await Test("reject case insensitive duplicate filenames",async()=>{try{PackUpdater.Validate(manifest with{Files=[F("mods/A.jar"),F("mods/a.jar")]});}catch(InvalidDataException){return;}await Task.CompletedTask;throw new Exception("duplicate accepted");});
        await Test("cancel leaves installation unchanged",async()=>{using var c=new CancellationTokenSource();c.Cancel();try{await updater.ApplyAsync(ct:c.Token);}catch(OperationCanceledException){Assert(Data.Read<InstalledState>(updater.StatePath).Version=="3.0.0");return;}throw new Exception("Cancellation ignored");});
        await Test("world lock prevents updates",async()=>{using var locked=new FileStream(Path.Combine(game,"saves/world/session.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);await Reject(()=>updater.ApplyAsync());});
        await Test("native runtime signature integrity and offline arguments",async()=>
        {
            var runtimeSource=Path.Combine(channel,"runtime.json");var r=new GameRuntime(1,"1.21.1","21.1.265","17","4.0.45","20240808.144430","forgeclient",["client/client.jar","libraries/test.jar"],["libraries/test.jar"],[F("client/client.jar"),F("libraries/test.jar")]);
            Data.Write(runtimeSource,r);File.WriteAllBytes(runtimeSource+".sig",rsa.SignData(File.ReadAllBytes(runtimeSource),HashAlgorithmName.SHA256,RSASignaturePadding.Pss));
            var engine=new NativeGameEngine(Path.Combine(root,"native test"),runtimeSource,key);await engine.EnsureAsync();Assert(File.Exists(Path.Combine(engine.Runtime,"client/client.jar")));
            var settings=new LauncherSettings{Nickname="ArcaneTester"};var launch=engine.BuildArguments(settings,r);Assert(launch.Contains("cpw.mods.bootstraplauncher.BootstrapLauncher") && launch[Array.IndexOf(launch,"--accessToken")+1]=="0" && !launch.Contains("--xuid") && !launch.Any(x=>x.Contains("prism",StringComparison.OrdinalIgnoreCase)));
            var uuid=NativeGameEngine.OfflineUuid(settings.Nickname);Assert(uuid.Length==32 && uuid[12]=='3' && "89ab".Contains(uuid[16]) && uuid!=NativeGameEngine.OfflineUuid("AnotherTester"));
            File.AppendAllText(runtimeSource," ");await Reject(()=>engine.EnsureAsync());
            try{NativeGameEngine.Validate(r with{ClassPath=["../outside.jar"]});}catch(InvalidDataException){return;}throw new Exception("Unsafe native runtime accepted");
        });
        await Test("concurrent update lock prevents second writer",async()=>{using var locked=new FileStream(Path.Combine(game,".arcane/lock"),FileMode.Open,FileAccess.ReadWrite,FileShare.None);await Reject(()=>updater.ApplyAsync());});
        await Test("recover pending journal from previous process",async()=>
        {var backup=Path.Combine(game,".arcane/backup/mods");Directory.CreateDirectory(backup);File.Copy(Path.Combine(game,"mods/a.jar"),Path.Combine(backup,"a.jar"),true);File.Copy(updater.StatePath,Path.Combine(game,".arcane/backup/installed.json"),true);File.WriteAllText(Path.Combine(game,"mods/a.jar"),"INTERRUPTED WRITE");Data.Write(Path.Combine(game,".arcane/journal.json"),new[]{new{path="mods/a.jar",existed=true}});updater.Recover();Assert(File.ReadAllText(Path.Combine(game,"mods/a.jar"))=="version two");await Task.CompletedTask;});
        await Test("tampered installed catalog cannot delete player saves",async()=>
        {Data.Write(updater.StatePath,new InstalledState("3.0.0",[F("saves/world/level.dat")]));await updater.ApplyAsync();Assert(File.ReadAllText(Path.Combine(game,"saves/world/level.dat"))=="WORLD"&&Data.Read<InstalledState>(updater.StatePath).Files.All(f=>!f.Path.StartsWith("saves/")));});
        await Test("launcher channel signature hash and separate version",async()=>
        {var binary=Path.Combine(channel,"test-setup.exe");File.WriteAllText(binary,"TEST ONLY");var p=Path.Combine(channel,"launcher.json");Data.Write(p,new LauncherRelease(1,"0.1.1","test-setup.exe",PackUpdater.Hash(binary),new FileInfo(binary).Length));File.WriteAllBytes(p+".sig",rsa.SignData(File.ReadAllBytes(p),HashAlgorithmName.SHA256,RSASignaturePadding.Pss));var r=await LauncherUpdater.Check(p,key);var downloaded=await LauncherUpdater.Download(r,p,Path.Combine(root,"launcher-download"));Assert(File.ReadAllText(downloaded)=="TEST ONLY");File.WriteAllText(binary,"BAD");await Reject(()=>LauncherUpdater.Download(r,p,Path.Combine(root,"launcher-download")));});
        await Test("portable defaults and legacy migration preserve player settings",async()=>{var saved=new LauncherSettings{Channel="C:/old/outputs/ArcaneGenesis_Local_Channel/pack/pack.json",RuntimeChannel="C:/old/outputs/ArcaneGenesis_Local_Channel/runtime/runtime.json",Nickname="Tester",MemoryMiB=8192,InstallDirectory=Path.Combine(root,"chosen-game")};var resolved=DistributionSettings.Resolve(saved,new LauncherSettings{Channel="release/pack.json",PublicKey=key},root);Assert(resolved.Channel==Path.Combine(root,"release","pack.json") && resolved.RuntimeChannel==OfficialBootstrap.Channel && resolved.MemoryMiB==8192 && resolved.Nickname=="Tester" && resolved.InstallDirectory==Path.Combine(root,"chosen-game"));await Task.CompletedTask;});
        await Test("official library OS rules",async()=>{Assert(OfficialBootstrap.AllowsWindows(System.Text.Json.Nodes.JsonNode.Parse("{\"rules\":[{\"action\":\"allow\",\"os\":{\"name\":\"windows\"}}]}")!) && !OfficialBootstrap.AllowsWindows(System.Text.Json.Nodes.JsonNode.Parse("{\"rules\":[{\"action\":\"allow\",\"os\":{\"name\":\"linux\"}}]}")!));await Task.CompletedTask;});
        await Test("UNC channels rejected without filesystem access",async()=>{foreach(var address in new[]{@"\\untrusted.invalid\share\pack.json","file://untrusted.invalid/share/pack.json"}){try{ChannelAddress.Parse(address);}catch(InvalidDataException){continue;}throw new Exception("UNC accepted");}await Task.CompletedTask;});
        await Test("HTTPS downgrade rejected",async()=>{try{ChannelAddress.Parse("http://example.invalid/pack.json");}catch(InvalidDataException){return;}throw new Exception("HTTP accepted");});
        await Test("signature URI preserves query and escaped path",async()=>{var uri=ChannelAddress.Signature(new Uri("https://example.invalid/pack%20name.json?token=test#fragment"));Assert(uri.AbsolutePath=="/pack%20name.json.sig"&&uri.Query=="?token=test");await Task.CompletedTask;});
        await Test("nickname rejects final newline",async()=>{Assert(!System.Text.RegularExpressions.Regex.IsMatch("Tester\n",@"^[A-Za-z0-9_]{3,16}\z"));await Task.CompletedTask;});
        await Test("unsupported loader rejected before installation",async()=>{try{PackUpdater.Validate(manifest with{NeoForge="21.1.266"});}catch(InvalidDataException){return;}throw new Exception("Loader accepted");});
        await Test("verified stage survives corrupt source and live file",async()=>{var file=manifest.Files.First(x=>x.Path=="mods/a.jar");var live=Path.Combine(game,"mods/a.jar");var original=File.ReadAllBytes(content);try{File.WriteAllText(live,"repair first");await updater.ApplyAsync();File.WriteAllText(content,"unavailable source");File.WriteAllText(live,"repair again");await updater.ApplyAsync();Assert(PackUpdater.Hash(live)==file.Sha256);}finally{File.WriteAllBytes(content,original);}});
        await Test("log sink failure still drains JVM output",async()=>{using var reader=new StreamReader(new MemoryStream(new byte[262144]));var method=typeof(NativeGameEngine).GetMethod("Pump",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static)!;await (Task)method.Invoke(null,new object[]{reader,root})!;Assert(await reader.ReadToEndAsync()=="");});
        await Test("local metadata bounded before buffering",async()=>{var file=Path.Combine(root,"oversized-metadata.bin");File.WriteAllBytes(file,new byte[65536]);using var http=new System.Net.Http.HttpClient();await Reject(()=>ChannelAddress.ReadBoundedAsync(http,new Uri(file),1024,CancellationToken.None));});
        await Test("future settings fields preserve profile",async()=>{var file=Path.Combine(root,"future-settings.json");File.WriteAllText(file,"{\"nickname\":\"Tester\",\"futureOption\":true}");Assert(Data.ReadSettings(file,new()).Nickname=="Tester");await Task.CompletedTask;});
        await Test("corrupt settings quarantined with defaults",async()=>{var file=Path.Combine(root,"corrupt-settings.json");File.WriteAllText(file,"{broken");Assert(Data.ReadSettings(file,new(){Nickname="Fallback"}).Nickname=="Fallback"&&!File.Exists(file)&&Directory.GetFiles(root,"corrupt-settings.json.bad-*").Length==1);await Task.CompletedTask;});
        await Test("Unicode roots use ASCII relative arguments",async()=>{var r=new GameRuntime(1,"1.21.1","21.1.265","17","4.0.45","20240808.144430","forgeclient",["client/a.jar","libraries/b.jar"],["libraries/b.jar"],[new("client/a.jar","https://example.invalid/a",new string('a',64),0),new("libraries/b.jar","https://example.invalid/b",new string('b',64),0)]);var engine=new NativeGameEngine(Path.Combine(root,"Папка пробел"),OfficialBootstrap.Channel,"");var args=engine.BuildArguments(new(){Nickname="Tester"},r);Assert(args.All(x=>x.All(c=>c<128))&&args[Array.IndexOf(args,"--gameDir")+1]=="."&&args[Array.IndexOf(args,"-cp")+1].StartsWith("../runtime/"));await Task.CompletedTask;});
        await Test("semicolon installation rejected before filesystem access",async()=>{try{new NativeGameEngine(Path.Combine(root,"bad;path"),OfficialBootstrap.Channel,"");}catch(InvalidDataException){return;}throw new Exception("Unsupported Java directory accepted");});
        await Test("read-only managed file can be repaired",async()=>{var live=Path.Combine(game,"mods/a.jar");File.WriteAllText(live,"needs repair");File.SetAttributes(live,File.GetAttributes(live)|FileAttributes.ReadOnly);await updater.ApplyAsync();Assert(PackUpdater.Hash(live)==manifest.Files.First(x=>x.Path=="mods/a.jar").Sha256);});
        await Test("tampered recovery journal cannot delete world",async()=>{var local=Path.Combine(root,"journal-protection");Directory.CreateDirectory(Path.Combine(local,".arcane"));Directory.CreateDirectory(Path.Combine(local,"saves/world"));var world=Path.Combine(local,"saves/world/level.dat");File.WriteAllText(world,"WORLD");Data.Write(Path.Combine(local,".arcane/journal.json"),new[]{new{path="saves/world/level.dat",existed=false}});await Reject(()=>{new PackUpdater(local,address,key).RecoverBeforeLaunch();return Task.CompletedTask;});Assert(File.ReadAllText(world)=="WORLD");});
        await Test("missing backup rejected before any rollback mutation",async()=>{var local=Path.Combine(root,"missing-backup");Directory.CreateDirectory(Path.Combine(local,".arcane"));Directory.CreateDirectory(Path.Combine(local,"mods"));var keep=Path.Combine(local,"mods/keep.jar");File.WriteAllText(keep,"KEEP");var journal=Path.Combine(local,".arcane/journal.json");Data.Write(journal,new[]{new{path="mods/keep.jar",existed=false},new{path="mods/old.jar",existed=true}});await Reject(()=>{new PackUpdater(local,address,key).RecoverBeforeLaunch();return Task.CompletedTask;});Assert(File.Exists(keep)&&File.Exists(journal));});
        var javaZip=Path.Combine(root,"pinned-java.zip");var javaRoot=Path.Combine(root,"pinned-java");
        using(var archive=System.IO.Compression.ZipFile.Open(javaZip,System.IO.Compression.ZipArchiveMode.Create))
        {foreach(var name in new[]{"jre/bin/javaw.exe","jre/bin/java.exe","jre/bin/server/jvm.dll"}){using var writer=new StreamWriter(archive.CreateEntry(name).Open());writer.Write("test fixture "+name);}}
        var javaHash=PackUpdater.Hash(javaZip);
        await Test("pinned Java archive accepts exact contents",async()=>{PinnedArchive.Extract(javaZip,javaHash,javaRoot);Assert(PinnedArchive.Verify(javaZip,javaHash,javaRoot).EndsWith("javaw.exe"));await Task.CompletedTask;});
        await Test("pinned Java rejects extra DLL despite forged receipt",async()=>{var extra=Path.Combine(javaRoot,"injected.dll");File.WriteAllText(extra,"extra");await Reject(()=>{PinnedArchive.Verify(javaZip,javaHash,javaRoot);return Task.CompletedTask;});File.Delete(extra);});
        await Test("pinned Java rejects modified executable",async()=>{var exe=Path.Combine(javaRoot,"jre/bin/javaw.exe");var original=File.ReadAllBytes(exe);File.WriteAllText(exe,"changed");await Reject(()=>{PinnedArchive.Verify(javaZip,javaHash,javaRoot);return Task.CompletedTask;});File.WriteAllBytes(exe,original);});
        await Test("pinned Java rejects substituted archive",async()=>{await Reject(()=>{PinnedArchive.Verify(javaZip,new string('0',64),javaRoot);return Task.CompletedTask;});});
        await Test("Java detector requires version 21 and x64",async()=>{var valid="java.version = 21.0.13\nsun.arch.data.model = 64\nos.arch = amd64\n";Assert(NativeGameEngine.SupportsJava21(valid)&&!NativeGameEngine.SupportsJava21(valid.Replace("21.0.13","22.0.1"))&&!NativeGameEngine.SupportsJava21(valid.Replace("= 64","= 32"))&&!NativeGameEngine.SupportsJava21(valid.Replace("amd64","aarch64")));await Task.CompletedTask;});
        await Test("official runtime ignores forged local receipt",async()=>{var runtime=OfficialRuntimeCatalog.Read();Assert(runtime.Files.Count==4037&&runtime.ClassPath.Length==107);var local=Path.Combine(root,"forged-runtime");Directory.CreateDirectory(Path.Combine(local,"runtime"));Data.Write(Path.Combine(local,"runtime/official-runtime.json"),runtime with{ClassPath=["client/attacker.jar"]});var engine=new NativeGameEngine(local,OfficialBootstrap.Channel,"");var method=typeof(NativeGameEngine).GetMethod("Cached",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic)!;var actual=(GameRuntime)method.Invoke(engine,null)!;Assert(actual.ClassPath.SequenceEqual(runtime.ClassPath)&&!actual.ClassPath.Contains("client/attacker.jar"));await Task.CompletedTask;});
        await Test("official native directory rejects unlisted library",async()=>{var local=Path.Combine(root,"native-membership");var runtime=OfficialRuntimeCatalog.Read();foreach(var file in runtime.Files.Where(f=>f.Path.StartsWith("natives/"))){var path=PackUpdater.SafePath(local,file.Path);Directory.CreateDirectory(Path.GetDirectoryName(path)!);File.WriteAllText(path,"membership fixture");}Assert(OfficialRuntimeCatalog.VerifyNatives(local,runtime));File.WriteAllText(Path.Combine(local,"natives/unlisted.dll"),"extra");Assert(!OfficialRuntimeCatalog.VerifyNatives(local,runtime));await Task.CompletedTask;});
        await Test("temporary native libraries are isolated from search directory",async()=>{var engine=new NativeGameEngine(Path.Combine(root,"native-temp-test"),OfficialBootstrap.Channel,"");var arguments=engine.BuildArguments(new(){Nickname="Tester"},OfficialRuntimeCatalog.Read());var search=arguments.Single(a=>a.StartsWith("-Djava.library.path="));Assert(arguments.Contains("-Djna.tmpdir=.arcane/native-temp")&&arguments.Contains("-Dio.netty.native.workdir=.arcane/native-temp")&&!search.Contains(".arcane/native-temp"));await Task.CompletedTask;});
        await Test("cancel midway preserves verified stage and retry resumes",async()=>
        {
            var local=Path.Combine(root,"mid-download");var source=Path.Combine(local,"channel");Directory.CreateDirectory(source);
            File.WriteAllText(Path.Combine(source,"one"),"first payload");File.WriteAllText(Path.Combine(source,"two"),"second payload");
            var files=new[]{"one","two"}.Select(name=>new PackFile("mods/"+name+".jar",name,PackUpdater.Hash(Path.Combine(source,name)),new FileInfo(Path.Combine(source,name)).Length)).ToList();
            var channelFile=Path.Combine(source,"pack.json");Data.Write(channelFile,new PackManifest(1,"1.0.0","1.21.1","21.1.265","",files));SignTest(channelFile,rsa);
            var target=Path.Combine(local,"game");var operation=new PackUpdater(target,channelFile,key);using var stop=new CancellationTokenSource();
            try{await operation.ApplyAsync(new InlineProgress<UpdateProgress>(p=>{if(p.Message.StartsWith("2/2"))stop.Cancel();}),stop.Token);throw new Exception("Cancellation ignored");}
            catch(OperationCanceledException){Assert(stop.IsCancellationRequested&&!File.Exists(Path.Combine(target,"mods/one.jar"))&&!File.Exists(operation.StatePath));}
            Assert(Directory.GetFiles(Path.Combine(target,".arcane/stage"),"one.jar",SearchOption.AllDirectories).Length==1);
            File.WriteAllText(Path.Combine(source,"one"),"source unavailable after cancellation");await operation.ApplyAsync();
            Assert(File.ReadAllText(Path.Combine(target,"mods/one.jar"))=="first payload"&&File.ReadAllText(Path.Combine(target,"mods/two.jar"))=="second payload");
        });
        await Test("cache retention preserves current stage and unknown folders",async()=>
        {
            var local=Path.Combine(root,"cache-retention");Directory.CreateDirectory(Path.Combine(local,"stage"));
            var names=new[]{new string('a',64),new string('b',64),new string('c',64),"player-data"};
            for(int i=0;i<names.Length;i++){var folder=Path.Combine(local,"stage",names[i]);Directory.CreateDirectory(folder);File.WriteAllText(Path.Combine(folder,"keep.bin"),names[i]);Directory.SetLastWriteTimeUtc(folder,DateTime.UtcNow.AddDays(-i));}
            ManagedCache.Prune(local,"stage","",64,2,names[2]);
            Assert(Directory.Exists(Path.Combine(local,"stage",names[0]))&&!Directory.Exists(Path.Combine(local,"stage",names[1]))&&Directory.Exists(Path.Combine(local,"stage",names[2]))&&Directory.Exists(Path.Combine(local,"stage",names[3])));
            await Task.CompletedTask;
        });
        await Test("cache cleanup handles readonly files and rejects escape",async()=>{var local=Path.Combine(root,"cache-readonly");Directory.CreateDirectory(Path.Combine(local,"cache"));var file=Path.Combine(local,"cache/test.bin");File.WriteAllText(file,"CACHE");File.SetAttributes(file,FileAttributes.ReadOnly);Assert(ManagedCache.Remove(local,"cache")&&!Directory.Exists(Path.Combine(local,"cache"))&&!ManagedCache.Remove(local,"../outside"));await Task.CompletedTask;});
        await Test("cache cleanup rejects junction before deleting any file",async()=>
        {
            var local=Path.Combine(root,"cache-junction");var cache=Path.Combine(local,"cache");var world=Path.Combine(local,"world");Directory.CreateDirectory(cache);Directory.CreateDirectory(world);
            File.WriteAllText(Path.Combine(cache,"managed.bin"),"CACHE");File.WriteAllText(Path.Combine(world,"keep.dat"),"WORLD");
            string Quote(string value)=>"'"+value.Replace("'","''")+"'";
            var script="New-Item -ItemType Junction -Path "+Quote(Path.Combine(cache,"link"))+" -Target "+Quote(world)+" -ErrorAction Stop | Out-Null";
            var start=new ProcessStartInfo("powershell.exe"){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true};
            foreach(var value in new[]{"-NoProfile","-NonInteractive","-EncodedCommand",Convert.ToBase64String(System.Text.Encoding.Unicode.GetBytes(script))})start.ArgumentList.Add(value);
            using var process=Process.Start(start)??throw new IOException("Cannot create junction test");
            var stdout=process.StandardOutput.ReadToEndAsync();var stderr=process.StandardError.ReadToEndAsync();using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(20));
            try{await process.WaitForExitAsync(timeout.Token);}finally{if(!process.HasExited)process.Kill(true);}
            Assert(process.ExitCode==0);await Task.WhenAll(stdout,stderr);
            Assert(!ManagedCache.Remove(local,"cache")&&File.ReadAllText(Path.Combine(world,"keep.dat"))=="WORLD"&&File.ReadAllText(Path.Combine(cache,"managed.bin"))=="CACHE");
        });
        await Test("corrupt installed state restored from signed release offline",async()=>{File.WriteAllText(updater.StatePath,"{broken");updater.RecoverBeforeLaunch();Assert(Data.Read<InstalledState>(updater.StatePath).Version=="3.0.0"&&Directory.GetFiles(Path.Combine(game,".arcane"),"installed.json.bad-*").Length>0);await Task.CompletedTask;});
        await Test("missing installed state reconstructed from signed release",async()=>{File.Delete(updater.StatePath);Assert(InstalledCatalog.Read(game,key)!.Version=="3.0.0");updater.RecoverBeforeLaunch();Assert(File.Exists(updater.StatePath));await Task.CompletedTask;});
        await Test("tampered signed receipt cannot fall back to unsigned state",async()=>{var path=PackUpdater.SafePath(game,InstalledCatalog.ReceiptPath);var original=File.ReadAllBytes(path);try{var receipt=Data.Read<SignedPackReceipt>(path);receipt.Manifest[0]^=1;Data.Write(path,receipt);await Reject(()=>{InstalledCatalog.Read(game,key);return Task.CompletedTask;});Assert(Data.Read<InstalledState>(updater.StatePath).Version=="3.0.0");}finally{File.WriteAllBytes(path,original);}});
        await Test("signed older pack rejected before file mutation",async()=>{var original=manifest;var before=PackUpdater.Hash(Path.Combine(game,"mods/a.jar"));try{manifest=manifest with{Version="2.9.9"};Publish();await Reject(()=>updater.ApplyAsync());Assert(InstalledCatalog.Read(game,key)!.Version=="3.0.0"&&PackUpdater.Hash(Path.Combine(game,"mods/a.jar"))==before);}finally{manifest=original;Publish();}});
        await Test("same release number cannot silently replace signed content",async()=>{var original=manifest;var source=File.ReadAllBytes(content);var before=PackUpdater.Hash(Path.Combine(game,"mods/a.jar"));try{File.WriteAllText(content,"replacement without version bump");manifest=manifest with{Files=[F("mods/a.jar"),F("config/user.json","seed")]};Publish();await Reject(()=>updater.ApplyAsync());Assert(PackUpdater.Hash(Path.Combine(game,"mods/a.jar"))==before&&InstalledCatalog.Read(game,key)!.Files[0].Sha256==before);}finally{File.WriteAllBytes(content,source);manifest=original;Publish();}});
        await Test("state and signed receipt rollback together after metadata failure",async()=>
        {
            var original=manifest;var source=File.ReadAllBytes(content);var before=File.ReadAllBytes(PackUpdater.SafePath(game,InstalledCatalog.ReceiptPath));
            try{File.WriteAllText(content,"version four");manifest=manifest with{Version="4.0.0",Files=[F("mods/a.jar"),F("config/user.json","seed")]};Publish();await Reject(()=>updater.ApplyAsync(fault:n=>{if(n==3)throw new IOException("failure after signed receipt write");}));Assert(Data.Read<InstalledState>(updater.StatePath).Version=="3.0.0"&&InstalledCatalog.Read(game,key)!.Version=="3.0.0"&&before.SequenceEqual(File.ReadAllBytes(PackUpdater.SafePath(game,InstalledCatalog.ReceiptPath)))&&File.ReadAllText(Path.Combine(game,"mods/a.jar"))=="version two");}
            finally{File.WriteAllBytes(content,source);manifest=original;Publish();}
        });
        await Test("null legacy catalog produces controlled repair error",async()=>{var local=Path.Combine(root,"null-installed");Directory.CreateDirectory(Path.Combine(local,".arcane"));File.WriteAllText(Path.Combine(local,".arcane/installed.json"),"{\"version\":\"1.0.0\",\"files\":null}");await Reject(()=>{InstalledCatalog.Read(local,key);return Task.CompletedTask;});});
        await Test("semantic version order handles prerelease and large numbers",async()=>{var order=new[]{"1.0.0-alpha","1.0.0-alpha.1","1.0.0-alpha.beta","1.0.0-beta","1.0.0-beta.2","1.0.0-beta.11","1.0.0-rc.1","1.0.0"};for(int i=1;i<order.Length;i++)Assert(ReleaseVersion.Compare(order[i-1],order[i])<0);Assert(ReleaseVersion.Compare("0.3.2-armor.1","0.3.1-visuals.1")>0&&ReleaseVersion.Compare("1.0.0+build.2","1.0.0+build.1")==0&&ReleaseVersion.Compare("9999999999999999999999.0.0","9.0.0")>0);await Reject(()=>{ReleaseVersion.Compare("1.0.0-alpha.01","1.0.0");return Task.CompletedTask;});});
        await Test("corrupt game marker uses backup and still blocks live process",async()=>{var local=Path.Combine(root,"active-marker");var engine=new NativeGameEngine(local,OfficialBootstrap.Channel,"");Directory.CreateDirectory(Path.Combine(engine.Game,".arcane"));File.WriteAllText(Path.Combine(engine.Game,".arcane/active-game.json"),"{broken");using var process=Process.GetCurrentProcess();Data.Write(Path.Combine(engine.Game,".arcane/active-game.json.backup"),new RunningGame(process.Id,process.StartTime.ToUniversalTime().Ticks));await Reject(()=>{engine.EnsureNotRunning();return Task.CompletedTask;});Data.Write(Path.Combine(engine.Game,".arcane/active-game.json.backup"),new RunningGame(process.Id,1));engine.EnsureNotRunning();File.WriteAllText(Path.Combine(engine.Game,".arcane/active-game.json.backup"),"{broken");await Reject(()=>{engine.EnsureNotRunning();return Task.CompletedTask;});});
        await Test("atomic metadata write leaves original intact if locked",async()=>{var path=Path.Combine(root,"locked-metadata.json");Data.Write(path,new{value="original"});bool rejected=false;using(var locked=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read)){try{Data.Write(path,new{value="replacement"});}catch(Exception error) when(error is IOException or UnauthorizedAccessException){rejected=true;}}Assert(rejected&&File.ReadAllText(path).Contains("original")&&Directory.GetFiles(root,"locked-metadata.json.new-*").Length==0);await Task.CompletedTask;});
        await Test("atomic metadata repairs readonly target without touching legacy temp",async()=>{var path=Path.Combine(root,"readonly-metadata.json");Data.Write(path,new{value="original"});File.SetAttributes(path,FileAttributes.ReadOnly);File.WriteAllText(path+".new","UNRELATED LEGACY TEMP");Data.Write(path,new{value="replacement"});Assert(File.ReadAllText(path).Contains("replacement")&&File.ReadAllText(path+".new")=="UNRELATED LEGACY TEMP");await Task.CompletedTask;});
        async Task BundleCase(string name,bool validCache,bool validSource,bool reject)
        {
            var local=Path.Combine(root,name);var source=Path.Combine(local,"channel");var cache=Path.Combine(local,"older-bundle/objects");Directory.CreateDirectory(source);Directory.CreateDirectory(cache);
            var wanted=System.Text.Encoding.UTF8.GetBytes("unchanged project object reused by a newer release");var hash=Convert.ToHexString(SHA256.HashData(wanted)).ToLowerInvariant();
            File.WriteAllBytes(Path.Combine(cache,hash),validCache?wanted:System.Text.Encoding.UTF8.GetBytes("corrupt bundled object"));
            var address=Path.Combine(source,"pack.json");Data.Write(address,new PackManifest(1,"9.0.0","1.21.1","21.1.265","",[new("mods/reused.jar","payload",hash,wanted.Length)]));SignTest(address,rsa);
            if(validSource)File.WriteAllBytes(Path.Combine(source,"payload"),wanted);
            else if(!validCache)File.WriteAllText(Path.Combine(source,"payload"),"invalid authoritative object");
            var target=Path.Combine(local,"game");var operation=new PackUpdater(target,address,key,cache);
            if(reject){await Reject(()=>operation.ApplyAsync());Assert(!File.Exists(Path.Combine(target,"mods/reused.jar")));}
            else{await operation.ApplyAsync();Assert(PackUpdater.Hash(Path.Combine(target,"mods/reused.jar"))==hash);}
        }
        await Test("older bundled objects reused by hash without source download",()=>BundleCase("bundle-reuse",true,false,false));
        await Test("corrupt bundled object ignored in favor of verified source",()=>BundleCase("bundle-fallback",false,true,false));
        await Test("corrupt bundle and source cannot install unexpected bytes",()=>BundleCase("bundle-rejected",false,false,true));
        await Test("streamed installer validates multiple chunks and preserves prior file on error",async()=>
        {
            var local=Path.Combine(root,"streamed-installer");Directory.CreateDirectory(local);var source=Path.Combine(local,"payload");
            using(var stream=File.Create(source)){var block=new byte[65536];Random.Shared.NextBytes(block);for(int i=0;i<64;i++)stream.Write(block);}
            var release=new LauncherRelease(1,"9.0.0","payload",PackUpdater.Hash(source),new FileInfo(source).Length);
            var address=Path.Combine(local,"launcher.json");var folder=Path.Combine(local,"downloads");var target=await LauncherUpdater.Download(release,address,folder);
            Assert(PackUpdater.Hash(target)==release.Sha256);
            File.WriteAllText(source,"corrupt replacement");await Reject(()=>LauncherUpdater.Download(release,address,folder));
            Assert(PackUpdater.Hash(target)==release.Sha256&&!File.Exists(target+".partial"));
        });
        await Test("cancelled installer download leaves no destination or partial",async()=>{var local=Path.Combine(root,"cancelled-installer");using var stop=new CancellationTokenSource();stop.Cancel();try{await LauncherUpdater.Download(new(1,"9.0.0","payload",new string('a',64),1),Path.Combine(root,"launcher.json"),local,stop.Token);throw new Exception("Cancellation ignored");}catch(OperationCanceledException){Assert(!Directory.Exists(local));}});
        async Task<(PackUpdater Updater,string Game,string Source,string Address,PackManifest Target)> FailedUpdate(string name)
        {
            var local=Path.Combine(root,name);var source=Path.Combine(local,"channel");Directory.CreateDirectory(source);
            PackFile Item(string path,string url,string text,string policy="managed"){var file=Path.Combine(source,url);File.WriteAllText(file,text);return new(path,url,PackUpdater.Hash(file),new FileInfo(file).Length,policy);}
            var old=new PackManifest(1,"1.0.0","1.21.1","21.1.265","",[Item("mods/old.jar","old.obj","old payload"),Item("config/update.json","config-old.obj","default v1","seed"),Item("config/player.json","player-old.obj","player default v1","seed")]);
            var address=Path.Combine(source,"pack.json");Data.Write(address,old);SignTest(address,rsa);var game=Path.Combine(local,"game");var updater=new PackUpdater(game,address,key);await updater.ApplyAsync();
            File.WriteAllText(Path.Combine(game,"config/player.json"),"USER SETTINGS");File.WriteAllText(Path.Combine(game,"mods/custom.jar"),"USER MOD");
            var target=old with{Version="2.0.0",Files=[Item("mods/new.jar","new.obj","new payload"),Item("config/update.json","config-new.obj","default v2","seed"),Item("config/player.json","player-new.obj","player default v2","seed")]};
            Data.Write(address,target);SignTest(address,rsa);
            var backup=Path.Combine(game,".arcane/backup");Directory.CreateDirectory(backup);File.Copy(updater.StatePath,Path.Combine(backup,"installed.json"));File.Copy(PackUpdater.SafePath(game,InstalledCatalog.ReceiptPath),Path.Combine(backup,"installed-release.json"));
            Data.Write(Path.Combine(backup,"metadata.json"),new{state=true,receipt=true});Data.Write(PackUpdater.SafePath(game,InterruptedUpdateRepair.TargetProofPath),new SignedPackReceipt(File.ReadAllBytes(address),File.ReadAllBytes(address+".sig")));
            File.WriteAllText(Path.Combine(game,"mods/new.jar"),"PARTIAL JAR");File.WriteAllText(Path.Combine(game,"config/update.json"),"PARTIAL CONFIG");
            Data.Write(Path.Combine(game,".arcane/journal.json"),new[]{new{path="mods/old.jar",existed=true},new{path="mods/new.jar",existed=false},new{path="config/update.json",existed=true}});
            Directory.CreateDirectory(Path.Combine(game,"saves/world"));File.WriteAllText(Path.Combine(game,"saves/world/level.dat"),"WORLD");Directory.CreateDirectory(Path.Combine(game,"screenshots"));File.WriteAllText(Path.Combine(game,"screenshots/keep.png"),"SCREENSHOT");
            return(updater,game,source,address,target);
        }
        void Preserved(string game){Assert(File.ReadAllText(Path.Combine(game,"saves/world/level.dat"))=="WORLD"&&File.ReadAllText(Path.Combine(game,"screenshots/keep.png"))=="SCREENSHOT"&&File.ReadAllText(Path.Combine(game,"config/player.json"))=="USER SETTINGS"&&File.ReadAllText(Path.Combine(game,"mods/custom.jar"))=="USER MOD");}
        await Test("missing backups repaired with signed target and rescue archive",async()=>
        {
            var f=await FailedUpdate("repair-lost-backup");await Reject(()=>f.Updater.ApplyAsync());await f.Updater.RepairAsync();
            Assert(File.ReadAllText(Path.Combine(f.Game,"mods/new.jar"))=="new payload"&&!File.Exists(Path.Combine(f.Game,"mods/old.jar"))&&File.ReadAllText(Path.Combine(f.Game,"config/update.json"))=="default v2"&&InstalledCatalog.Read(f.Game,key)!.Version=="2.0.0"&&!PackUpdater.HasPendingRecovery(f.Game));Preserved(f.Game);
            Assert(Directory.EnumerateFiles(Path.Combine(f.Game,".arcane/recovery-archive"),"update.json",SearchOption.AllDirectories).Any(p=>File.ReadAllText(p)=="PARTIAL CONFIG"));
        });
        await Test("second repair interruption resumes fixed target before newer release",async()=>
        {
            var f=await FailedUpdate("repair-resume");await Reject(()=>f.Updater.RepairAsync(fault:n=>{if(n==1)throw new IOException("second interruption");}));
            Assert(InterruptedUpdateRepair.Pending(f.Game));await Reject(()=>f.Updater.ApplyAsync());await Reject(()=>{f.Updater.RecoverBeforeLaunch();return Task.CompletedTask;});
            var next=Path.Combine(f.Source,"next.obj");File.WriteAllText(next,"next payload");var latest=f.Target with{Version="3.0.0",Files=f.Target.Files.Append(new PackFile("mods/next.jar","next.obj",PackUpdater.Hash(next),new FileInfo(next).Length)).ToList()};Data.Write(f.Address,latest);SignTest(f.Address,rsa);
            File.WriteAllText(Path.Combine(f.Source,"new.obj"),"source temporarily corrupt");await f.Updater.RepairAsync();Assert(InstalledCatalog.Read(f.Game,key)!.Version=="2.0.0"&&!File.Exists(Path.Combine(f.Game,"mods/next.jar")));Preserved(f.Game);
            await f.Updater.ApplyAsync();Assert(InstalledCatalog.Read(f.Game,key)!.Version=="3.0.0"&&File.Exists(Path.Combine(f.Game,"mods/next.jar")));
        });
        await Test("cancelled repair keeps old journal and live partial files",async()=>{var f=await FailedUpdate("repair-cancel");using var stop=new CancellationTokenSource();try{await f.Updater.RepairAsync(new InlineProgress<UpdateProgress>(p=>{if(p.Message.StartsWith("2/3"))stop.Cancel();}),stop.Token);throw new Exception("Cancellation ignored");}catch(OperationCanceledException){Assert(File.Exists(Path.Combine(f.Game,".arcane/journal.json"))&&!InterruptedUpdateRepair.Pending(f.Game)&&File.ReadAllText(Path.Combine(f.Game,"mods/new.jar"))=="PARTIAL JAR"&&InstalledCatalog.Read(f.Game,key)!.Version=="1.0.0");Preserved(f.Game);}});
        await Test("bad repair payload cannot consume old journal or overwrite files",async()=>{var f=await FailedUpdate("repair-bad-payload");File.WriteAllText(Path.Combine(f.Source,"new.obj"),"invalid source");await Reject(()=>f.Updater.RepairAsync());Assert(File.Exists(Path.Combine(f.Game,".arcane/journal.json"))&&!InterruptedUpdateRepair.Pending(f.Game)&&File.ReadAllText(Path.Combine(f.Game,"config/update.json"))=="PARTIAL CONFIG");Preserved(f.Game);});
        await Test("repair refuses journal path absent from signed catalogs",async()=>{var f=await FailedUpdate("repair-unknown-path");var unknown=Path.Combine(f.Game,"config/not-owned.json");File.WriteAllText(unknown,"KEEP");Data.Write(Path.Combine(f.Game,".arcane/journal.json"),new[]{new{path="config/not-owned.json",existed=true}});await Reject(()=>f.Updater.RepairAsync());Assert(File.ReadAllText(unknown)=="KEEP"&&!InterruptedUpdateRepair.Pending(f.Game));Preserved(f.Game);});
        await Test("repair plan rejects UNC source and downgrade without mutation",async()=>
        {
            var f=await FailedUpdate("repair-plan-guards");await Reject(()=>f.Updater.RepairAsync(fault:n=>{if(n==1)throw new IOException("interruption");}));var marker=PackUpdater.SafePath(f.Game,InterruptedUpdateRepair.PlanPath);var original=File.ReadAllBytes(marker);var plan=Data.Read<ForwardRepairPlan>(marker);
            Data.Write(marker,plan with{Source="file://untrusted.invalid/share/pack.json"});await Reject(()=>f.Updater.RepairAsync());
            Data.Write(marker,plan with{Target=plan.Previous[0]});await Reject(()=>f.Updater.RepairAsync());Assert(File.ReadAllText(Path.Combine(f.Game,"mods/new.jar"))=="PARTIAL JAR");Preserved(f.Game);
            File.WriteAllBytes(marker,original);await f.Updater.RepairAsync();Assert(!PackUpdater.HasPendingRecovery(f.Game));
        });
        await Test("repair survives crash after intent before old journal move",async()=>{var f=await FailedUpdate("repair-intent-boundary");var target=Data.Read<SignedPackReceipt>(PackUpdater.SafePath(f.Game,InterruptedUpdateRepair.TargetProofPath));var plan=InterruptedUpdateRepair.Create(f.Game,key,target,new Uri(f.Address).AbsoluteUri,["mods/old.jar","mods/new.jar","config/update.json"]);Data.Write(PackUpdater.SafePath(f.Game,InterruptedUpdateRepair.PlanPath),plan);await f.Updater.RepairAsync();Assert(!PackUpdater.HasPendingRecovery(f.Game)&&InstalledCatalog.Read(f.Game,key)!.Version=="2.0.0");Preserved(f.Game);});
        await Test("repair survives crash after old journal archived before new transaction",async()=>{var f=await FailedUpdate("repair-archive-boundary");var target=Data.Read<SignedPackReceipt>(PackUpdater.SafePath(f.Game,InterruptedUpdateRepair.TargetProofPath));var plan=InterruptedUpdateRepair.Create(f.Game,key,target,new Uri(f.Address).AbsoluteUri,["mods/old.jar","mods/new.jar","config/update.json"]);InterruptedUpdateRepair.Archive(f.Game,plan,key,plan.Touched);Assert(InterruptedUpdateRepair.Pending(f.Game)&&!File.Exists(Path.Combine(f.Game,".arcane/journal.json")));await f.Updater.RepairAsync();Assert(!PackUpdater.HasPendingRecovery(f.Game)&&File.ReadAllText(Path.Combine(f.Game,"config/update.json"))=="default v2");Preserved(f.Game);});
        await Test("rescue archiver rejects protected path outside validated plan",async()=>{var f=await FailedUpdate("repair-archive-guard");var target=Data.Read<SignedPackReceipt>(PackUpdater.SafePath(f.Game,InterruptedUpdateRepair.TargetProofPath));var plan=InterruptedUpdateRepair.Create(f.Game,key,target,new Uri(f.Address).AbsoluteUri,["mods/old.jar","mods/new.jar","config/update.json"]);await Reject(()=>{InterruptedUpdateRepair.Archive(f.Game,plan,key,["saves/world/level.dat"]);return Task.CompletedTask;});Assert(!InterruptedUpdateRepair.Pending(f.Game));Preserved(f.Game);});
        Data.Write(Path.Combine(root,"report.json"),new{status="PASS",count=results.Count,checks=results});
    }
    private static void SignTest(string path,RSA key)=>File.WriteAllBytes(path+".sig",key.SignData(File.ReadAllBytes(path),HashAlgorithmName.SHA256,RSASignaturePadding.Pss));
    private sealed class InlineProgress<T>(Action<T> action):IProgress<T>{public void Report(T value)=>action(value);}
}



