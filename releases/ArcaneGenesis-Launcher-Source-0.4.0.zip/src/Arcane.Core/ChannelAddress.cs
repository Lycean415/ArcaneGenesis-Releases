namespace Arcane.Core;

public static class ChannelAddress
{
    public static Uri Parse(string value)
    {
        if (value.StartsWith(@"\\", StringComparison.Ordinal)) throw new InvalidDataException("Network file paths are not allowed");
        return Check(Uri.TryCreate(value, UriKind.Absolute, out var uri) ? uri : new Uri(Path.GetFullPath(value)));
    }
    public static Uri Check(Uri uri)
    {
        if (uri.IsUnc || (uri.IsFile && uri.Host.Length != 0)) throw new InvalidDataException("Network file paths are not allowed");
        if (!uri.IsFile && uri.Scheme != "https") throw new InvalidDataException("HTTPS required");
        return uri;
    }
    public static async Task<byte[]> ReadBoundedAsync(System.Net.Http.HttpClient http,Uri uri,int limit,CancellationToken ct)
    {
        Check(uri);
        using var response=uri.IsFile?null:await http.GetAsync(uri,System.Net.Http.HttpCompletionOption.ResponseHeadersRead,ct);
        response?.EnsureSuccessStatusCode();
        if(response!=null&&response.RequestMessage?.RequestUri?.Scheme!="https")throw new InvalidDataException("Insecure redirect");
        await using var input=uri.IsFile?File.OpenRead(uri.LocalPath):await response!.Content.ReadAsStreamAsync(ct);
        using var output=new MemoryStream();var buffer=new byte[65536];int n;
        while((n=await input.ReadAsync(buffer,ct))>0){if(output.Length+n>limit)throw new InvalidDataException("Download exceeds size limit");await output.WriteAsync(buffer.AsMemory(0,n),ct);}
        return output.ToArray();
    }
    public static Uri Signature(Uri channel)
    {
        Check(channel);
        var builder = new UriBuilder(channel) { Path = channel.AbsolutePath + ".sig" };
        return Check(builder.Uri);
    }
}
