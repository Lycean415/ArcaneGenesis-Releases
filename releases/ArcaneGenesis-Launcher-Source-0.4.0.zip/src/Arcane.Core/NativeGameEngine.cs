using System.Diagnostics;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace Arcane.Core;
public sealed record GameRuntime(int Schema,string Minecraft,string NeoForge,string AssetIndex,string FmlVersion,string NeoFormVersion,string LaunchTarget,string[] ClassPath,string[] ModulePath,List<PackFile> Files);
public sealed record RunningGame(int Pid,long Started);
public sealed class NativeGameEngine
{
    private readonly string channel,key;
    public string Root{get;}
    public string Runtime=>Path.Combine(Root,"runtime");
    public string Game=>Directory.Exists(Path.Combine(Root,"prism","instances","ArcaneGenesis",".minecraft"))?Path.Combine(Root,"prism","instances","ArcaneGenesis",".minecraft"):Path.Combine(Root,"game");
    private string Active=>Path.Combine(Game,".arcane","active-game.json");
    public NativeGameEngine(string root,string channel,string key){Root=Path.GetFullPath(root);if(Root.Contains(';'))throw new InvalidDataException("Выбери папку установки без точки с запятой (;): Java не поддерживает такой путь");this.channel=channel;this.key=key;}
    public void EnsureNotRunning()
    {
        PackUpdater.EnsureIdle(Game);
        var records=new List<RunningGame>();bool found=false;
        foreach(var relative in new[]{".arcane/active-game.json",".arcane/active-game.json.backup"})
        {
            var path=PackUpdater.SafePath(Game,relative);if(!File.Exists(path))continue;found=true;
            try
            {
                using var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read);
                if(stream.Length>4096)continue;
                var record=JsonSerializer.Deserialize<RunningGame>(stream,Data.Json);
                if(record!=null&&record.Pid>0&&record.Started>0&&record.Started<=DateTime.MaxValue.Ticks)records.Add(record);
            }
            catch(JsonException){}
        }
        if(found&&records.Count==0)throw new IOException("Повреждены обе записи о запущенной игре. Не удалось безопасно проверить, закрыт ли Minecraft; установка и обновление остановлены.");
        foreach(var active in records.Distinct())
        {
            try{using var process=Process.GetProcessById(active.Pid);if(!process.HasExited && process.StartTime.ToUniversalTime().Ticks==active.Started)throw new IOException("Minecraft уже запущен. Закрой игру перед обновлением.");}
            catch(ArgumentException){}
            catch(System.ComponentModel.Win32Exception error){throw new IOException("Windows не позволила проверить процесс Minecraft. Обновление остановлено, файлы сохранены.",error);}
        }
    }
    private static Uri Address(string path)=>ChannelAddress.Parse(path);
    private static async Task<byte[]> Read(Uri uri,CancellationToken ct)
    {
        ChannelAddress.Check(uri);
        if(uri.IsFile){using var localHttp=new HttpClient();return await ChannelAddress.ReadBoundedAsync(localHttp,uri,16*1024*1024,ct);}
        if(uri.Scheme!="https")throw new InvalidDataException("HTTPS required");
        using var http=new HttpClient{Timeout=TimeSpan.FromSeconds(30)};
        return await ChannelAddress.ReadBoundedAsync(http,uri,16*1024*1024,ct);
    }
    private GameRuntime Verify(byte[] data,byte[] signature)
    {
        using var rsa=RSA.Create();rsa.ImportFromPem(key);
        if(!rsa.VerifyData(data,signature,HashAlgorithmName.SHA256,RSASignaturePadding.Pss))throw new CryptographicException("Invalid runtime signature");
        var result=JsonSerializer.Deserialize<GameRuntime>(data,Data.Json)??throw new InvalidDataException("Empty runtime");
        Validate(result);return result;
    }
    public static void Validate(GameRuntime r)
    {
        if(r.Schema!=1 || r.Minecraft!="1.21.1" || r.NeoForge!="21.1.265" || r.AssetIndex!="17" || r.FmlVersion!="4.0.45" || r.NeoFormVersion!="20240808.144430" || r.LaunchTarget!="forgeclient" || r.Files.Count is <1 or >30000)throw new InvalidDataException("Unsupported Minecraft runtime");
        var paths=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(var f in r.Files)
        {
            PackUpdater.ValidateRelativePath(f.Path);
            if(!paths.Add(f.Path) || !new[]{"libraries/","assets/","natives/","client/"}.Any(x=>f.Path.StartsWith(x,StringComparison.Ordinal)) || f.Size<0 || f.Size>1024L*1024*1024 || !Regex.IsMatch(f.Sha256,"^[a-f0-9]{64}\\z"))throw new InvalidDataException("Unsafe runtime entry");
        }
        foreach(var p in r.ClassPath.Concat(r.ModulePath))if(!paths.Contains(p)||!p.EndsWith(".jar",StringComparison.Ordinal))throw new InvalidDataException("Missing runtime classpath entry");
        if(r.ClassPath.Length<2 || r.ModulePath.Length<1)throw new InvalidDataException("Incomplete classpath");
    }
    public async Task EnsureAsync(IProgress<UpdateProgress>? progress=null,CancellationToken ct=default)
    {
        EnsureNotRunning();Directory.CreateDirectory(Runtime);
        using var gate=new FileStream(PackUpdater.SafePath(Runtime,"install.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
        if(channel==OfficialBootstrap.Channel){await OfficialBootstrap.Ensure(Runtime,progress,ct);return;}
        var address=Address(channel);
        var bytes=await Read(address,ct);var signature=await Read(ChannelAddress.Signature(address),ct);var r=Verify(bytes,signature);
        using var http=new HttpClient{Timeout=TimeSpan.FromMinutes(15)};
        int n=0;
        foreach(var f in r.Files)
        {
            ct.ThrowIfCancellationRequested();var target=PackUpdater.SafePath(Runtime,f.Path);
            if(File.Exists(target)&&new FileInfo(target).Length==f.Size&&PackUpdater.Hash(target)==f.Sha256){n++;continue;}
            progress?.Report(new UpdateProgress($"Minecraft · {++n}/{r.Files.Count}",n*100.0/r.Files.Count));
            var uri=ChannelAddress.Check(new Uri(address,f.Url));
            if((!address.IsFile&&uri.Scheme!="https")||(!uri.IsFile&&uri.Scheme!="https"))throw new InvalidDataException("Unsafe runtime download");
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);var temp=PackUpdater.SafePath(Runtime,f.Path+".partial");
            using var response=uri.IsFile?null:await http.GetAsync(uri,HttpCompletionOption.ResponseHeadersRead,ct);response?.EnsureSuccessStatusCode();
            if(response!=null&&response.RequestMessage?.RequestUri?.Scheme!="https")throw new InvalidDataException("Unsafe redirect");
            await using(var input=uri.IsFile?File.OpenRead(uri.LocalPath):await response!.Content.ReadAsStreamAsync(ct))
            await using(var output=File.Create(temp))
            {var buffer=new byte[131072];long total=0;int count;while((count=await input.ReadAsync(buffer,ct))>0){total+=count;if(total>f.Size)throw new InvalidDataException("Runtime size mismatch");await output.WriteAsync(buffer.AsMemory(0,count),ct);}}
            if(new FileInfo(temp).Length!=f.Size||PackUpdater.Hash(temp)!=f.Sha256)throw new InvalidDataException("Runtime checksum mismatch: "+f.Path);
            File.Move(temp,target,true);
        }
        await File.WriteAllBytesAsync(Path.Combine(Runtime,"runtime.json"),bytes,ct);await File.WriteAllBytesAsync(Path.Combine(Runtime,"runtime.json.sig"),signature,ct);
    }
    private GameRuntime Cached()=>channel==OfficialBootstrap.Channel?OfficialRuntimeCatalog.Read():Verify(File.ReadAllBytes(Path.Combine(Runtime,"runtime.json")),File.ReadAllBytes(Path.Combine(Runtime,"runtime.json.sig")));
    public void Configure(LauncherSettings settings,PackManifest pack)
    {
        var r=Cached();if(r.Minecraft!=pack.Minecraft||r.NeoForge!=pack.NeoForge)throw new InvalidDataException("Runtime and modpack versions do not match");
        if(settings.MemoryMiB is <2048 or >65536||settings.Width is <640 or >7680||settings.Height is <480 or >4320)throw new InvalidDataException("Invalid memory or resolution");
        Directory.CreateDirectory(Game);var path=Path.Combine(Game,"options.txt");var lines=File.Exists(path)?File.ReadAllLines(path).ToList():[];
        var i=lines.FindIndex(x=>x.StartsWith("fullscreen:"));var value="fullscreen:"+settings.Fullscreen.ToString().ToLowerInvariant();if(i>=0)lines[i]=value;else lines.Add(value);File.WriteAllLines(path,lines);
    }
    public static string OfflineUuid(string name)
    {
        var bytes=MD5.HashData(Encoding.UTF8.GetBytes("OfflinePlayer:"+name));bytes[6]=(byte)((bytes[6]&15)|48);bytes[8]=(byte)((bytes[8]&63)|128);return Convert.ToHexString(bytes).ToLowerInvariant();
    }
    public string[] BuildArguments(LauncherSettings s,GameRuntime r,string nativeTemp=".arcane/native-temp")
    {
        Validate(r);if(!Regex.IsMatch(s.Nickname,"^[A-Za-z0-9_]{3,16}\\z"))throw new InvalidDataException("Ник: 3–16 латинских букв, цифр или _");
        if(s.MemoryMiB is <2048 or >65536)throw new InvalidDataException("Invalid RAM");
        string P(string rel)=>Path.GetRelativePath(Game,PackUpdater.SafePath(Runtime,rel)).Replace('\\','/');
        var natives=P("natives").TrimEnd('/');
        List<string> args=[$"-Xms1024m",$"-Xmx{s.MemoryMiB}m","-Djava.library.path="+natives,"-Djna.tmpdir="+nativeTemp,"-Dorg.lwjgl.system.SharedLibraryExtractPath="+natives,"-Dio.netty.native.workdir="+nativeTemp,"-Dminecraft.launcher.brand=ArcaneGenesis","-Dminecraft.launcher.version="+LauncherBuild.Display,"-Djava.net.preferIPv6Addresses=system","-DignoreList=client-extra,client.jar","-DlibraryDirectory="+P("libraries").TrimEnd('/'),"-cp",string.Join(';',r.ClassPath.Except(r.ModulePath,StringComparer.OrdinalIgnoreCase).Select(P)),"-p",string.Join(';',r.ModulePath.Select(P)),"--add-modules","ALL-MODULE-PATH","--add-opens","java.base/java.util.jar=cpw.mods.securejarhandler","--add-opens","java.base/java.lang.invoke=cpw.mods.securejarhandler","--add-exports","java.base/sun.security.util=cpw.mods.securejarhandler","--add-exports","jdk.naming.dns/com.sun.jndi.dns=java.naming","cpw.mods.bootstraplauncher.BootstrapLauncher","--username",s.Nickname,"--version","ArcaneGenesis-1.21.1","--gameDir",".","--assetsDir",P("assets").TrimEnd('/'),"--assetIndex",r.AssetIndex,"--uuid",OfflineUuid(s.Nickname),"--accessToken","0","--userType","legacy","--versionType","release","--fml.neoForgeVersion",r.NeoForge,"--fml.fmlVersion",r.FmlVersion,"--fml.mcVersion",r.Minecraft,"--fml.neoFormVersion",r.NeoFormVersion,"--launchTarget",r.LaunchTarget,"--width",s.Width.ToString(),"--height",s.Height.ToString()];
        PackUpdater.ValidateRelativePath(nativeTemp);
        return args.ToArray();
    }
    public Process Launch(LauncherSettings s)
    {
        EnsureNotRunning();var r=Cached();var java=string.IsNullOrWhiteSpace(s.JavaPath)?OfficialBootstrap.Java(Runtime)??FindJava21():s.JavaPath;
        if(channel==OfficialBootstrap.Channel&&!OfficialRuntimeCatalog.VerifyNatives(Runtime,r))throw new InvalidDataException("Unexpected native files. Run file repair before launch.");
        if(java==null||!File.Exists(java))throw new FileNotFoundException("Не найдена Java 21. Укажи путь к javaw.exe в настройках.");
        if(!IsJava21(java))throw new InvalidDataException("Для игры нужна рабочая 64-разрядная Java 21. Проверь путь Java в настройках.");
        ManagedCache.Prune(Game,".arcane/native-temp","",32,0);
        var nativeTemp=".arcane/native-temp/"+Guid.NewGuid().ToString("N");Directory.CreateDirectory(PackUpdater.SafePath(Game,nativeTemp));
        var args=BuildArguments(s,r,nativeTemp);var path=PackUpdater.SafePath(Game,".arcane/launch.args");Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        if(args.Any(x=>x.Any(c=>c>127||char.IsControl(c))))throw new InvalidDataException("Unsupported non-ASCII runtime argument");
        File.WriteAllLines(path,args.Select(x=>"\""+x.Replace("\\","\\\\").Replace("\"","\\\"")+"\""));
        var start=new ProcessStartInfo(java){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=Game,RedirectStandardOutput=true,RedirectStandardError=true};start.ArgumentList.Add("@"+Path.GetRelativePath(Game,path).Replace('\\','/'));
        Directory.CreateDirectory(Path.Combine(Game,"logs"));var process=Process.Start(start)??throw new IOException("Minecraft не запустился");
        _=Pump(process.StandardOutput,Path.Combine(Game,"logs","launcher-out.log"));_=Pump(process.StandardError,Path.Combine(Game,"logs","launcher-error.log"));
        try
        {
            var active=new RunningGame(process.Id,process.StartTime.ToUniversalTime().Ticks);
            Data.Write(PackUpdater.SafePath(Game,".arcane/active-game.json.backup"),active);Data.Write(Active,active);return process;
        }
        catch{try{if(!process.HasExited)process.Kill(true);}finally{process.Dispose();}throw;}
    }
    private static async Task Pump(StreamReader reader,string path)
    {
        FileStream? file=null;
        try
        {
            try{file=new FileStream(path,FileMode.Create,FileAccess.Write,FileShare.ReadWrite);}catch(IOException){}catch(UnauthorizedAccessException){}
            var buffer=new byte[32768];int n;
            while((n=await reader.BaseStream.ReadAsync(buffer))>0)
            {
                if(file==null)continue;
                try{await file.WriteAsync(buffer.AsMemory(0,n));}
                catch(Exception ex) when(ex is IOException or UnauthorizedAccessException){await file.DisposeAsync();file=null;}
            }
        }
        catch(IOException){}catch(ObjectDisposedException){}
        finally{if(file!=null)await file.DisposeAsync();}
    }
    public static string? FindJava21()
    {
        var baseDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),".minecraft","runtime");
        var candidates=new List<string>();var home=Environment.GetEnvironmentVariable("JAVA_HOME");if(home!=null)candidates.Add(Path.Combine(home,"bin","javaw.exe"));
        foreach(var dir in new[]{baseDir,Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"Eclipse Adoptium"),Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"Java")})
            if(Directory.Exists(dir))try{candidates.AddRange(Directory.EnumerateFiles(dir,"javaw.exe",new EnumerationOptions{RecurseSubdirectories=true,IgnoreInaccessible=true,AttributesToSkip=FileAttributes.ReparsePoint}));}catch(IOException){}catch(UnauthorizedAccessException){}
        foreach(var java in candidates.Distinct())if(IsJava21(java))return java;
        return null;
    }

    public static bool SupportsJava21(string output)=>
        Regex.IsMatch(output,@"(?m)^\s*java\.version\s*=\s*21(?:\.|\s|$)") &&
        Regex.IsMatch(output,@"(?m)^\s*sun\.arch\.data\.model\s*=\s*64\s*$") &&
        Regex.IsMatch(output,@"(?m)^\s*os\.arch\s*=\s*(?:amd64|x86_64)\s*$");

    public static bool IsJava21(string java)
    {
        try
        {
            if(!File.Exists(java))return false;
            var executable=Path.Combine(Path.GetDirectoryName(Path.GetFullPath(java))!,"java.exe");
            using var p=Process.Start(new ProcessStartInfo(executable,"-XshowSettings:properties -version"){UseShellExecute=false,CreateNoWindow=true,RedirectStandardError=true,RedirectStandardOutput=true});
            if(p==null)return false;
            using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(5));
            async Task<string> ReadBounded(StreamReader reader)
            {
                var buffer=new char[4096];var result=new StringBuilder();int count;
                while((count=await reader.ReadAsync(buffer.AsMemory(),timeout.Token))>0)
                {if(result.Length+count>65536)throw new InvalidDataException("Java probe output too large");result.Append(buffer,0,count);}
                return result.ToString();
            }
            try
            {
                var stdout=ReadBounded(p.StandardOutput);var stderr=ReadBounded(p.StandardError);
                Task.WhenAll(stdout,stderr,p.WaitForExitAsync(timeout.Token)).GetAwaiter().GetResult();
                return p.ExitCode==0&&SupportsJava21(stdout.Result+"\n"+stderr.Result);
            }
            finally { if(!p.HasExited){try{p.Kill(true);}catch(InvalidOperationException){}} }
        }
        catch(Exception e) when(e is System.ComponentModel.Win32Exception or IOException or UnauthorizedAccessException or OperationCanceledException or InvalidDataException){return false;}
    }
}




