using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;
namespace Arcane.Core;
public sealed record LauncherRelease(int Schema,string Version,string Url,string Sha256,long Size);
public static class LauncherUpdater
{
    private static void Validate(LauncherRelease r)
    {
        if(r.Schema!=1||!Version.TryParse(r.Version,out _)||r.Url is null||r.Sha256 is null||r.Size<=0||r.Size>500L*1024*1024||!System.Text.RegularExpressions.Regex.IsMatch(r.Sha256,"^[a-f0-9]{64}\\z"))throw new InvalidDataException("Invalid launcher manifest");
    }
    private static Uri Address(string address)=>ChannelAddress.Parse(address);
    private static readonly HttpClient Http=new(){Timeout=TimeSpan.FromMinutes(15)};
    private static async Task<byte[]> Read(Uri uri,CancellationToken ct,int limit)
    {
        ChannelAddress.Check(uri);
        if(!uri.IsFile && uri.Scheme!="https")throw new InvalidDataException("HTTPS required");
        using var response=uri.IsFile?null:await Http.GetAsync(uri,HttpCompletionOption.ResponseHeadersRead,ct);response?.EnsureSuccessStatusCode();
        if(response!=null && response.RequestMessage?.RequestUri?.Scheme!="https")throw new InvalidDataException("Insecure redirect");
        await using var input=uri.IsFile?File.OpenRead(uri.LocalPath):await response!.Content.ReadAsStreamAsync(ct);
        using var output=new MemoryStream();var b=new byte[131072];int n;while((n=await input.ReadAsync(b,ct))>0){if(output.Length+n>limit)throw new InvalidDataException("Download too large");await output.WriteAsync(b.AsMemory(0,n),ct);}return output.ToArray();
    }
    public static async Task<LauncherRelease> Check(string channel,string key,CancellationToken ct=default)
    {
        using var deadline=CancellationTokenSource.CreateLinkedTokenSource(ct);deadline.CancelAfter(TimeSpan.FromSeconds(25));
        var address=Address(channel);var bytes=await Read(address,deadline.Token,1024*1024);var sig=await Read(ChannelAddress.Signature(address),deadline.Token,4096);
        using var rsa=RSA.Create();rsa.ImportFromPem(key);if(!rsa.VerifyData(bytes,sig,HashAlgorithmName.SHA256,RSASignaturePadding.Pss))throw new CryptographicException("Invalid launcher signature");
        var r=JsonSerializer.Deserialize<LauncherRelease>(bytes,Data.Json)??throw new InvalidDataException("Empty launcher manifest");
        Validate(r);
        var target=ChannelAddress.Check(new Uri(address,r.Url));if(!address.IsFile && target.Scheme!="https")throw new InvalidDataException("Insecure installer source");return r;
    }
    public static async Task<string> Download(LauncherRelease release,string channel,string folder,CancellationToken ct=default)
    {
        Validate(release);ct.ThrowIfCancellationRequested();
        var address=Address(channel);var uri=ChannelAddress.Check(new Uri(address,release.Url));if(!address.IsFile && uri.Scheme!="https")throw new InvalidDataException("Insecure installer source");
        var name="ArcaneGenesis-Setup-"+Version.Parse(release.Version)+".exe";
        var target=PackUpdater.SafePath(folder,name);var partial=PackUpdater.SafePath(folder,name+".partial");
        Directory.CreateDirectory(folder);
        try
        {
            using var response=uri.IsFile?null:await Http.GetAsync(uri,HttpCompletionOption.ResponseHeadersRead,ct);response?.EnsureSuccessStatusCode();
            if(response!=null&&response.RequestMessage?.RequestUri?.Scheme!="https")throw new InvalidDataException("Insecure redirect");
            if(response?.Content.Headers.ContentLength is long length&&length>release.Size)throw new InvalidDataException("Installer exceeds declared size");
            await using var input=uri.IsFile?File.OpenRead(uri.LocalPath):await response!.Content.ReadAsStreamAsync(ct);
            if(input.CanSeek&&input.Length>release.Size)throw new InvalidDataException("Installer exceeds declared size");
            using var hash=IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
            await using(var output=new FileStream(partial,FileMode.Create,FileAccess.Write,FileShare.None))
            {
                var buffer=new byte[131072];long total=0;int count;
                while((count=await input.ReadAsync(buffer,ct))>0)
                {total+=count;if(total>release.Size)throw new InvalidDataException("Installer exceeds declared size");hash.AppendData(buffer,0,count);await output.WriteAsync(buffer.AsMemory(0,count),ct);}
                if(total!=release.Size||!Convert.ToHexString(hash.GetHashAndReset()).Equals(release.Sha256,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("Installer checksum mismatch");
                await output.FlushAsync(ct);
            }
            ct.ThrowIfCancellationRequested();
            if(File.Exists(target)){var attributes=File.GetAttributes(target);if((attributes&FileAttributes.ReadOnly)!=0)File.SetAttributes(target,attributes&~FileAttributes.ReadOnly);}
            File.Move(partial,target,true);return target;
        }
        finally
        {try{if(File.Exists(partial))File.Delete(partial);}catch(IOException){}catch(UnauthorizedAccessException){}}
    }
}
