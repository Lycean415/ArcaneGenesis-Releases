using System.Text.Json;

namespace Arcane.Core;

public sealed class RecoveryIncompleteException(string message):IOException(message){}
public sealed record ForwardRepairPlan(string ArchiveId,string Source,SignedPackReceipt Target,List<SignedPackReceipt> Previous,List<string> Touched);

// Explicit repair finishes one verified target; normal launch never ignores a failed rollback.
public static class InterruptedUpdateRepair
{
    public const string PlanPath=".arcane/forward-repair.json";
    public const string TargetProofPath=".arcane/backup/target-release.json";
    private static T Read<T>(string path,int limit)
    {
        using var input=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read);
        if(input.Length>limit)throw new InvalidDataException("Recovery metadata too large");
        return JsonSerializer.Deserialize<T>(input,Data.Json)??throw new InvalidDataException("Empty recovery metadata");
    }
    public static bool Pending(string root)=>File.Exists(PackUpdater.SafePath(root,PlanPath));
    public static ForwardRepairPlan? Load(string root,string key)
    {
        var path=PackUpdater.SafePath(root,PlanPath);if(!File.Exists(path))return null;
        var plan=Read<ForwardRepairPlan>(path,80*1024*1024);Validate(plan,key);return plan;
    }
    public static ForwardRepairPlan Create(string root,string key,SignedPackReceipt target,string source,List<string> touched)
    {
        var previous=new List<SignedPackReceipt>();
        foreach(var path in new[]{InstalledCatalog.ReceiptPath,TargetProofPath})
        {
            var full=PackUpdater.SafePath(root,path);if(!File.Exists(full))continue;
            var receipt=Read<SignedPackReceipt>(full,24*1024*1024);InstalledCatalog.Verify(receipt,key);previous.Add(receipt);
        }
        var plan=new ForwardRepairPlan(Guid.NewGuid().ToString("N"),source,target,previous,touched);
        Validate(plan,key);return plan;
    }
    public static void Validate(ForwardRepairPlan plan,string key)
    {
        if(plan.ArchiveId is null||!System.Text.RegularExpressions.Regex.IsMatch(plan.ArchiveId,@"\A[a-f0-9]{32}\z")||string.IsNullOrWhiteSpace(plan.Source)||plan.Source.Length>16384||plan.Target is null||plan.Previous is null||plan.Previous.Count>2||plan.Touched is null||plan.Touched.Count>20000)
            throw new InvalidDataException("Invalid recovery plan");
        ChannelAddress.Parse(plan.Source);
        var target=InstalledCatalog.Verify(plan.Target,key);
        var manifests=plan.Previous.Select(p=>InstalledCatalog.Verify(p,key)).Append(target).ToArray();
        if(manifests.Any(m=>ReleaseVersion.Compare(m.Version,target.Version)>0))throw new InvalidDataException("Recovery target would downgrade a verified release");
        if(manifests.Any(m=>m.Version==target.Version&&!PackUpdater.SameContents(m.Files,target.Files)))throw new InvalidDataException("Conflicting signed recovery catalogs under the same version");
        var allowed=manifests.SelectMany(m=>m.Files).Select(f=>f.Path).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(var path in plan.Touched)
        {PackUpdater.ValidateRelativePath(path);if(!seen.Add(path)||!allowed.Contains(path))throw new InvalidDataException("Recovery journal contains a file outside signed catalogs");}
    }
    public static InstalledState Baseline(ForwardRepairPlan plan,string key)
    {
        var manifests=plan.Previous.Select(p=>InstalledCatalog.Verify(p,key)).ToList();
        if(manifests.Count==0)manifests.Add(InstalledCatalog.Verify(plan.Target,key));
        var best=manifests.Aggregate((a,b)=>ReleaseVersion.Compare(a.Version,b.Version)>=0?a:b);
        return new(best.Version,best.Files,best.Minecraft,best.NeoForge);
    }
    public static List<PackFile> RemovedFiles(ForwardRepairPlan plan,string key,HashSet<string> desired)
    {
        var touched=plan.Touched.ToHashSet(StringComparer.OrdinalIgnoreCase);
        return plan.Previous.SelectMany(p=>InstalledCatalog.Verify(p,key).Files)
            .Where(f=>f.Policy=="managed"&&touched.Contains(f.Path)&&!desired.Contains(f.Path))
            .DistinctBy(f=>f.Path,StringComparer.OrdinalIgnoreCase).ToList();
    }
    public static void Archive(string root,ForwardRepairPlan plan,string key,IEnumerable<string> operations)
    {
        Validate(plan,key);
        var paths=operations.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var touched=plan.Touched.ToHashSet(StringComparer.OrdinalIgnoreCase);
        if(paths.Any(p=>!touched.Contains(p)))throw new InvalidDataException("Archive write set is outside the validated recovery plan");
        var relative=".arcane/recovery-archive/"+plan.ArchiveId+"/attempt-"+Guid.NewGuid().ToString("N");
        var destination=PackUpdater.SafePath(root,relative);Directory.CreateDirectory(destination);
        void Copy(string sourceRelative,string targetRelative)
        {
            var source=PackUpdater.SafePath(root,sourceRelative);if(!File.Exists(source))return;
            var target=PackUpdater.SafePath(root,relative+"/"+targetRelative);Directory.CreateDirectory(Path.GetDirectoryName(target)!);File.Copy(source,target,false);
        }
        foreach(var path in paths)Copy(path,"files/"+path);
        Copy(".arcane/installed.json","installed.json");Copy(InstalledCatalog.ReceiptPath,"installed-release.json");
        Copy(".arcane/journal.json","journal-copy.json");
        var backup=PackUpdater.SafePath(root,".arcane/backup");
        void Check(string path)
        {
            foreach(var child in Directory.EnumerateFileSystemEntries(PackUpdater.SafePath(root,path)))
            {var rel=Path.GetRelativePath(root,child).Replace('\\','/');var safe=PackUpdater.SafePath(root,rel);if(Directory.Exists(safe))Check(rel);}
        }
        if(Directory.Exists(backup))Check(".arcane/backup");
        // Durable block on normal launch/update BEFORE the old journal or backup moves.
        Data.Write(PackUpdater.SafePath(root,PlanPath),plan);
        if(Directory.Exists(backup))Directory.Move(backup,PackUpdater.SafePath(root,relative+"/previous-backup"));
        var journal=PackUpdater.SafePath(root,".arcane/journal.json");
        if(File.Exists(journal))File.Move(journal,PackUpdater.SafePath(root,relative+"/previous-journal.json"));
    }
}
