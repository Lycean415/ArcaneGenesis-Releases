using System.Text.RegularExpressions;

namespace Arcane.Core;

public static class ReleaseVersion
{
    private sealed record Parsed(string[] Core,string[] Pre);
    private static Parsed Parse(string value)
    {
        if(string.IsNullOrWhiteSpace(value)||value.Length>128)throw new InvalidDataException("Invalid release version");
        var match=Regex.Match(value,@"\A(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?\z");
        if(!match.Success)throw new InvalidDataException("Invalid release version: "+value);
        var pre=match.Groups[4].Success?match.Groups[4].Value.Split('.'):[];
        if(pre.Any(p=>Numeric(p)&&p.Length>1&&p[0]=='0'))throw new InvalidDataException("Invalid prerelease number");
        return new([match.Groups[1].Value,match.Groups[2].Value,match.Groups[3].Value],pre);
    }
    private static bool Numeric(string text)=>text.All(c=>c is >= '0' and <= '9');
    private static int Number(string a,string b)=>a.Length!=b.Length?a.Length.CompareTo(b.Length):StringComparer.Ordinal.Compare(a,b);
    public static int Compare(string left,string right)
    {
        var a=Parse(left);var b=Parse(right);
        for(int i=0;i<3;i++){var order=Number(a.Core[i],b.Core[i]);if(order!=0)return order;}
        if(a.Pre.Length==0||b.Pre.Length==0)return a.Pre.Length==b.Pre.Length?0:a.Pre.Length==0?1:-1;
        for(int i=0;i<Math.Min(a.Pre.Length,b.Pre.Length);i++)
        {
            var an=Numeric(a.Pre[i]);var bn=Numeric(b.Pre[i]);
            var order=an&&bn?Number(a.Pre[i],b.Pre[i]):an!=bn?an?-1:1:StringComparer.Ordinal.Compare(a.Pre[i],b.Pre[i]);
            if(order!=0)return order;
        }
        return a.Pre.Length.CompareTo(b.Pre.Length);
    }
}
