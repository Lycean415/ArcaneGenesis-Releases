namespace Arcane.Core;

public static class LauncherBuild
{
    public static Version Version
    {
        get{var value=typeof(LauncherBuild).Assembly.GetName().Version??throw new InvalidDataException("Launcher assembly version missing");return new(value.Major,value.Minor,Math.Max(0,value.Build));}
    }
    public static string Display=>Version.ToString(3);
}
