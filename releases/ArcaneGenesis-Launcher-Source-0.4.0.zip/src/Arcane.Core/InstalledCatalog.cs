using System.Security.Cryptography;
using System.Text.Json;

namespace Arcane.Core;

public sealed record SignedPackReceipt(byte[] Manifest,byte[] Signature);

public static class InstalledCatalog
{
    public const string ReceiptPath=".arcane/installed-release.json";
    private static T ReadBounded<T>(string path,int limit)
    {
        using var input=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read);
        if(input.Length>limit)throw new InvalidDataException("Installation metadata is too large");
        return JsonSerializer.Deserialize<T>(input,Data.Json)??throw new InvalidDataException("Empty installation metadata");
    }
    public static PackManifest Verify(SignedPackReceipt receipt,string key)
    {
        if(receipt is null||receipt.Manifest is null||receipt.Signature is null||receipt.Manifest.Length is <1 or >16*1024*1024||receipt.Signature.Length is <1 or >4096)
            throw new InvalidDataException("Invalid installed release receipt");
        using var rsa=RSA.Create();rsa.ImportFromPem(key);
        if(!rsa.VerifyData(receipt.Manifest,receipt.Signature,HashAlgorithmName.SHA256,RSASignaturePadding.Pss))throw new CryptographicException("Installed release signature is invalid");
        var manifest=JsonSerializer.Deserialize<PackManifest>(receipt.Manifest,Data.Json)??throw new InvalidDataException("Empty installed release");
        PackUpdater.Validate(manifest);ReleaseVersion.Compare(manifest.Version,manifest.Version);return manifest;
    }
    private static InstalledState State(PackManifest manifest)=>new(manifest.Version,manifest.Files,manifest.Minecraft,manifest.NeoForge);
    private static InstalledState Legacy(string path)
    {
        var state=ReadBounded<InstalledState>(path,16*1024*1024);
        PackUpdater.Validate(new(1,state.Version,state.Minecraft,state.NeoForge,"",state.Files));ReleaseVersion.Compare(state.Version,state.Version);return state;
    }
    public static InstalledState? Read(string root,string key,bool repair=false)
    {
        var statePath=PackUpdater.SafePath(root,".arcane/installed.json");var receiptPath=PackUpdater.SafePath(root,ReceiptPath);
        try
        {
            if(File.Exists(receiptPath))
            {
                var state=State(Verify(ReadBounded<SignedPackReceipt>(receiptPath,24*1024*1024),key));
                if(repair)
                {
                    bool matches=false;
                    if(File.Exists(statePath))try{matches=JsonSerializer.Serialize(Legacy(statePath),Data.Json)==JsonSerializer.Serialize(state,Data.Json);}catch(Exception e) when(e is JsonException or InvalidDataException){}
                    if(!matches)
                    {
                        if(File.Exists(statePath))File.Move(statePath,PackUpdater.SafePath(root,".arcane/installed.json.bad-"+Guid.NewGuid().ToString("N")));
                        Data.Write(statePath,state);
                    }
                }
                return state;
            }
            return File.Exists(statePath)?Legacy(statePath):null;
        }
        catch(Exception error) when(error is JsonException or InvalidDataException or CryptographicException or ArgumentException)
        {throw new InvalidDataException("Повреждены служебные данные установки. Проверка файлов не будет удалять неизвестные файлы. Нужен действительный подписанный каталог установленной версии либо новая отдельная установка.",error);}
    }
}
