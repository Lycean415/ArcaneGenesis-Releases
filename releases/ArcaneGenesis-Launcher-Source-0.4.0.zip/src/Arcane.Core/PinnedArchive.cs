using System.IO.Compression;
using System.Security.Cryptography;

namespace Arcane.Core;

// The expected digest comes from launcher code, never from a writable receipt.
public static class PinnedArchive
{
    private static Dictionary<string, ZipArchiveEntry> Entries(ZipArchive archive)
    {
        var files = new Dictionary<string, ZipArchiveEntry>(StringComparer.OrdinalIgnoreCase);
        long total = 0;
        foreach (var entry in archive.Entries)
        {
            if (entry.FullName.EndsWith('/')) continue;
            PackUpdater.ValidateRelativePath(entry.FullName);
            total += entry.Length;
            if (entry.Length > 512L * 1024 * 1024 || total > 2L * 1024 * 1024 * 1024 ||
                files.Count >= 20000 || !files.TryAdd(entry.FullName, entry))
                throw new InvalidDataException("Unsafe Java archive");
        }
        if (files.Count == 0) throw new InvalidDataException("Empty Java archive");
        return files;
    }

    private static IEnumerable<string> Files(string root, string relative = "")
    {
        var directory = relative.Length == 0 ? root : PackUpdater.SafePath(root, relative);
        foreach (var path in Directory.EnumerateFileSystemEntries(directory))
        {
            var rel = Path.GetRelativePath(root, path).Replace('\\', '/');
            var safe = PackUpdater.SafePath(root, rel); // Reject links before recursing.
            if (Directory.Exists(safe))
            {
                foreach (var child in Files(root, rel)) yield return child;
            }
            else yield return rel;
        }
    }

    public static string Verify(string zip, string digest, string root)
    {
        if (PackUpdater.Hash(zip) != digest) throw new InvalidDataException("Java archive checksum mismatch");
        using var archive = ZipFile.OpenRead(zip);
        var entries = Entries(archive);
        var installed = Files(root).ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (!installed.SetEquals(entries.Keys)) throw new InvalidDataException("Unexpected or missing Java files");
        foreach (var (name, entry) in entries)
        {
            var path = PackUpdater.SafePath(root, name);
            if (new FileInfo(path).Length != entry.Length) throw new InvalidDataException("Java size mismatch");
            using var source = entry.Open();
            var expected = Convert.ToHexString(SHA256.HashData(source)).ToLowerInvariant();
            if (PackUpdater.Hash(path) != expected) throw new InvalidDataException("Java file checksum mismatch");
        }
        var executable = entries.Keys.Where(x => x.EndsWith("/bin/javaw.exe", StringComparison.OrdinalIgnoreCase)).ToArray();
        if (executable.Length != 1) throw new InvalidDataException("Ambiguous Java executable");
        return PackUpdater.SafePath(root, executable[0]);
    }

    public static void Extract(string zip, string digest, string root)
    {
        if (PackUpdater.Hash(zip) != digest) throw new InvalidDataException("Java archive checksum mismatch");
        using var archive = ZipFile.OpenRead(zip);
        foreach (var (name, entry) in Entries(archive))
        {
            var path = PackUpdater.SafePath(root, name);
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            entry.ExtractToFile(path, false);
        }
    }
}
