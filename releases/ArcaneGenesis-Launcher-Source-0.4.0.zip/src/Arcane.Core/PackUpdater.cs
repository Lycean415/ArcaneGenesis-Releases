using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;

namespace Arcane.Core;

public sealed class PackUpdater
{
    private static readonly HttpClient Http = CreateHttp();
    private static HttpClient CreateHttp(){var http=new HttpClient{Timeout=TimeSpan.FromMinutes(20)};http.DefaultRequestHeaders.UserAgent.ParseAdd("ArcaneGenesisLauncher/"+LauncherBuild.Display);return http;}
    private readonly string root;
    private readonly Uri channel;
    private readonly string key;
    private readonly string? bundledObjects;
    private SignedPackReceipt? verifiedReceipt;
    private Uri? downloadChannel;
    public PackManifest? LastAppliedManifest { get; private set; }
    public string StatePath => System.IO.Path.Combine(root, ".arcane", "installed.json");
    public static bool HasPendingRecovery(string root)=>File.Exists(SafePath(root,".arcane/journal.json"))||InterruptedUpdateRepair.Pending(root);
    public PackUpdater(string root, string channel, string key,string? bundledObjects=null)
    {
        this.root = System.IO.Path.GetFullPath(root);
        this.channel = ChannelAddress.Parse(channel);
        this.key = key;
        if(bundledObjects!=null)
        {var location=ChannelAddress.Parse(bundledObjects);if(!location.IsFile)throw new InvalidDataException("Bundled cache must be local");this.bundledObjects=location.LocalPath;}
        if (!this.channel.IsFile && this.channel.Scheme != "https") throw new InvalidDataException("The update channel must use HTTPS.");
    }
    public static string Hash(string path)
    {
        using var input = File.OpenRead(path);
        return Convert.ToHexString(SHA256.HashData(input)).ToLowerInvariant();
    }
    public static bool SameContents(IEnumerable<PackFile> first,IEnumerable<PackFile> second)
    {
        static IEnumerable<(string,string,long,string)> Ordered(IEnumerable<PackFile> files)=>files.OrderBy(f=>f.Path,StringComparer.OrdinalIgnoreCase).Select(f=>(f.Path.ToLowerInvariant(),f.Sha256,f.Size,f.Policy));
        return Ordered(first).SequenceEqual(Ordered(second));
    }
    public static void ValidateRelativePath(string relative)
    {
        if (string.IsNullOrWhiteSpace(relative) || relative.Contains('\\') || relative.Contains(':') || relative.StartsWith('/') || relative.Split('/').Any(p => p is ".." or "." or "" || p.EndsWith('.') || p.EndsWith(' ') || p.IndexOfAny(System.IO.Path.GetInvalidFileNameChars()) >= 0)) throw new InvalidDataException("Unsafe relative path");
    }
    public static string SafePath(string root, string relative)
    {
        ValidateRelativePath(relative);
        if (string.IsNullOrWhiteSpace(relative) || relative.Contains('\\') || relative.Contains(':') || relative.StartsWith('/') || relative.Split('/').Any(p => p is ".." or "." or "" || p.EndsWith('.') || p.EndsWith(' ') || p.IndexOfAny(System.IO.Path.GetInvalidFileNameChars()) >= 0))
            throw new InvalidDataException("Unsafe path: " + relative);
        var absolute = System.IO.Path.GetFullPath(System.IO.Path.Combine(root, relative));
        var prefix = System.IO.Path.GetFullPath(root).TrimEnd(System.IO.Path.DirectorySeparatorChar) + System.IO.Path.DirectorySeparatorChar;
        if (!absolute.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Path escapes install directory");
        for (var p = absolute; p != null && p.Length >= prefix.Length - 1; p = System.IO.Path.GetDirectoryName(p))
            if ((File.Exists(p) || Directory.Exists(p)) && (File.GetAttributes(p) & FileAttributes.ReparsePoint) != 0) throw new InvalidDataException("Links are not supported in managed paths: " + relative);
        return absolute;
    }
    public static void Validate(PackManifest manifest)
    {
        if (manifest.Schema != 1 || string.IsNullOrWhiteSpace(manifest.Version) || manifest.Files is null || manifest.Files.Count == 0 || manifest.Files.Count > 20000 || manifest.Minecraft != "1.21.1" || manifest.NeoForge != "21.1.265") throw new InvalidDataException("Unsupported pack manifest");
        var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var f in manifest.Files)
        {
            if(f is null||f.Path is null||f.Sha256 is null||f.Url is null)throw new InvalidDataException("Missing file metadata");
            ValidateRelativePath(f.Path);
            if (!paths.Add(f.Path) || f.Size < 0 || f.Size > 2L * 1024 * 1024 * 1024 || !System.Text.RegularExpressions.Regex.IsMatch(f.Sha256, "^[a-f0-9]{64}\\z")) throw new InvalidDataException("Invalid file metadata: " + f.Path);
            if (f.Policy is not ("managed" or "seed")) throw new InvalidDataException("Unsupported update policy");
            // Only modpack-owned content is managed. Player data and credentials are never accepted.
            if (!new[] { "mods/", "config/", "defaultconfigs/", "resourcepacks/", "kubejs/", "scripts/", "global_packs/", "patchouli_books/", "datapacks/" }.Any(x => f.Path.StartsWith(x, StringComparison.OrdinalIgnoreCase))) throw new InvalidDataException("Protected/unknown directory: " + f.Path);
            if (f.Path.EndsWith("/", StringComparison.Ordinal) || f.Path.Contains("runtime-test", StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Test/private content rejected");
        }
        foreach (var p in paths)
            if (paths.Any(other => other.StartsWith(p + "/", StringComparison.OrdinalIgnoreCase))) throw new InvalidDataException("File/directory conflict: " + p);
    }
    private async Task<byte[]> ReadUri(Uri uri, CancellationToken ct)
    {
        ChannelAddress.Check(uri);
        if (!channel.IsFile && uri.Scheme != "https") throw new InvalidDataException("Remote channel cannot read local files");
        if (!uri.IsFile && uri.Scheme != "https") throw new InvalidDataException("HTTPS required");
        if (uri.IsFile) return await ChannelAddress.ReadBoundedAsync(Http,uri,16*1024*1024,ct);
        using var request = new HttpRequestMessage(HttpMethod.Get, uri);
        using var response = await Http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
        response.EnsureSuccessStatusCode();
        if (response.RequestMessage?.RequestUri?.Scheme != "https") throw new InvalidDataException("Insecure redirect");
        await using var stream = await response.Content.ReadAsStreamAsync(ct);
        using var memory = new MemoryStream();
        var buffer = new byte[65536];
        int n;
        while ((n = await stream.ReadAsync(buffer, ct)) != 0) { if (memory.Length + n > 16 * 1024 * 1024) throw new InvalidDataException("Manifest too large"); await memory.WriteAsync(buffer.AsMemory(0,n), ct); }
        return memory.ToArray();
    }
    public async Task<PackManifest> GetManifestAsync(CancellationToken ct = default)
    {
        using var deadline=CancellationTokenSource.CreateLinkedTokenSource(ct);deadline.CancelAfter(TimeSpan.FromSeconds(25));
        var bytes = await ReadUri(channel, deadline.Token);
        if (string.IsNullOrWhiteSpace(key)) throw new InvalidDataException("Trusted release public key is missing");
        var signature = await ReadUri(ChannelAddress.Signature(channel), deadline.Token);
        using var rsa = RSA.Create(); rsa.ImportFromPem(key);
        if (!rsa.VerifyData(bytes, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pss)) throw new CryptographicException("Invalid manifest signature");
        var manifest = JsonSerializer.Deserialize<PackManifest>(bytes, Data.Json) ?? throw new InvalidDataException("Empty manifest");
        Validate(manifest);
        ReleaseVersion.Compare(manifest.Version,manifest.Version);
        verifiedReceipt=new(bytes,signature);
        return manifest;
    }
    private async Task Download(PackFile f, string target, CancellationToken ct)
    {
        if (File.Exists(target) && new FileInfo(target).Length == f.Size && Hash(target) == f.Sha256) return;
        if(await CopyBundled(f,target,ct))return;
        for (int attempt=0;;attempt++)
        {
            ct.ThrowIfCancellationRequested();
            if(File.Exists(target))File.Delete(target);
            try { await DownloadAttempt(f,target,ct); return; }
            catch(Exception ex) when(attempt<2 && !ct.IsCancellationRequested && ex is HttpRequestException or IOException or TaskCanceledException)
            { await Task.Delay(TimeSpan.FromSeconds(attempt+1),ct); }
        }
    }
    private async Task<bool> CopyBundled(PackFile file,string target,CancellationToken ct)
    {
        if(bundledObjects==null)return false;
        FileStream? input=null;
        try
        {
            try
            {
                var path=SafePath(bundledObjects,file.Sha256);
                if(!File.Exists(path))return false;
                input=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read);
                if(input.Length!=file.Size||!Convert.ToHexString(await SHA256.HashDataAsync(input,ct)).Equals(file.Sha256,StringComparison.OrdinalIgnoreCase))return false;
            }
            catch(Exception error) when(error is IOException or UnauthorizedAccessException or InvalidDataException){return false;}
            ct.ThrowIfCancellationRequested();input.Position=0;Directory.CreateDirectory(System.IO.Path.GetDirectoryName(target)!);
            await using(var output=new FileStream(target,FileMode.Create,FileAccess.Write,FileShare.None))await input.CopyToAsync(output,ct);
            return true;
        }
        finally{if(input!=null)await input.DisposeAsync();}
    }
    private async Task DownloadAttempt(PackFile f, string target, CancellationToken ct)
    {
        Directory.CreateDirectory(System.IO.Path.GetDirectoryName(target)!);
        var origin=downloadChannel??channel;
        var uri = ChannelAddress.Check(new Uri(origin, f.Url));
        if ((!origin.IsFile && uri.Scheme != "https") || (!uri.IsFile && uri.Scheme != "https")) throw new InvalidDataException("Insecure download");
        await using var output = new FileStream(target, FileMode.CreateNew, FileAccess.Write, FileShare.None);
        using var response = uri.IsFile ? null : await Http.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead, ct);
        response?.EnsureSuccessStatusCode();
        if (response != null && response.RequestMessage?.RequestUri?.Scheme != "https") throw new InvalidDataException("Insecure redirect");
        await using var input = uri.IsFile ? File.OpenRead(uri.LocalPath) : await response!.Content.ReadAsStreamAsync(ct);
        using var digest = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        var buffer = new byte[131072]; long total = 0; int n;
        while ((n = await input.ReadAsync(buffer, ct)) > 0)
        {
            total += n; if (total > f.Size) throw new InvalidDataException("File exceeds declared size: " + f.Path);
            digest.AppendData(buffer, 0, n); await output.WriteAsync(buffer.AsMemory(0,n), ct);
        }
        if (total != f.Size || !Convert.ToHexString(digest.GetHashAndReset()).Equals(f.Sha256, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Checksum mismatch: " + f.Path);
        await output.FlushAsync(ct);
    }
    public static void EnsureIdle(string gameRoot)
    {
        // The game process continues independently of the invoking process.
        if (Directory.Exists(System.IO.Path.Combine(gameRoot, "saves")))
            foreach (var file in Directory.EnumerateFiles(System.IO.Path.Combine(gameRoot,"saves"), "session.lock", SearchOption.AllDirectories))
            {
                try { using var check = new FileStream(file, FileMode.Open, FileAccess.ReadWrite, FileShare.None); }
                catch (IOException) { throw new IOException("Minecraft is using a world. Close the game before updating."); }
            }
    }
    public Task<InstallResult> RepairAsync(IProgress<UpdateProgress>? progress=null,CancellationToken ct=default,Action<int>? fault=null)=>ApplyAsync(progress,ct,fault,repairIncomplete:true);
    public async Task<InstallResult> ApplyAsync(IProgress<UpdateProgress>? progress = null, CancellationToken ct = default, Action<int>? fault = null,bool repairIncomplete=false)
    {
        Directory.CreateDirectory(root);
        SafePath(root, ".arcane/lock");
        Directory.CreateDirectory(System.IO.Path.Combine(root, ".arcane"));
        using var gate = new FileStream(System.IO.Path.Combine(root,".arcane","lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        EnsureIdle(root);
        ForwardRepairPlan? plan=null;bool interrupted=false;downloadChannel=null;
        if(InterruptedUpdateRepair.Pending(root))
        {
            if(!repairIncomplete)throw new RecoveryIncompleteException("Нужно завершить восстановление сборки. Нажми «Проверить файлы».");
            plan=InterruptedUpdateRepair.Load(root,key);
        }
        if(plan==null)try{Recover();}catch(RecoveryIncompleteException) when(repairIncomplete){interrupted=true;}
        var manifest=plan==null?await GetManifestAsync(ct):InstalledCatalog.Verify(plan.Target,key);
        var receipt=plan?.Target??verifiedReceipt??throw new InvalidDataException("Verified release receipt missing");
        if(interrupted)plan=InterruptedUpdateRepair.Create(root,key,receipt,channel.AbsoluteUri,ReadJournal().Select(e=>e.Path).ToList());
        InstalledState old;
        if(plan!=null)
        {
            var baseline=InterruptedUpdateRepair.Baseline(plan,key);
            old=File.Exists(SafePath(root,InstalledCatalog.ReceiptPath))?InstalledCatalog.Read(root,key)??baseline:baseline;
            downloadChannel=ChannelAddress.Parse(plan.Source);
        }
        else old=InstalledCatalog.Read(root,key,repair:true)??new InstalledState("", []);
        if(old.Version.Length>0&&ReleaseVersion.Compare(manifest.Version,old.Version)<0)throw new InvalidDataException("Канал предлагает более старую версию сборки. Автоматический откат запрещён; установленная версия сохранена.");
        if(manifest.Version==old.Version)
        {
            if(!SameContents(old.Files,manifest.Files))throw new InvalidDataException("Содержимое опубликованной версии изменилось без смены её номера. Установка остановлена, текущая сборка сохранена.");
        }
        if(old.Files.Count>0) Validate(new PackManifest(1,old.Version,"1.21.1","21.1.265","",old.Files));
        foreach (var f in old.Files) SafePath(root, f.Path);
        var stageId=Convert.ToHexString(SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(JsonSerializer.Serialize(manifest,Data.Json)))).ToLowerInvariant();
        var stage = SafePath(root,".arcane/stage/"+stageId);
        Directory.CreateDirectory(stage);
        int unchanged=0, preserved=0;
        List<PackFile> changed = [];
        for (int i=0; i<manifest.Files.Count; i++)
        {
            ct.ThrowIfCancellationRequested();
            var f = manifest.Files[i]; var dest = SafePath(root, f.Path);
            if (File.Exists(dest) && new FileInfo(dest).Length == f.Size && Hash(dest) == f.Sha256) { unchanged++; continue; }
            var prior = old.Files.Find(x => x.Path.Equals(f.Path, StringComparison.OrdinalIgnoreCase));
            // Templates update when untouched; locally edited settings are preserved, with the new default stored separately.
            if (f.Policy == "seed" && File.Exists(dest) && !(plan?.Touched.Contains(f.Path,StringComparer.OrdinalIgnoreCase)??false) && (prior == null || Hash(dest) != prior.Sha256))
            {
                var template = SafePath(stage, "templates/"+f.Path);
                await Download(f, template, ct); preserved++; continue;
            }
            progress?.Report(new UpdateProgress($"{i+1}/{manifest.Files.Count} · {f.Path}", (i+1)*90.0/manifest.Files.Count));
            await Download(f, SafePath(stage,"content/"+f.Path), ct); changed.Add(f);
        }
        var desired = manifest.Files.Select(x => x.Path).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var remove = old.Files.Where(x => !desired.Contains(x.Path) && x.Policy == "managed").ToList();
        if(plan!=null)remove=remove.Concat(InterruptedUpdateRepair.RemovedFiles(plan,key,desired)).DistinctBy(f=>f.Path,StringComparer.OrdinalIgnoreCase).ToList();
        var operations = changed.Select(x=>x.Path).Concat(remove.Select(x=>x.Path)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        ct.ThrowIfCancellationRequested();
        if(plan!=null)
        {
            plan=plan with{Touched=plan.Touched.Concat(operations).Distinct(StringComparer.OrdinalIgnoreCase).ToList()};
            InterruptedUpdateRepair.Validate(plan,key);
            progress?.Report(new UpdateProgress("Сохранение файлов прерванного обновления перед восстановлением",92));
            InterruptedUpdateRepair.Archive(root,plan,key,operations);
        }
        var backup = SafePath(root,".arcane/backup");
        if (!ManagedCache.Remove(root,".arcane/backup"))throw new IOException("Не удалось безопасно очистить рабочую папку резервных копий");
        Directory.CreateDirectory(backup);
        // Back up the entire write set before recording the transaction. No live files have changed yet.
        var journal = operations.Select(p => new JournalEntry(p, File.Exists(SafePath(root,p)))).ToList();
        foreach (var item in journal.Where(x=>x.Existed))
        { var to=SafePath(backup,item.Path); Directory.CreateDirectory(System.IO.Path.GetDirectoryName(to)!); File.Copy(SafePath(root,item.Path),to);Writable(to); }
        if (File.Exists(StatePath)) File.Copy(StatePath, System.IO.Path.Combine(backup,"installed.json"));
        var receiptPath=SafePath(root,InstalledCatalog.ReceiptPath);
        var metadataBackup=new MetadataBackup(File.Exists(StatePath),File.Exists(receiptPath));
        if(metadataBackup.Receipt)File.Copy(receiptPath,SafePath(backup,"installed-release.json"));
        Data.Write(SafePath(backup,"metadata.json"),metadataBackup);
        Data.Write(SafePath(root,InterruptedUpdateRepair.TargetProofPath),receipt);
        Data.Write(System.IO.Path.Combine(root,".arcane","journal.json"),journal);
        try
        {
            EnsureIdle(root); ct.ThrowIfCancellationRequested(); int count=0;
            foreach (var p in operations)
            {
                var dest=SafePath(root,p); var source=SafePath(stage,"content/"+p);
                if (File.Exists(source)) { Directory.CreateDirectory(System.IO.Path.GetDirectoryName(dest)!); CopyReplace(source,dest); }
                else if (File.Exists(dest)){Writable(dest);File.Delete(dest);}
                fault?.Invoke(++count);
            }
            Data.Write(StatePath, new InstalledState(manifest.Version,manifest.Files,manifest.Minecraft,manifest.NeoForge));
            fault?.Invoke(++count);
            Data.Write(receiptPath,receipt);
            fault?.Invoke(++count);
            File.Delete(System.IO.Path.Combine(root,".arcane","journal.json"));
            if(plan!=null){var marker=SafePath(root,InterruptedUpdateRepair.PlanPath);Writable(marker);File.Delete(marker);}
        }
        catch { Recover(); throw; }
        var templates=System.IO.Path.Combine(stage,"templates");
        if (Directory.Exists(templates)) foreach(var file in Directory.EnumerateFiles(templates,"*",SearchOption.AllDirectories))
        { var dest=SafePath(root,".arcane/new-defaults/"+System.IO.Path.GetRelativePath(templates,file).Replace('\\','/')); Directory.CreateDirectory(System.IO.Path.GetDirectoryName(dest)!); File.Copy(file,dest,true); }
        progress?.Report(new UpdateProgress(manifest.Version,100));
        LastAppliedManifest=manifest;
        ManagedCache.Remove(root,".arcane/backup");
        ManagedCache.Prune(root,".arcane/stage","",64,2,stageId);
        return new InstallResult(changed.Count,unchanged,preserved,manifest.Version);
    }
    public void RecoverBeforeLaunch()
    {
        if(InterruptedUpdateRepair.Pending(root))throw new RecoveryIncompleteException("Нужно завершить восстановление сборки. Нажми «Проверить файлы».");
        if(!File.Exists(SafePath(root,".arcane/journal.json"))&&!File.Exists(SafePath(root,InstalledCatalog.ReceiptPath)))return;
        using var gate=new FileStream(SafePath(root,".arcane/lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
        EnsureIdle(root);Recover();InstalledCatalog.Read(root,key,repair:true);
    }
    private static void Writable(string path){if(File.Exists(path))File.SetAttributes(path,File.GetAttributes(path)&~FileAttributes.ReadOnly);}
    private static void CopyReplace(string source,string target){Writable(target);File.Copy(source,target,true);}
    private sealed record JournalEntry(string Path, bool Existed);
    private sealed record MetadataBackup(bool State,bool Receipt);
    private List<JournalEntry> ReadJournal()
    {
        var path=SafePath(root,".arcane/journal.json");
        using var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read);
        if(stream.Length>16*1024*1024)throw new InvalidDataException("Recovery journal too large");
        var entries=JsonSerializer.Deserialize<List<JournalEntry>>(stream,Data.Json)??throw new InvalidDataException("Empty recovery journal");
        if(entries.Any(e=>e is null))throw new InvalidDataException("Invalid recovery journal");
        if(entries.Count>0)Validate(new PackManifest(1,"recovery","1.21.1","21.1.265","",entries.Select(e=>new PackFile(e.Path,"",new string('0',64),0)).ToList()));
        return entries;
    }
    public void Recover()
    {
        var journal=System.IO.Path.Combine(root,".arcane","journal.json");
        if (!File.Exists(journal)) return;
        var backup=System.IO.Path.Combine(root,".arcane","backup");
        var entries=ReadJournal();
        foreach(var item in entries)if(item.Existed&&!File.Exists(SafePath(backup,item.Path)))throw new RecoveryIncompleteException("Резервный файл утрачен. Для восстановления нажми «Проверить файлы»: "+item.Path);
        var metadataPath=SafePath(backup,"metadata.json");
        var metadata=File.Exists(metadataPath)?Data.Read<MetadataBackup>(metadataPath):null;
        if(metadata?.State==true&&!File.Exists(SafePath(backup,"installed.json")))throw new RecoveryIncompleteException("Утрачена резервная копия каталога. Нажми «Проверить файлы».");
        if(metadata?.Receipt==true&&!File.Exists(SafePath(backup,"installed-release.json")))throw new RecoveryIncompleteException("Утрачена резервная подпись каталога. Нажми «Проверить файлы».");
        foreach (var item in entries)
        {
            var target=SafePath(root,item.Path);
            if (item.Existed) { Directory.CreateDirectory(System.IO.Path.GetDirectoryName(target)!); CopyReplace(SafePath(backup,item.Path),target); }
            else if (File.Exists(target)){Writable(target);File.Delete(target);}
        }
        var stateBackup=System.IO.Path.Combine(backup,"installed.json");
        if(File.Exists(stateBackup)) CopyReplace(stateBackup,StatePath); else if(File.Exists(StatePath)) File.Delete(StatePath);
        if(metadata!=null)
        {
            var target=SafePath(root,InstalledCatalog.ReceiptPath);
            if(metadata.Receipt)CopyReplace(SafePath(backup,"installed-release.json"),target);
            else if(File.Exists(target)){Writable(target);File.Delete(target);}
        }
        File.Delete(journal);
    }
}

