using System.Text.RegularExpressions;

namespace Arcane.Core;

public static class ManagedCache
{
    public static bool Remove(string root,string relative)
    {
        // Cache deletion never follows links or recursively deletes an unchecked tree.
        try
        {
            var top=PackUpdater.SafePath(root,relative);
            if(!Directory.Exists(top))return true;
            var files=new List<string>();var directories=new List<string>();
            void Visit(string rel)
            {
                var directory=PackUpdater.SafePath(root,rel);directories.Add(directory);
                foreach(var entry in Directory.EnumerateFileSystemEntries(directory))
                {
                    var child=Path.GetRelativePath(root,entry).Replace('\\','/');var path=PackUpdater.SafePath(root,child);
                    if(Directory.Exists(path))Visit(child);else files.Add(path);
                }
            }
            Visit(relative); // Complete link/path preflight before deleting any file.
            foreach(var file in files)
            {
                var safe=PackUpdater.SafePath(root,Path.GetRelativePath(root,file).Replace('\\','/'));
                File.SetAttributes(safe,File.GetAttributes(safe)&~FileAttributes.ReadOnly);File.Delete(safe);
            }
            foreach(var directory in directories.OrderByDescending(p=>p.Length))
                Directory.Delete(PackUpdater.SafePath(root,Path.GetRelativePath(root,directory).Replace('\\','/')),false);
            return true;
        }
        catch(Exception e) when(e is IOException or UnauthorizedAccessException or InvalidDataException){return false;}
    }

    public static void Prune(string root,string relative,string prefix,int identifierLength,int keep,string? preserve=null)
    {
        try
        {
            var directory=PackUpdater.SafePath(root,relative);if(!Directory.Exists(directory))return;
            var pattern="^"+Regex.Escape(prefix)+"[a-f0-9]{"+identifierLength+"}\\z";
            var candidates=Directory.EnumerateDirectories(directory).Where(p=>Regex.IsMatch(Path.GetFileName(p),pattern))
                .Select(p=>PackUpdater.SafePath(root,relative+"/"+Path.GetFileName(p)))
                .OrderByDescending(Directory.GetLastWriteTimeUtc).ToList();
            var retained=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if(preserve!=null)retained.Add(preserve);
            foreach(var path in candidates)
            {
                var name=Path.GetFileName(path);
                if(retained.Contains(name))continue;
                if(retained.Count<keep){retained.Add(name);continue;}
                Remove(root,relative+"/"+name);
            }
        }
        catch(Exception e) when(e is IOException or UnauthorizedAccessException or InvalidDataException){ /* Best-effort cache maintenance never invalidates a successful installation. */ }
    }
}
