using System.Text.Json;
using System.Text.Json.Serialization;

namespace Arcane.Core;

public sealed record PackFile(string Path, string Url, string Sha256, long Size, string Policy = "managed", string? Source = null);
public sealed record PackManifest(int Schema, string Version, string Minecraft, string NeoForge, string News, List<PackFile> Files);
public sealed record InstalledState(string Version, List<PackFile> Files, string Minecraft="1.21.1", string NeoForge="21.1.265");
public sealed record UpdateProgress(string Message, double Percent);
public sealed record InstallResult(int Downloaded, int Unchanged, int Preserved, string Version);
public sealed record EnginePin(string Version, string Url, string Sha256);
public sealed class LauncherSettings
{
    public string InstallDirectory { get; set; } = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ArcaneGenesis", "Game");
    public string Channel { get; set; } = "";
    public string RuntimeChannel { get; set; } = "";
    public string LauncherChannel { get; set; } = "";
    public string Language { get; set; } = "ru";
    public string ProfileMode { get; set; } = "local";
    public string Nickname { get; set; } = "";
    public string MicrosoftProfile { get; set; } = "";
    public int MemoryMiB { get; set; } = 7168;
    public int Width { get; set; } = 1280;
    public int Height { get; set; } = 720;
    public bool Fullscreen { get; set; }
    public bool AutoUpdate { get; set; } = true;
    public bool Minimize { get; set; } = true;
    public string JavaPath { get; set; } = "";
    public string PublicKey { get; set; } = "";
    public string LauncherPublicKey { get; set; } = "";
}
public static class Data
{
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { WriteIndented = true, UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow };
    public static LauncherSettings ReadSettings(string path,LauncherSettings fallback)
    {
        if(!File.Exists(path))return fallback;
        try{return JsonSerializer.Deserialize<LauncherSettings>(File.ReadAllText(path),new JsonSerializerOptions(Json){UnmappedMemberHandling=JsonUnmappedMemberHandling.Skip})??throw new JsonException("Empty settings");}
        catch(Exception ex) when(ex is JsonException or InvalidDataException)
        {File.Move(path,path+".bad-"+Guid.NewGuid().ToString("N"));return fallback;}
    }
    public static T Read<T>(string path) => JsonSerializer.Deserialize<T>(File.ReadAllText(path), Json) ?? throw new InvalidDataException("Empty JSON");
    public static void Write<T>(string path, T value)
    {
        var absolute=System.IO.Path.GetFullPath(path);var directory=System.IO.Path.GetDirectoryName(absolute)!;
        Directory.CreateDirectory(directory);PackUpdater.SafePath(directory,System.IO.Path.GetFileName(absolute));
        var temp=PackUpdater.SafePath(directory,System.IO.Path.GetFileName(absolute)+".new-"+Guid.NewGuid().ToString("N"));
        try
        {
            using(var output=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None))
            {JsonSerializer.Serialize(output,value,Json);output.Flush(true);}
            PackUpdater.SafePath(directory,System.IO.Path.GetFileName(absolute));
            if(File.Exists(absolute))
            {var attributes=File.GetAttributes(absolute);if((attributes&FileAttributes.ReadOnly)!=0)File.SetAttributes(absolute,attributes&~FileAttributes.ReadOnly);}
            File.Move(temp,absolute,true);
        }
        finally{if(File.Exists(temp))File.Delete(temp);}
    }
}
