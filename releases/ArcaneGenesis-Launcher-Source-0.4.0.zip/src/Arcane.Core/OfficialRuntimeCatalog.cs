using System.Text.Json;

namespace Arcane.Core;

// Release-controlled metadata only. No game binaries, paths or writable receipts.
public static class OfficialRuntimeCatalog
{
    public static GameRuntime Read()
    {
        using var input=typeof(OfficialRuntimeCatalog).Assembly.GetManifestResourceStream("Arcane.OfficialRuntime")
            ??throw new InvalidDataException("Official runtime catalog is missing");
        var runtime=JsonSerializer.Deserialize<GameRuntime>(input,Data.Json)??throw new InvalidDataException("Empty official catalog");
        NativeGameEngine.Validate(runtime);
        return runtime;
    }

    public static bool VerifyNatives(string root,GameRuntime runtime)
    {
        var expected=runtime.Files.Where(f=>f.Path.StartsWith("natives/",StringComparison.Ordinal)).Select(f=>f.Path).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var directory=PackUpdater.SafePath(root,"natives");
        if(!Directory.Exists(directory))return false;
        var actual=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        bool Visit(string relative)
        {
            foreach(var path in Directory.EnumerateFileSystemEntries(PackUpdater.SafePath(root,relative)))
            {
                var name=Path.GetRelativePath(root,path).Replace('\\','/');
                var safe=PackUpdater.SafePath(root,name);
                if(Directory.Exists(safe)){if(!Visit(name))return false;}
                else if(!expected.Contains(name)||!actual.Add(name))return false;
            }
            return true;
        }
        return Visit("natives")&&actual.SetEquals(expected);
    }

    public static bool VerifyFiles(string root,GameRuntime runtime,CancellationToken ct=default)
    {
        if(!VerifyNatives(root,runtime))return false;
        foreach(var file in runtime.Files)
        {
            ct.ThrowIfCancellationRequested();
            var path=PackUpdater.SafePath(root,file.Path);
            if(!File.Exists(path)||new FileInfo(path).Length!=file.Size||PackUpdater.Hash(path)!=file.Sha256)return false;
        }
        return true;
    }
}
