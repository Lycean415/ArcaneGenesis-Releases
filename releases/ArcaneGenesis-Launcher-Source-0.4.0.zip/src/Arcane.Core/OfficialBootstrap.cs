using System.Diagnostics;
using System.IO.Compression;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json.Nodes;

namespace Arcane.Core;

// No game binaries or user-machine paths are distributed. Each installation is built
// from Mojang metadata and the checksum-pinned, unmodified NeoForge installer.
public static class OfficialBootstrap
{
    public const string Channel = "official:1.21.1-neoforge-21.1.265";
    private const string InstallerHash = "a547ccc30a80a675d1c61d04b55d10c45c39a86971e09731482c50a24399d1a2";
    private const string JavaHash = "e15ee1e54a5a3b38027a09cedfa87bc3348d7dd3ce50866dd3d9671d7fffc6c1";
    private const string JavaUrl = "https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.13.1%2B2/OpenJDK21U-jre_x64_windows_hotspot_21.0.13.1_2.zip";
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromMinutes(20) };
    private static string S(JsonNode n,string key)=>n[key]!.GetValue<string>();
    private static string Digest(string file, bool sha1)
    { using var input=File.OpenRead(file);return Convert.ToHexString(sha1?SHA1.HashData(input):SHA256.HashData(input)).ToLowerInvariant(); }

    private static async Task Fetch(string url,string file,string hash,bool sha1,CancellationToken ct)
    {
        if(File.Exists(file)&&Digest(file,sha1)==hash)return;
        if(new Uri(url).Scheme!="https")throw new InvalidDataException("Official downloads require HTTPS");
        Directory.CreateDirectory(Path.GetDirectoryName(file)!);
        for(int attempt=0;;attempt++)
        {
            try
            {
                using var response=await Http.GetAsync(url,HttpCompletionOption.ResponseHeadersRead,ct);response.EnsureSuccessStatusCode();
                if(response.RequestMessage?.RequestUri?.Scheme!="https")throw new InvalidDataException("Insecure redirect");
                await using(var output=new FileStream(file+".partial",FileMode.Create,FileAccess.Write,FileShare.None))
                await using(var input=await response.Content.ReadAsStreamAsync(ct)) { var buffer=new byte[131072];long total=0;int count;while((count=await input.ReadAsync(buffer,ct))>0){total+=count;if(total>1024L*1024*1024)throw new InvalidDataException("Official download exceeds size limit");await output.WriteAsync(buffer.AsMemory(0,count),ct);} }
                if(Digest(file+".partial",sha1)!=hash)throw new InvalidDataException("Official download checksum mismatch: "+Path.GetFileName(file));
                File.Move(file+".partial",file,true);return;
            }
            catch(Exception ex) when(attempt<2 && !ct.IsCancellationRequested && ex is HttpRequestException or IOException or TaskCanceledException) { await Task.Delay(500*(attempt+1),ct); }
        }
    }
    private static async Task<JsonNode> Json(string url,CancellationToken ct)
    { if(new Uri(url).Scheme!="https")throw new InvalidDataException("HTTPS required");return JsonNode.Parse(await ChannelAddress.ReadBoundedAsync(Http,new Uri(url),16*1024*1024,ct))??throw new InvalidDataException("Empty metadata"); }
    public static bool AllowsWindows(JsonNode library)
    {
        if(library["rules"] is not JsonArray rules)return true;
        bool allowed=false;
        foreach(var r in rules)
        {
            if(r!["features"]!=null)continue;
            var os=r["os"];if(os!=null && (os["name"]?.GetValue<string>() is string name && name!="windows"))continue;
            if(os?["arch"]?.GetValue<string>() is string arch && arch is not ("x86_64" or "amd64"))continue;
            allowed=S(r,"action")=="allow";
        }
        return allowed;
    }
    private static void Extract(string zip,string output,bool dllOnly=false)
    {
        using var archive=ZipFile.OpenRead(zip);
        foreach(var e in archive.Entries)
        {
            if(e.FullName.EndsWith('/'))continue;
            if(dllOnly&&!e.FullName.EndsWith(".dll",StringComparison.OrdinalIgnoreCase))continue;
            var name=dllOnly?Path.GetFileName(e.FullName):e.FullName;
            var target=PackUpdater.SafePath(output,name);Directory.CreateDirectory(Path.GetDirectoryName(target)!);e.ExtractToFile(target,true);
        }
    }
    public static string? Java(string runtime)
    {
        try { return PinnedArchive.Verify(PackUpdater.SafePath(runtime,"bootstrap/java21.zip"),JavaHash,PackUpdater.SafePath(runtime,"jre")); }
        catch(Exception e) when(e is IOException or InvalidDataException or UnauthorizedAccessException) { return null; }
    }
    private static async Task<string> EnsureJava(string root,CancellationToken ct)
    {
        var existing=Java(root);if(existing!=null)return existing;
        var zip=Path.Combine(root,"bootstrap","java21.zip");await Fetch(JavaUrl,zip,JavaHash,false,ct);
        // Build separately: never merge a clean runtime with unlisted executable files.
        var jre=PackUpdater.SafePath(root,"jre");
        var staged=PackUpdater.SafePath(root,"bootstrap/jre-stage-"+Guid.NewGuid().ToString("N"));
        PinnedArchive.Extract(zip,JavaHash,staged);
        PinnedArchive.Verify(zip,JavaHash,staged);
        ct.ThrowIfCancellationRequested();
        var rejected=PackUpdater.SafePath(root,"bootstrap/jre-rejected-"+Guid.NewGuid().ToString("N"));
        if(Directory.Exists(jre))Directory.Move(jre,rejected);
        try { Directory.Move(staged,jre); }
        catch { if(Directory.Exists(rejected)&&!Directory.Exists(jre))Directory.Move(rejected,jre);throw; }
        return Java(root)??throw new IOException("Java 21 archive is incomplete");
    }
    private static bool RestoreNativesFromCache(string root,GameRuntime trusted,CancellationToken ct)
    {
        var sources=trusted.Files.Where(f=>f.Path.StartsWith("libraries/",StringComparison.Ordinal)&&f.Path.Contains("natives-windows.jar",StringComparison.Ordinal)).ToArray();
        foreach(var file in sources)
        {
            ct.ThrowIfCancellationRequested();var path=PackUpdater.SafePath(root,file.Path);
            if(!File.Exists(path)||PackUpdater.Hash(path)!=file.Sha256)return false;
        }
        var staged=PackUpdater.SafePath(root,"bootstrap/native-stage-"+Guid.NewGuid().ToString("N"));
        foreach(var file in sources){ct.ThrowIfCancellationRequested();Extract(PackUpdater.SafePath(root,file.Path),Path.Combine(staged,"natives"),true);}
        if(!OfficialRuntimeCatalog.VerifyNatives(staged,trusted))throw new InvalidDataException("Incomplete native cache");
        foreach(var file in trusted.Files.Where(f=>f.Path.StartsWith("natives/",StringComparison.Ordinal)))
            if(PackUpdater.Hash(PackUpdater.SafePath(staged,file.Path))!=file.Sha256)throw new InvalidDataException("Native cache checksum mismatch");
        ct.ThrowIfCancellationRequested();
        var natives=PackUpdater.SafePath(root,"natives");var backup=PackUpdater.SafePath(root,"bootstrap/natives-rejected-"+Guid.NewGuid().ToString("N"));
        if(Directory.Exists(natives))Directory.Move(natives,backup);
        try{Directory.Move(Path.Combine(staged,"natives"),natives);}
        catch{if(Directory.Exists(backup)&&!Directory.Exists(natives))Directory.Move(backup,natives);throw;}
        Directory.Delete(staged);return true;
    }
    public static async Task<GameRuntime> Ensure(string root,IProgress<UpdateProgress>? progress,CancellationToken ct)
    {
        Directory.CreateDirectory(root);
        progress?.Report(new("Java 21 · проверка среды",0));var java=await EnsureJava(root,ct);
        var receipt=Path.Combine(root,"official-runtime.json");
        var trusted=OfficialRuntimeCatalog.Read();
        if(!OfficialRuntimeCatalog.VerifyNatives(root,trusted))RestoreNativesFromCache(root,trusted,ct);
        if(OfficialRuntimeCatalog.VerifyFiles(root,trusted,ct)){CleanCache(root);return trusted;}
        var meta=await Json("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json",ct);
        var version=meta["versions"]!.AsArray().First(x=>S(x!,"id")=="1.21.1")!;
        var vanillaPath=PackUpdater.SafePath(root,"versions/1.21.1/1.21.1.json");
        await Fetch(S(version,"url"),vanillaPath,S(version,"sha1"),true,ct);
        var vanilla=JsonNode.Parse(await File.ReadAllTextAsync(vanillaPath,ct))!;
        var client=vanilla["downloads"]!["client"]!;
        if(S(client,"sha1")!="30c73b1c5da787909b2f73340419fdf13b9def88")throw new InvalidDataException("Unexpected Minecraft 1.21.1 client");
        progress?.Report(new("Minecraft 1.21.1 · загрузка",3));
        await Fetch(S(client,"url"),PackUpdater.SafePath(root,"versions/1.21.1/1.21.1.jar"),S(client,"sha1"),true,ct);
        Directory.CreateDirectory(Path.Combine(root,"client"));File.Copy(PackUpdater.SafePath(root,"versions/1.21.1/1.21.1.jar"),PackUpdater.SafePath(root,"client/client.jar"),true);
        // A repaired native directory must not inherit unlisted DLLs.
        var nativeDirectory=PackUpdater.SafePath(root,"natives");
        if(Directory.Exists(nativeDirectory))Directory.Move(nativeDirectory,PackUpdater.SafePath(root,"bootstrap/natives-rejected-"+Guid.NewGuid().ToString("N")));
        var libraries=vanilla["libraries"]!.AsArray().Where(x=>AllowsWindows(x!)).Select(x=>x!).ToArray();
        var cp=new List<string>();int done=0;
        foreach(var lib in libraries)
        {
            var a=lib["downloads"]?["artifact"];if(a==null)continue;
            var path="libraries/"+S(a,"path");await Fetch(S(a,"url"),PackUpdater.SafePath(root,path),S(a,"sha1"),true,ct);cp.Add(path);
            // Native classifiers in modern Mojang metadata are regular artifacts.
            if(path.Contains("natives-windows.jar",StringComparison.Ordinal))Extract(PackUpdater.SafePath(root,path),Path.Combine(root,"natives"),true);
            progress?.Report(new($"Библиотеки Minecraft · {++done}/{libraries.Length}",5+done*15.0/libraries.Length));
        }
        var index=vanilla["assetIndex"]!;var assetId=S(index,"id");
        var indexPath=PackUpdater.SafePath(root,"assets/indexes/"+assetId+".json");await Fetch(S(index,"url"),indexPath,S(index,"sha1"),true,ct);
        var objects=JsonNode.Parse(await File.ReadAllTextAsync(indexPath,ct))!["objects"]!.AsObject().Select(x=>x.Value!).GroupBy(x=>S(x,"hash")).Select(x=>x.First()).ToArray();done=0;
        await Parallel.ForEachAsync(objects,new ParallelOptions{MaxDegreeOfParallelism=8,CancellationToken=ct},async(obj,token)=>
        {
            var h=S(obj,"hash");await Fetch("https://resources.download.minecraft.net/"+h[..2]+"/"+h,PackUpdater.SafePath(root,"assets/objects/"+h[..2]+"/"+h),h,true,token);
            var n=Interlocked.Increment(ref done);if(n%25==0||n==objects.Length)progress?.Report(new($"Ресурсы Minecraft · {n}/{objects.Length}",20+n*50.0/objects.Length));
        });
        var installer=PackUpdater.SafePath(root,"bootstrap/neoforge-installer.jar");
        await Fetch("https://maven.neoforged.net/releases/net/neoforged/neoforge/21.1.265/neoforge-21.1.265-installer.jar",installer,InstallerHash,false,ct);
        // The official installer requires the standard launcher directory marker.
        var profiles=Path.Combine(root,"launcher_profiles.json");if(!File.Exists(profiles))await File.WriteAllTextAsync(profiles,"{\"profiles\":{}}",ct);
        progress?.Report(new("NeoForge 21.1.265 · официальная установка",72));
        var start=new ProcessStartInfo(Path.Combine(Path.GetDirectoryName(java)!,"java.exe")){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=root,RedirectStandardOutput=true,RedirectStandardError=true};
        foreach(var arg in new[]{"-jar",installer,"--installClient",root})start.ArgumentList.Add(arg);
        using(var process=Process.Start(start)??throw new IOException("Cannot start NeoForge installer"))
        {
            var stdout=process.StandardOutput.ReadToEndAsync(ct);var stderr=process.StandardError.ReadToEndAsync(ct);
            using var registration=ct.Register(()=>{try{process.Kill(true);}catch(InvalidOperationException){}});
            await process.WaitForExitAsync(ct);var log=(await stdout)+"\n"+(await stderr);await File.WriteAllTextAsync(Path.Combine(root,"bootstrap","neoforge-install.log"),log,ct);
            if(process.ExitCode!=0)throw new IOException("NeoForge не установлен. Подробности: "+Path.Combine(root,"bootstrap","neoforge-install.log"));
        }
        var neo=JsonNode.Parse(await File.ReadAllTextAsync(PackUpdater.SafePath(root,"versions/neoforge-21.1.265/neoforge-21.1.265.json"),ct))!;
        foreach(var lib in neo["libraries"]!.AsArray())
        {
            var a=lib!["downloads"]?["artifact"];if(a==null)continue;
            var path="libraries/"+S(a,"path");
            if(!File.Exists(PackUpdater.SafePath(root,path))||Digest(PackUpdater.SafePath(root,path),true)!=S(a,"sha1"))await Fetch(S(a,"url"),PackUpdater.SafePath(root,path),S(a,"sha1"),true,ct);
            cp.Insert(0,path);
        }
        cp.Add("client/client.jar");
        var jvm=neo["arguments"]!["jvm"]!.AsArray().Where(x=>x is JsonValue).Select(x=>x!.GetValue<string>()).ToArray();var mp=jvm[Array.IndexOf(jvm,"-p")+1].Replace("${classpath_separator}",";").Split(';').Select(x=>x.Replace("${library_directory}/","libraries/")).ToArray();
        if(assetId!=trusted.AssetIndex||!cp.Distinct().SequenceEqual(trusted.ClassPath)||!mp.SequenceEqual(trusted.ModulePath)||!OfficialRuntimeCatalog.VerifyFiles(root,trusted,ct))
            throw new InvalidDataException("Official runtime differs from the release catalog. Repair is required; no unverified runtime will be launched.");
        Data.Write(receipt,trusted);CleanCache(root);progress?.Report(new("Minecraft и NeoForge установлены",100));return trusted;
    }
    private static void CleanCache(string root)
    {
        ManagedCache.Prune(root,"bootstrap","jre-rejected-",32,1);
        ManagedCache.Prune(root,"bootstrap","natives-rejected-",32,1);
        ManagedCache.Prune(root,"bootstrap","jre-stage-",32,0);
        ManagedCache.Prune(root,"bootstrap","native-stage-",32,0);
    }
}

